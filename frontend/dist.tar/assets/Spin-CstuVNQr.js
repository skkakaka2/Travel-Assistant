import{t as e}from"./use-compitable-C1bpwaTZ.js";import{$t as t,Bn as n,Bt as r,Dn as i,Dr as a,Fn as o,In as s,J as c,K as l,Kn as u,Kt as d,Mn as f,Mr as p,Nn as m,Nr as h,R as g,Rn as _,Sr as v,Vn as y,X as b,dr as x,in as S,lr as C,lt as w,ot as T,p as E,q as D,tr as O,yn as k,zn as A,zt as j}from"./index-CpWi_OZp.js";function M(e){let{textColor2:t,primaryColorHover:n,primaryColorPressed:r,primaryColor:a,infoColor:o,successColor:s,warningColor:c,errorColor:l,baseColor:u,borderColor:d,opacityDisabled:f,tagColor:p,closeIconColor:m,closeIconColorHover:h,closeIconColorPressed:_,borderRadiusSmall:v,fontSizeMini:y,fontSizeTiny:b,fontSizeSmall:x,fontSizeMedium:S,heightMini:C,heightTiny:w,heightSmall:T,heightMedium:E,closeColorHover:D,closeColorPressed:O,buttonColor2Hover:k,buttonColor2Pressed:A,fontWeightStrong:j}=e;return Object.assign(Object.assign({},g),{closeBorderRadius:v,heightTiny:C,heightSmall:w,heightMedium:T,heightLarge:E,borderRadius:v,opacityDisabled:f,fontSizeTiny:y,fontSizeSmall:b,fontSizeMedium:x,fontSizeLarge:S,fontWeightStrong:j,textColorCheckable:t,textColorHoverCheckable:t,textColorPressedCheckable:t,textColorChecked:u,colorCheckable:`#0000`,colorHoverCheckable:k,colorPressedCheckable:A,colorChecked:a,colorCheckedHover:n,colorCheckedPressed:r,border:`1px solid ${d}`,textColor:t,color:p,colorBordered:`rgb(250, 250, 252)`,closeIconColor:m,closeIconColorHover:h,closeIconColorPressed:_,closeColorHover:D,closeColorPressed:O,borderPrimary:`1px solid ${i(a,{alpha:.3})}`,textColorPrimary:a,colorPrimary:i(a,{alpha:.12}),colorBorderedPrimary:i(a,{alpha:.1}),closeIconColorPrimary:a,closeIconColorHoverPrimary:a,closeIconColorPressedPrimary:a,closeColorHoverPrimary:i(a,{alpha:.12}),closeColorPressedPrimary:i(a,{alpha:.18}),borderInfo:`1px solid ${i(o,{alpha:.3})}`,textColorInfo:o,colorInfo:i(o,{alpha:.12}),colorBorderedInfo:i(o,{alpha:.1}),closeIconColorInfo:o,closeIconColorHoverInfo:o,closeIconColorPressedInfo:o,closeColorHoverInfo:i(o,{alpha:.12}),closeColorPressedInfo:i(o,{alpha:.18}),borderSuccess:`1px solid ${i(s,{alpha:.3})}`,textColorSuccess:s,colorSuccess:i(s,{alpha:.12}),colorBorderedSuccess:i(s,{alpha:.1}),closeIconColorSuccess:s,closeIconColorHoverSuccess:s,closeIconColorPressedSuccess:s,closeColorHoverSuccess:i(s,{alpha:.12}),closeColorPressedSuccess:i(s,{alpha:.18}),borderWarning:`1px solid ${i(c,{alpha:.35})}`,textColorWarning:c,colorWarning:i(c,{alpha:.15}),colorBorderedWarning:i(c,{alpha:.12}),closeIconColorWarning:c,closeIconColorHoverWarning:c,closeIconColorPressedWarning:c,closeColorHoverWarning:i(c,{alpha:.12}),closeColorPressedWarning:i(c,{alpha:.18}),borderError:`1px solid ${i(l,{alpha:.23})}`,textColorError:l,colorError:i(l,{alpha:.1}),colorBorderedError:i(l,{alpha:.08}),closeIconColorError:l,closeIconColorHoverError:l,closeIconColorPressedError:l,closeColorHoverError:i(l,{alpha:.12}),closeColorPressedError:i(l,{alpha:.18})})}var N={name:`Tag`,common:l,self:M},P={color:Object,type:{type:String,default:`default`},round:Boolean,size:{type:String,default:`medium`},closable:Boolean,disabled:{type:Boolean,default:void 0}},F=s(`tag`,`
 --n-close-margin: var(--n-close-margin-top) var(--n-close-margin-right) var(--n-close-margin-bottom) var(--n-close-margin-left);
 white-space: nowrap;
 position: relative;
 box-sizing: border-box;
 cursor: default;
 display: inline-flex;
 align-items: center;
 flex-wrap: nowrap;
 padding: var(--n-padding);
 border-radius: var(--n-border-radius);
 color: var(--n-text-color);
 background-color: var(--n-color);
 transition: 
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 line-height: 1;
 height: var(--n-height);
 font-size: var(--n-font-size);
`,[A(`strong`,`
 font-weight: var(--n-font-weight-strong);
 `),_(`border`,`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 border-radius: inherit;
 border: var(--n-border);
 transition: border-color .3s var(--n-bezier);
 `),_(`icon`,`
 display: flex;
 margin: 0 4px 0 0;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 font-size: var(--n-avatar-size-override);
 `),_(`avatar`,`
 display: flex;
 margin: 0 6px 0 0;
 `),_(`close`,`
 margin: var(--n-close-margin);
 transition:
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
 `),A(`round`,`
 padding: 0 calc(var(--n-height) / 3);
 border-radius: calc(var(--n-height) / 2);
 `,[_(`icon`,`
 margin: 0 4px 0 calc((var(--n-height) - 8px) / -2);
 `),_(`avatar`,`
 margin: 0 6px 0 calc((var(--n-height) - 8px) / -2);
 `),A(`closable`,`
 padding: 0 calc(var(--n-height) / 4) 0 calc(var(--n-height) / 3);
 `)]),A(`icon, avatar`,[A(`round`,`
 padding: 0 calc(var(--n-height) / 3) 0 calc(var(--n-height) / 2);
 `)]),A(`disabled`,`
 cursor: not-allowed !important;
 opacity: var(--n-opacity-disabled);
 `),A(`checkable`,`
 cursor: pointer;
 box-shadow: none;
 color: var(--n-text-color-checkable);
 background-color: var(--n-color-checkable);
 `,[n(`disabled`,[o(`&:hover`,`background-color: var(--n-color-hover-checkable);`,[n(`checked`,`color: var(--n-text-color-hover-checkable);`)]),o(`&:active`,`background-color: var(--n-color-pressed-checkable);`,[n(`checked`,`color: var(--n-text-color-pressed-checkable);`)])]),A(`checked`,`
 color: var(--n-text-color-checked);
 background-color: var(--n-color-checked);
 `,[n(`disabled`,[o(`&:hover`,`background-color: var(--n-color-checked-hover);`),o(`&:active`,`background-color: var(--n-color-checked-pressed);`)])])])]);const I=Object.assign(Object.assign(Object.assign({},T.props),P),{bordered:{type:Boolean,default:void 0},checked:Boolean,checkable:Boolean,strong:Boolean,triggerClickOnClose:Boolean,onClose:[Array,Function],onMouseenter:Function,onMouseleave:Function,"onUpdate:checked":Function,onUpdateChecked:Function,internalCloseFocusable:{type:Boolean,default:!0},internalCloseIsButtonTag:{type:Boolean,default:!0},onCheckedChange:Function}),L=k(`n-tag`);var R=C({name:`Tag`,props:I,slots:Object,setup(e){let n=p(null),{mergedBorderedRef:i,mergedClsPrefixRef:a,inlineThemeDisabled:o,mergedRtlRef:s}=r(e),c=T(`Tag`,`-tag`,F,N,e,a);v(L,{roundRef:h(e,`round`)});function l(){if(!e.disabled&&e.checkable){let{checked:t,onCheckedChange:n,onUpdateChecked:r,"onUpdate:checked":i}=e;r&&r(!t),i&&i(!t),n&&n(!t)}}function u(n){if(e.triggerClickOnClose||n.stopPropagation(),!e.disabled){let{onClose:r}=e;r&&t(r,n)}}let d={setTextContent(e){let{value:t}=n;t&&(t.textContent=e)}},m=w(`Tag`,s,a),g=O(()=>{let{type:t,size:n,color:{color:r,textColor:a}={}}=e,{common:{cubicBezierEaseInOut:o},self:{padding:s,closeMargin:l,borderRadius:u,opacityDisabled:d,textColorCheckable:p,textColorHoverCheckable:m,textColorPressedCheckable:h,textColorChecked:g,colorCheckable:_,colorHoverCheckable:v,colorPressedCheckable:b,colorChecked:x,colorCheckedHover:S,colorCheckedPressed:C,closeBorderRadius:w,fontWeightStrong:T,[y(`colorBordered`,t)]:E,[y(`closeSize`,n)]:D,[y(`closeIconSize`,n)]:O,[y(`fontSize`,n)]:k,[y(`height`,n)]:A,[y(`color`,t)]:j,[y(`textColor`,t)]:M,[y(`border`,t)]:N,[y(`closeIconColor`,t)]:P,[y(`closeIconColorHover`,t)]:F,[y(`closeIconColorPressed`,t)]:I,[y(`closeColorHover`,t)]:L,[y(`closeColorPressed`,t)]:R}}=c.value,z=f(l);return{"--n-font-weight-strong":T,"--n-avatar-size-override":`calc(${A} - 8px)`,"--n-bezier":o,"--n-border-radius":u,"--n-border":N,"--n-close-icon-size":O,"--n-close-color-pressed":R,"--n-close-color-hover":L,"--n-close-border-radius":w,"--n-close-icon-color":P,"--n-close-icon-color-hover":F,"--n-close-icon-color-pressed":I,"--n-close-icon-color-disabled":P,"--n-close-margin-top":z.top,"--n-close-margin-right":z.right,"--n-close-margin-bottom":z.bottom,"--n-close-margin-left":z.left,"--n-close-size":D,"--n-color":r||(i.value?E:j),"--n-color-checkable":_,"--n-color-checked":x,"--n-color-checked-hover":S,"--n-color-checked-pressed":C,"--n-color-hover-checkable":v,"--n-color-pressed-checkable":b,"--n-font-size":k,"--n-height":A,"--n-opacity-disabled":d,"--n-padding":s,"--n-text-color":a||M,"--n-text-color-checkable":p,"--n-text-color-checked":g,"--n-text-color-hover-checkable":m,"--n-text-color-pressed-checkable":h}}),_=o?j(`tag`,O(()=>{let t=``,{type:n,size:r,color:{color:a,textColor:o}={}}=e;return t+=n[0],t+=r[0],a&&(t+=`a${S(a)}`),o&&(t+=`b${S(o)}`),i.value&&(t+=`c`),t}),g,e):void 0;return Object.assign(Object.assign({},d),{rtlEnabled:m,mergedClsPrefix:a,contentRef:n,mergedBordered:i,handleClick:l,handleCloseClick:u,cssVars:o?void 0:g,themeClass:_?.themeClass,onRender:_?.onRender})},render(){var e;let{mergedClsPrefix:t,rtlEnabled:n,closable:r,color:{borderColor:i}={},round:a,onRender:o,$slots:s}=this;o?.();let c=d(s.avatar,e=>e&&x(`div`,{class:`${t}-tag__avatar`},e)),l=d(s.icon,e=>e&&x(`div`,{class:`${t}-tag__icon`},e));return x(`div`,{class:[`${t}-tag`,this.themeClass,{[`${t}-tag--rtl`]:n,[`${t}-tag--strong`]:this.strong,[`${t}-tag--disabled`]:this.disabled,[`${t}-tag--checkable`]:this.checkable,[`${t}-tag--checked`]:this.checkable&&this.checked,[`${t}-tag--round`]:a,[`${t}-tag--avatar`]:c,[`${t}-tag--icon`]:l,[`${t}-tag--closable`]:r}],style:this.cssVars,onClick:this.handleClick,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},l||c,x(`span`,{class:`${t}-tag__content`,ref:`contentRef`},(e=this.$slots).default?.call(e)),!this.checkable&&r?x(b,{clsPrefix:t,class:`${t}-tag__close`,disabled:this.disabled,onClick:this.handleCloseClick,focusable:this.internalCloseFocusable,round:a,isButtonTag:this.internalCloseIsButtonTag,absolute:!0}):null,!this.checkable&&this.mergedBordered?x(`div`,{class:`${t}-tag__border`,style:{borderColor:i}}):null)}}),z=o([o(`@keyframes spin-rotate`,`
 from {
 transform: rotate(0);
 }
 to {
 transform: rotate(360deg);
 }
 `),s(`spin-container`,`
 position: relative;
 `,[s(`spin-body`,`
 position: absolute;
 top: 50%;
 left: 50%;
 transform: translateX(-50%) translateY(-50%);
 `,[D()])]),s(`spin-body`,`
 display: inline-flex;
 align-items: center;
 justify-content: center;
 flex-direction: column;
 `),s(`spin`,`
 display: inline-flex;
 height: var(--n-size);
 width: var(--n-size);
 font-size: var(--n-size);
 color: var(--n-color);
 `,[A(`rotate`,`
 animation: spin-rotate 2s linear infinite;
 `)]),s(`spin-description`,`
 display: inline-block;
 font-size: var(--n-font-size);
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 margin-top: 8px;
 `),s(`spin-content`,`
 opacity: 1;
 transition: opacity .3s var(--n-bezier);
 pointer-events: all;
 `,[A(`spinning`,`
 user-select: none;
 -webkit-user-select: none;
 pointer-events: none;
 opacity: var(--n-opacity-spinning);
 `)])]),B={small:20,medium:18,large:16},V=C({name:`Spin`,props:Object.assign(Object.assign({},T.props),{contentClass:String,contentStyle:[Object,String],description:String,stroke:String,size:{type:[String,Number],default:`medium`},show:{type:Boolean,default:!0},strokeWidth:Number,rotate:{type:Boolean,default:!0},spinning:{type:Boolean,validator:()=>!0,default:void 0},delay:Number}),slots:Object,setup(t){let{mergedClsPrefixRef:n,inlineThemeDisabled:i}=r(t),o=T(`Spin`,`-spin`,z,E,t,n),s=O(()=>{let{size:e}=t,{common:{cubicBezierEaseInOut:n},self:r}=o.value,{opacitySpinning:i,color:a,textColor:s}=r,c=typeof e==`number`?m(e):r[y(`size`,e)];return{"--n-bezier":n,"--n-opacity-spinning":i,"--n-size":c,"--n-color":a,"--n-text-color":s}}),c=i?j(`spin`,O(()=>{let{size:e}=t;return typeof e==`number`?String(e):e[0]}),s,t):void 0,l=e(t,[`spinning`,`show`]),u=p(!1);return a(e=>{let n;if(l.value){let{delay:r}=t;if(r){n=window.setTimeout(()=>{u.value=!0},r),e(()=>{clearTimeout(n)});return}}u.value=l.value}),{mergedClsPrefix:n,active:u,mergedStrokeWidth:O(()=>{let{strokeWidth:e}=t;if(e!==void 0)return e;let{size:n}=t;return B[typeof n==`number`?`medium`:n]}),cssVars:i?void 0:s,themeClass:c?.themeClass,onRender:c?.onRender}},render(){var e;let{$slots:t,mergedClsPrefix:n,description:r}=this,i=t.icon&&this.rotate,a=(r||t.description)&&x(`div`,{class:`${n}-spin-description`},r||t.description?.call(t)),o=t.icon?x(`div`,{class:[`${n}-spin-body`,this.themeClass]},x(`div`,{class:[`${n}-spin`,i&&`${n}-spin--rotate`],style:t.default?``:this.cssVars},t.icon()),a):x(`div`,{class:[`${n}-spin-body`,this.themeClass]},x(c,{clsPrefix:n,style:t.default?``:this.cssVars,stroke:this.stroke,"stroke-width":this.mergedStrokeWidth,class:`${n}-spin`}),a);return(e=this.onRender)==null||e.call(this),t.default?x(`div`,{class:[`${n}-spin-container`,this.themeClass],style:this.cssVars},x(`div`,{class:[`${n}-spin-content`,this.active&&`${n}-spin-content--spinning`,this.contentClass],style:this.contentStyle},t),x(u,{name:`fade-in-transition`},{default:()=>this.active?o:null})):o}});export{R as n,L as r,V as t};