import{a as e,c as t,d as n,i as r,l as i,o as a,p as o,s,t as c,u as l}from"./Popover-6tp3lNMs.js";import{s as u}from"./Space-DSfbK4ZR.js";import{t as d}from"./use-compitable-C1bpwaTZ.js";import{a as f,s as p}from"./FormItem-BceLBxxW.js";import{Q as m,Z as h,nt as g}from"./date-C85Pz325.js";import{n as _,t as v}from"./create-C0ev3hp9.js";import{n as y}from"./Spin-CstuVNQr.js";import{$t as b,An as x,B as S,Bn as C,Bt as ee,Cn as w,D as te,Dr as T,Er as E,Fn as D,Ht as O,In as k,J as A,Kn as j,Kt as ne,L as M,Mn as N,Mr as P,Nr as F,Pn as re,Rn as I,Rt as ie,Sr as L,U as R,V as z,Vn as B,Wt as ae,Zn as V,_r as oe,bn as se,dn as H,dr as U,fr as W,it as ce,kr as le,ln as ue,lr as G,lt as de,mr as K,ot as fe,qn as q,qt as J,rn as pe,sn as Y,tr as X,wr as me,yr as he,zn as Z,zt as ge}from"./index-CpWi_OZp.js";var Q=`v-hidden`,_e=e(`[v-hidden]`,{display:`none!important`}),ve=G({name:`Overflow`,props:{getCounter:Function,getTail:Function,updateCounter:Function,onUpdateCount:Function,onUpdateOverflow:Function},setup(e,{slots:t}){let n=P(null),r=P(null);function i(i){let{value:a}=n,{getCounter:o,getTail:s}=e,c;if(c=o===void 0?r.value:o(),!a||!c)return;c.hasAttribute(Q)&&c.removeAttribute(Q);let{children:l}=a;if(i.showAllItemsBeforeCalculate)for(let e of l)e.hasAttribute(Q)&&e.removeAttribute(Q);let u=a.offsetWidth,d=[],f=t.tail?s?.():null,p=f?f.offsetWidth:0,m=!1,h=a.children.length-(t.tail?1:0);for(let t=0;t<h-1;++t){if(t<0)continue;let n=l[t];if(m){n.hasAttribute(Q)||n.setAttribute(Q,``);continue}else n.hasAttribute(Q)&&n.removeAttribute(Q);let r=n.offsetWidth;if(p+=r,d[t]=r,p>u){let{updateCounter:n}=e;for(let r=t;r>=0;--r){let i=h-1-r;n===void 0?c.textContent=`${i}`:n(i);let a=c.offsetWidth;if(p-=d[r],p+a<=u||r===0){m=!0,t=r-1,f&&(t===-1?(f.style.maxWidth=`${u-a}px`,f.style.boxSizing=`border-box`):f.style.maxWidth=``);let{onUpdateCount:n}=e;n&&n(i);break}}}}let{onUpdateOverflow:g}=e;m?g!==void 0&&g(!0):(g!==void 0&&g(!1),c.setAttribute(Q,``))}let o=ue();return _e.mount({id:`vueuc/overflow`,head:!0,anchorMetaName:a,ssr:o}),he(()=>i({showAllItemsBeforeCalculate:!1})),{selfRef:n,counterRef:r,sync:i}},render(){let{$slots:e}=this;return K(()=>this.sync({showAllItemsBeforeCalculate:!1})),U(`div`,{class:`v-overflow`,ref:`selfRef`},[me(e,`default`),e.counter?e.counter():U(`span`,{style:{display:`inline-block`},ref:`counterRef`}),e.tail?e.tail():null])}});function ye(e,t){t&&(he(()=>{let{value:n}=e;n&&Y.registerHandler(n,t)}),E(e,(e,t)=>{t&&Y.unregisterHandler(t)},{deep:!1}),oe(()=>{let{value:t}=e;t&&Y.unregisterHandler(t)}))}function be(e){switch(typeof e){case`string`:return e||void 0;case`number`:return String(e);default:return}}function $(e){let t=e.filter(e=>e!==void 0);if(t.length!==0)return t.length===1?t[0]:t=>{e.forEach(e=>{e&&e(t)})}}var xe=G({name:`Checkmark`,render(){return U(`svg`,{xmlns:`http://www.w3.org/2000/svg`,viewBox:`0 0 16 16`},U(`g`,{fill:`none`},U(`path`,{d:`M14.046 3.486a.75.75 0 0 1-.032 1.06l-7.93 7.474a.85.85 0 0 1-1.188-.022l-2.68-2.72a.75.75 0 1 1 1.068-1.053l2.234 2.267l7.468-7.038a.75.75 0 0 1 1.06.032z`,fill:`currentColor`})))}}),Se=G({name:`NBaseSelectGroupHeader`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){let{renderLabelRef:e,renderOptionRef:t,labelFieldRef:r,nodePropsRef:i}=W(n);return{labelField:r,nodeProps:i,renderLabel:e,renderOption:t}},render(){let{clsPrefix:e,renderLabel:t,renderOption:n,nodeProps:r,tmNode:{rawNode:i}}=this,a=r?.(i),o=t?t(i,!1):J(i[this.labelField],i,!1),s=U(`div`,Object.assign({},a,{class:[`${e}-base-select-group-header`,a?.class]}),o);return i.render?i.render({node:s,option:i}):n?n({node:s,option:i,selected:!1}):s}});function Ce(e,t){return U(j,{name:`fade-in-scale-up-transition`},{default:()=>e?U(ce,{clsPrefix:t,class:`${t}-base-select-option__check`},{default:()=>U(xe)}):null})}var we=G({name:`NBaseSelectOption`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(e){let{valueRef:t,pendingTmNodeRef:r,multipleRef:i,valueSetRef:a,renderLabelRef:o,renderOptionRef:s,labelFieldRef:c,valueFieldRef:l,showCheckmarkRef:u,nodePropsRef:d,handleOptionClick:f,handleOptionMouseEnter:p}=W(n),m=w(()=>{let{value:t}=r;return t?e.tmNode.key===t.key:!1});function h(t){let{tmNode:n}=e;n.disabled||f(t,n)}function g(t){let{tmNode:n}=e;n.disabled||p(t,n)}function _(t){let{tmNode:n}=e,{value:r}=m;n.disabled||r||p(t,n)}return{multiple:i,isGrouped:w(()=>{let{tmNode:t}=e,{parent:n}=t;return n&&n.rawNode.type===`group`}),showCheckmark:u,nodeProps:d,isPending:m,isSelected:w(()=>{let{value:n}=t,{value:r}=i;if(n===null)return!1;let o=e.tmNode.rawNode[l.value];if(r){let{value:e}=a;return e.has(o)}else return n===o}),labelField:c,renderLabel:o,renderOption:s,handleMouseMove:_,handleMouseEnter:g,handleClick:h}},render(){let{clsPrefix:e,tmNode:{rawNode:t},isSelected:n,isPending:r,isGrouped:i,showCheckmark:a,nodeProps:o,renderOption:s,renderLabel:c,handleClick:l,handleMouseEnter:u,handleMouseMove:d}=this,f=Ce(n,e),p=c?[c(t,n),a&&f]:[J(t[this.labelField],t,n),a&&f],m=o?.(t),h=U(`div`,Object.assign({},m,{class:[`${e}-base-select-option`,t.class,m?.class,{[`${e}-base-select-option--disabled`]:t.disabled,[`${e}-base-select-option--selected`]:n,[`${e}-base-select-option--grouped`]:i,[`${e}-base-select-option--pending`]:r,[`${e}-base-select-option--show-checkmark`]:a}],style:[m?.style||``,t.style||``],onClick:$([l,m?.onClick]),onMouseenter:$([u,m?.onMouseenter]),onMousemove:$([d,m?.onMousemove])}),U(`div`,{class:`${e}-base-select-option__content`},p));return t.render?t.render({node:h,option:t,selected:n}):s?s({node:h,option:t,selected:n}):h}}),Te=k(`base-select-menu`,`
 line-height: 1.5;
 outline: none;
 z-index: 0;
 position: relative;
 border-radius: var(--n-border-radius);
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
 background-color: var(--n-color);
`,[k(`scrollbar`,`
 max-height: var(--n-height);
 `),k(`virtual-list`,`
 max-height: var(--n-height);
 `),k(`base-select-option`,`
 min-height: var(--n-option-height);
 font-size: var(--n-option-font-size);
 display: flex;
 align-items: center;
 `,[I(`content`,`
 z-index: 1;
 white-space: nowrap;
 text-overflow: ellipsis;
 overflow: hidden;
 `)]),k(`base-select-group-header`,`
 min-height: var(--n-option-height);
 font-size: .93em;
 display: flex;
 align-items: center;
 `),k(`base-select-menu-option-wrapper`,`
 position: relative;
 width: 100%;
 `),I(`loading, empty`,`
 display: flex;
 padding: 12px 32px;
 flex: 1;
 justify-content: center;
 `),I(`loading`,`
 color: var(--n-loading-color);
 font-size: var(--n-loading-size);
 `),I(`header`,`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-bottom: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),I(`action`,`
 padding: 8px var(--n-option-padding-left);
 font-size: var(--n-option-font-size);
 transition: 
 color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 border-top: 1px solid var(--n-action-divider-color);
 color: var(--n-action-text-color);
 `),k(`base-select-group-header`,`
 position: relative;
 cursor: default;
 padding: var(--n-option-padding);
 color: var(--n-group-header-text-color);
 `),k(`base-select-option`,`
 cursor: pointer;
 position: relative;
 padding: var(--n-option-padding);
 transition:
 color .3s var(--n-bezier),
 opacity .3s var(--n-bezier);
 box-sizing: border-box;
 color: var(--n-option-text-color);
 opacity: 1;
 `,[Z(`show-checkmark`,`
 padding-right: calc(var(--n-option-padding-right) + 20px);
 `),D(`&::before`,`
 content: "";
 position: absolute;
 left: 4px;
 right: 4px;
 top: 0;
 bottom: 0;
 border-radius: var(--n-border-radius);
 transition: background-color .3s var(--n-bezier);
 `),D(`&:active`,`
 color: var(--n-option-text-color-pressed);
 `),Z(`grouped`,`
 padding-left: calc(var(--n-option-padding-left) * 1.5);
 `),Z(`pending`,[D(`&::before`,`
 background-color: var(--n-option-color-pending);
 `)]),Z(`selected`,`
 color: var(--n-option-text-color-active);
 `,[D(`&::before`,`
 background-color: var(--n-option-color-active);
 `),Z(`pending`,[D(`&::before`,`
 background-color: var(--n-option-color-active-pending);
 `)])]),Z(`disabled`,`
 cursor: not-allowed;
 `,[C(`selected`,`
 color: var(--n-option-text-color-disabled);
 `),Z(`selected`,`
 opacity: var(--n-option-opacity-disabled);
 `)]),I(`check`,`
 font-size: 16px;
 position: absolute;
 right: calc(var(--n-option-padding-right) - 4px);
 top: calc(50% - 7px);
 color: var(--n-option-check-color);
 transition: color .3s var(--n-bezier);
 `,[S({enterScale:`0.5`})])])]),Ee=G({name:`InternalSelectMenu`,props:Object.assign(Object.assign({},fe.props),{clsPrefix:{type:String,required:!0},scrollable:{type:Boolean,default:!0},treeMate:{type:Object,required:!0},multiple:Boolean,size:{type:String,default:`medium`},value:{type:[String,Number,Array],default:null},autoPending:Boolean,virtualScroll:{type:Boolean,default:!0},show:{type:Boolean,default:!0},labelField:{type:String,default:`label`},valueField:{type:String,default:`value`},loading:Boolean,focusable:Boolean,renderLabel:Function,renderOption:Function,nodeProps:Function,showCheckmark:{type:Boolean,default:!0},onMousedown:Function,onScroll:Function,onFocus:Function,onBlur:Function,onKeyup:Function,onKeydown:Function,onTabOut:Function,onMouseenter:Function,onMouseleave:Function,onResize:Function,resetMenuOnOptionsChange:{type:Boolean,default:!0},inlineThemeDisabled:Boolean,onToggle:Function}),setup(e){let{mergedClsPrefixRef:t,mergedRtlRef:r}=ee(e),i=de(`InternalSelectMenu`,r,t),a=fe(`InternalSelectMenu`,`-internal-select-menu`,Te,z,e,F(e,`clsPrefix`)),s=P(null),c=P(null),u=P(null),d=X(()=>e.treeMate.getFlattenedNodes()),f=X(()=>_(d.value)),p=P(null);function m(){let{treeMate:t}=e,n=null,{value:r}=e;r===null?n=t.getFirstAvailableNode():(n=e.multiple?t.getNode((r||[])[(r||[]).length-1]):t.getNode(r),(!n||n.disabled)&&(n=t.getFirstAvailableNode())),I(n||null)}function h(){let{value:t}=p;t&&!e.treeMate.getNode(t.key)&&(p.value=null)}let g;E(()=>e.show,t=>{t?g=E(()=>e.treeMate,()=>{e.resetMenuOnOptionsChange?(e.autoPending?m():h(),K(ie)):h()},{immediate:!0}):g?.()},{immediate:!0}),oe(()=>{g?.()});let v=X(()=>x(a.value.self[B(`optionHeight`,e.size)])),y=X(()=>N(a.value.self[B(`padding`,e.size)])),b=X(()=>e.multiple&&Array.isArray(e.value)?new Set(e.value):new Set),S=X(()=>{let e=d.value;return e&&e.length===0});function C(t){let{onToggle:n}=e;n&&n(t)}function w(t){let{onScroll:n}=e;n&&n(t)}function te(e){var t;(t=u.value)==null||t.sync(),w(e)}function T(){var e;(e=u.value)==null||e.sync()}function D(){let{value:e}=p;return e||null}function O(e,t){t.disabled||I(t,!1)}function k(e,t){t.disabled||C(t)}function A(t){var n;o(t,`action`)||(n=e.onKeyup)==null||n.call(e,t)}function j(t){var n;o(t,`action`)||(n=e.onKeydown)==null||n.call(e,t)}function ne(t){var n;(n=e.onMousedown)==null||n.call(e,t),!e.focusable&&t.preventDefault()}function M(){let{value:e}=p;e&&I(e.getNext({loop:!0}),!0)}function re(){let{value:e}=p;e&&I(e.getPrev({loop:!0}),!0)}function I(e,t=!1){p.value=e,t&&ie()}function ie(){var t,n;let r=p.value;if(!r)return;let i=f.value(r.key);i!==null&&(e.virtualScroll?(t=c.value)==null||t.scrollTo({index:i}):(n=u.value)==null||n.scrollTo({index:i,elSize:v.value}))}function R(t){var n;s.value?.contains(t.target)&&((n=e.onFocus)==null||n.call(e,t))}function ae(t){var n;s.value?.contains(t.relatedTarget)||(n=e.onBlur)==null||n.call(e,t)}L(n,{handleOptionMouseEnter:O,handleOptionClick:k,valueSetRef:b,pendingTmNodeRef:p,nodePropsRef:F(e,`nodeProps`),showCheckmarkRef:F(e,`showCheckmark`),multipleRef:F(e,`multiple`),valueRef:F(e,`value`),renderLabelRef:F(e,`renderLabel`),renderOptionRef:F(e,`renderOption`),labelFieldRef:F(e,`labelField`),valueFieldRef:F(e,`valueField`)}),L(l,s),he(()=>{let{value:e}=u;e&&e.sync()});let V=X(()=>{let{size:t}=e,{common:{cubicBezierEaseInOut:n},self:{height:r,borderRadius:i,color:o,groupHeaderTextColor:s,actionDividerColor:c,optionTextColorPressed:l,optionTextColor:u,optionTextColorDisabled:d,optionTextColorActive:f,optionOpacityDisabled:p,optionCheckColor:m,actionTextColor:h,optionColorPending:g,optionColorActive:_,loadingColor:v,loadingSize:y,optionColorActivePending:b,[B(`optionFontSize`,t)]:x,[B(`optionHeight`,t)]:S,[B(`optionPadding`,t)]:C}}=a.value;return{"--n-height":r,"--n-action-divider-color":c,"--n-action-text-color":h,"--n-bezier":n,"--n-border-radius":i,"--n-color":o,"--n-option-font-size":x,"--n-group-header-text-color":s,"--n-option-check-color":m,"--n-option-color-pending":g,"--n-option-color-active":_,"--n-option-color-active-pending":b,"--n-option-height":S,"--n-option-opacity-disabled":p,"--n-option-text-color":u,"--n-option-text-color-active":f,"--n-option-text-color-disabled":d,"--n-option-text-color-pressed":l,"--n-option-padding":C,"--n-option-padding-left":N(C,`left`),"--n-option-padding-right":N(C,`right`),"--n-loading-color":v,"--n-loading-size":y}}),{inlineThemeDisabled:se}=e,H=se?ge(`internal-select-menu`,X(()=>e.size[0]),V,e):void 0,U={selfRef:s,next:M,prev:re,getPendingTmNode:D};return ye(s,e.onResize),Object.assign({mergedTheme:a,mergedClsPrefix:t,rtlEnabled:i,virtualListRef:c,scrollbarRef:u,itemSize:v,padding:y,flattenedNodes:d,empty:S,virtualListContainer(){let{value:e}=c;return e?.listElRef},virtualListContent(){let{value:e}=c;return e?.itemsElRef},doScroll:w,handleFocusin:R,handleFocusout:ae,handleKeyUp:A,handleKeyDown:j,handleMouseDown:ne,handleVirtualListResize:T,handleVirtualListScroll:te,cssVars:se?void 0:V,themeClass:H?.themeClass,onRender:H?.onRender},U)},render(){let{$slots:e,virtualScroll:t,clsPrefix:n,mergedTheme:r,themeClass:i,onRender:a}=this;return a?.(),U(`div`,{ref:`selfRef`,tabindex:this.focusable?0:-1,class:[`${n}-base-select-menu`,this.rtlEnabled&&`${n}-base-select-menu--rtl`,i,this.multiple&&`${n}-base-select-menu--multiple`],style:this.cssVars,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onKeyup:this.handleKeyUp,onKeydown:this.handleKeyDown,onMousedown:this.handleMouseDown,onMouseenter:this.onMouseenter,onMouseleave:this.onMouseleave},ne(e.header,e=>e&&U(`div`,{class:`${n}-base-select-menu__header`,"data-header":!0,key:`header`},e)),this.loading?U(`div`,{class:`${n}-base-select-menu__loading`},U(A,{clsPrefix:n,strokeWidth:20})):this.empty?U(`div`,{class:`${n}-base-select-menu__empty`,"data-empty":!0},ae(e.empty,()=>[U(h,{theme:r.peers.Empty,themeOverrides:r.peerOverrides.Empty,size:this.size})])):U(R,{ref:`scrollbarRef`,theme:r.peers.Scrollbar,themeOverrides:r.peerOverrides.Scrollbar,scrollable:this.scrollable,container:t?this.virtualListContainer:void 0,content:t?this.virtualListContent:void 0,onScroll:t?void 0:this.doScroll},{default:()=>t?U(g,{ref:`virtualListRef`,class:`${n}-virtual-list`,items:this.flattenedNodes,itemSize:this.itemSize,showScrollbar:!1,paddingTop:this.padding.top,paddingBottom:this.padding.bottom,onResize:this.handleVirtualListResize,onScroll:this.handleVirtualListScroll,itemResizable:!0},{default:({item:e})=>e.isGroup?U(Se,{key:e.key,clsPrefix:n,tmNode:e}):e.ignored?null:U(we,{clsPrefix:n,key:e.key,tmNode:e})}):U(`div`,{class:`${n}-base-select-menu-option-wrapper`,style:{paddingTop:this.padding.top,paddingBottom:this.padding.bottom}},this.flattenedNodes.map(e=>e.isGroup?U(Se,{key:e.key,clsPrefix:n,tmNode:e}):U(we,{clsPrefix:n,key:e.key,tmNode:e})))}),ne(e.action,e=>e&&[U(`div`,{class:`${n}-base-select-menu__action`,"data-action":!0,key:`action`},e),U(m,{onFocus:this.onTabOut,key:`focus-detector`})]))}}),De=D([k(`base-selection`,`
 --n-padding-single: var(--n-padding-single-top) var(--n-padding-single-right) var(--n-padding-single-bottom) var(--n-padding-single-left);
 --n-padding-multiple: var(--n-padding-multiple-top) var(--n-padding-multiple-right) var(--n-padding-multiple-bottom) var(--n-padding-multiple-left);
 position: relative;
 z-index: auto;
 box-shadow: none;
 width: 100%;
 max-width: 100%;
 display: inline-block;
 vertical-align: bottom;
 border-radius: var(--n-border-radius);
 min-height: var(--n-height);
 line-height: 1.5;
 font-size: var(--n-font-size);
 `,[k(`base-loading`,`
 color: var(--n-loading-color);
 `),k(`base-selection-tags`,`min-height: var(--n-height);`),I(`border, state-border`,`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 pointer-events: none;
 border: var(--n-border);
 border-radius: inherit;
 transition:
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),I(`state-border`,`
 z-index: 1;
 border-color: #0000;
 `),k(`base-suffix`,`
 cursor: pointer;
 position: absolute;
 top: 50%;
 transform: translateY(-50%);
 right: 10px;
 `,[I(`arrow`,`
 font-size: var(--n-arrow-size);
 color: var(--n-arrow-color);
 transition: color .3s var(--n-bezier);
 `)]),k(`base-selection-overlay`,`
 display: flex;
 align-items: center;
 white-space: nowrap;
 pointer-events: none;
 position: absolute;
 top: 0;
 right: 0;
 bottom: 0;
 left: 0;
 padding: var(--n-padding-single);
 transition: color .3s var(--n-bezier);
 `,[I(`wrapper`,`
 flex-basis: 0;
 flex-grow: 1;
 overflow: hidden;
 text-overflow: ellipsis;
 `)]),k(`base-selection-placeholder`,`
 color: var(--n-placeholder-color);
 `,[I(`inner`,`
 max-width: 100%;
 overflow: hidden;
 `)]),k(`base-selection-tags`,`
 cursor: pointer;
 outline: none;
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 display: flex;
 padding: var(--n-padding-multiple);
 flex-wrap: wrap;
 align-items: center;
 width: 100%;
 vertical-align: bottom;
 background-color: var(--n-color);
 border-radius: inherit;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `),k(`base-selection-label`,`
 height: var(--n-height);
 display: inline-flex;
 width: 100%;
 vertical-align: bottom;
 cursor: pointer;
 outline: none;
 z-index: auto;
 box-sizing: border-box;
 position: relative;
 transition:
 color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 border-radius: inherit;
 background-color: var(--n-color);
 align-items: center;
 `,[k(`base-selection-input`,`
 font-size: inherit;
 line-height: inherit;
 outline: none;
 cursor: pointer;
 box-sizing: border-box;
 border:none;
 width: 100%;
 padding: var(--n-padding-single);
 background-color: #0000;
 color: var(--n-text-color);
 transition: color .3s var(--n-bezier);
 caret-color: var(--n-caret-color);
 `,[I(`content`,`
 text-overflow: ellipsis;
 overflow: hidden;
 white-space: nowrap; 
 `)]),I(`render-label`,`
 color: var(--n-text-color);
 `)]),C(`disabled`,[D(`&:hover`,[I(`state-border`,`
 box-shadow: var(--n-box-shadow-hover);
 border: var(--n-border-hover);
 `)]),Z(`focus`,[I(`state-border`,`
 box-shadow: var(--n-box-shadow-focus);
 border: var(--n-border-focus);
 `)]),Z(`active`,[I(`state-border`,`
 box-shadow: var(--n-box-shadow-active);
 border: var(--n-border-active);
 `),k(`base-selection-label`,`background-color: var(--n-color-active);`),k(`base-selection-tags`,`background-color: var(--n-color-active);`)])]),Z(`disabled`,`cursor: not-allowed;`,[I(`arrow`,`
 color: var(--n-arrow-color-disabled);
 `),k(`base-selection-label`,`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `,[k(`base-selection-input`,`
 cursor: not-allowed;
 color: var(--n-text-color-disabled);
 `),I(`render-label`,`
 color: var(--n-text-color-disabled);
 `)]),k(`base-selection-tags`,`
 cursor: not-allowed;
 background-color: var(--n-color-disabled);
 `),k(`base-selection-placeholder`,`
 cursor: not-allowed;
 color: var(--n-placeholder-color-disabled);
 `)]),k(`base-selection-input-tag`,`
 height: calc(var(--n-height) - 6px);
 line-height: calc(var(--n-height) - 6px);
 outline: none;
 display: none;
 position: relative;
 margin-bottom: 3px;
 max-width: 100%;
 vertical-align: bottom;
 `,[I(`input`,`
 font-size: inherit;
 font-family: inherit;
 min-width: 1px;
 padding: 0;
 background-color: #0000;
 outline: none;
 border: none;
 max-width: 100%;
 overflow: hidden;
 width: 1em;
 line-height: inherit;
 cursor: pointer;
 color: var(--n-text-color);
 caret-color: var(--n-caret-color);
 `),I(`mirror`,`
 position: absolute;
 left: 0;
 top: 0;
 white-space: pre;
 visibility: hidden;
 user-select: none;
 -webkit-user-select: none;
 opacity: 0;
 `)]),[`warning`,`error`].map(e=>Z(`${e}-status`,[I(`state-border`,`border: var(--n-border-${e});`),C(`disabled`,[D(`&:hover`,[I(`state-border`,`
 box-shadow: var(--n-box-shadow-hover-${e});
 border: var(--n-border-hover-${e});
 `)]),Z(`active`,[I(`state-border`,`
 box-shadow: var(--n-box-shadow-active-${e});
 border: var(--n-border-active-${e});
 `),k(`base-selection-label`,`background-color: var(--n-color-active-${e});`),k(`base-selection-tags`,`background-color: var(--n-color-active-${e});`)]),Z(`focus`,[I(`state-border`,`
 box-shadow: var(--n-box-shadow-focus-${e});
 border: var(--n-border-focus-${e});
 `)])])]))]),k(`base-selection-popover`,`
 margin-bottom: -3px;
 display: flex;
 flex-wrap: wrap;
 margin-right: -8px;
 `),k(`base-selection-tag-wrapper`,`
 max-width: 100%;
 display: inline-flex;
 padding: 0 7px 3px 0;
 `,[D(`&:last-child`,`padding-right: 0;`),k(`tag`,`
 font-size: 14px;
 max-width: 100%;
 `,[I(`content`,`
 line-height: 1.25;
 text-overflow: ellipsis;
 overflow: hidden;
 `)])])]),Oe=G({name:`InternalSelection`,props:Object.assign(Object.assign({},fe.props),{clsPrefix:{type:String,required:!0},bordered:{type:Boolean,default:void 0},active:Boolean,pattern:{type:String,default:``},placeholder:String,selectedOption:{type:Object,default:null},selectedOptions:{type:Array,default:null},labelField:{type:String,default:`label`},valueField:{type:String,default:`value`},multiple:Boolean,filterable:Boolean,clearable:Boolean,disabled:Boolean,size:{type:String,default:`medium`},loading:Boolean,autofocus:Boolean,showArrow:{type:Boolean,default:!0},inputProps:Object,focused:Boolean,renderTag:Function,onKeydown:Function,onClick:Function,onBlur:Function,onFocus:Function,onDeleteOption:Function,maxTagCount:[String,Number],ellipsisTagPopoverProps:Object,onClear:Function,onPatternInput:Function,onPatternFocus:Function,onPatternBlur:Function,renderLabel:Function,status:String,inlineThemeDisabled:Boolean,ignoreComposition:{type:Boolean,default:!0},onResize:Function}),setup(e){let{mergedClsPrefixRef:t,mergedRtlRef:n}=ee(e),r=de(`InternalSelection`,n,t),i=P(null),a=P(null),o=P(null),s=P(null),c=P(null),l=P(null),u=P(null),d=P(null),f=P(null),p=P(null),m=P(!1),h=P(!1),g=P(!1),_=fe(`InternalSelection`,`-internal-selection`,De,M,e,F(e,`clsPrefix`)),v=X(()=>e.clearable&&!e.disabled&&(g.value||e.active)),y=X(()=>e.selectedOption?e.renderTag?e.renderTag({option:e.selectedOption,handleClose:()=>{}}):e.renderLabel?e.renderLabel(e.selectedOption,!0):J(e.selectedOption[e.labelField],e.selectedOption,!0):e.placeholder),b=X(()=>{let t=e.selectedOption;if(t)return t[e.labelField]}),x=X(()=>e.multiple?!!(Array.isArray(e.selectedOptions)&&e.selectedOptions.length):e.selectedOption!==null);function S(){var t;let{value:n}=i;if(n){let{value:r}=a;r&&(r.style.width=`${n.offsetWidth}px`,e.maxTagCount!==`responsive`&&((t=f.value)==null||t.sync({showAllItemsBeforeCalculate:!1})))}}function C(){let{value:e}=p;e&&(e.style.display=`none`)}function w(){let{value:e}=p;e&&(e.style.display=`inline-block`)}E(F(e,`active`),e=>{e||C()}),E(F(e,`pattern`),()=>{e.multiple&&K(S)});function te(t){let{onFocus:n}=e;n&&n(t)}function D(t){let{onBlur:n}=e;n&&n(t)}function O(t){let{onDeleteOption:n}=e;n&&n(t)}function k(t){let{onClear:n}=e;n&&n(t)}function A(t){let{onPatternInput:n}=e;n&&n(t)}function j(e){(!e.relatedTarget||!o.value?.contains(e.relatedTarget))&&te(e)}function ne(e){o.value?.contains(e.relatedTarget)||D(e)}function re(e){k(e)}function I(){g.value=!0}function ie(){g.value=!1}function L(t){!e.active||!e.filterable||t.target!==a.value&&t.preventDefault()}function R(e){O(e)}let z=P(!1);function ae(t){if(t.key===`Backspace`&&!z.value&&!e.pattern.length){let{selectedOptions:t}=e;t?.length&&R(t[t.length-1])}}let V=null;function oe(t){let{value:n}=i;n&&(n.textContent=t.target.value,S()),e.ignoreComposition&&z.value?V=t:A(t)}function se(){z.value=!0}function H(){z.value=!1,e.ignoreComposition&&A(V),V=null}function U(t){var n;h.value=!0,(n=e.onPatternFocus)==null||n.call(e,t)}function W(t){var n;h.value=!1,(n=e.onPatternBlur)==null||n.call(e,t)}function ce(){var t,n;if(e.filterable)h.value=!1,(t=l.value)==null||t.blur(),(n=a.value)==null||n.blur();else if(e.multiple){let{value:e}=s;e?.blur()}else{let{value:e}=c;e?.blur()}}function le(){var t,n,r;e.filterable?(h.value=!1,(t=l.value)==null||t.focus()):e.multiple?(n=s.value)==null||n.focus():(r=c.value)==null||r.focus()}function ue(){let{value:e}=a;e&&(w(),e.focus())}function G(){let{value:e}=a;e&&e.blur()}function q(e){let{value:t}=u;t&&t.setTextContent(`+${e}`)}function pe(){let{value:e}=d;return e}function Y(){return a.value}let me=null;function Z(){me!==null&&window.clearTimeout(me)}function Q(){e.active||(Z(),me=window.setTimeout(()=>{x.value&&(m.value=!0)},100))}function _e(){Z()}function ve(e){e||(Z(),m.value=!1)}E(x,e=>{e||(m.value=!1)}),he(()=>{T(()=>{let t=l.value;t&&(e.disabled?t.removeAttribute(`tabindex`):t.tabIndex=h.value?-1:0)})}),ye(o,e.onResize);let{inlineThemeDisabled:be}=e,$=X(()=>{let{size:t}=e,{common:{cubicBezierEaseInOut:n},self:{fontWeight:r,borderRadius:i,color:a,placeholderColor:o,textColor:s,paddingSingle:c,paddingMultiple:l,caretColor:u,colorDisabled:d,textColorDisabled:f,placeholderColorDisabled:p,colorActive:m,boxShadowFocus:h,boxShadowActive:g,boxShadowHover:v,border:y,borderFocus:b,borderHover:x,borderActive:S,arrowColor:C,arrowColorDisabled:ee,loadingColor:w,colorActiveWarning:te,boxShadowFocusWarning:T,boxShadowActiveWarning:E,boxShadowHoverWarning:D,borderWarning:O,borderFocusWarning:k,borderHoverWarning:A,borderActiveWarning:j,colorActiveError:ne,boxShadowFocusError:M,boxShadowActiveError:P,boxShadowHoverError:F,borderError:re,borderFocusError:I,borderHoverError:ie,borderActiveError:L,clearColor:R,clearColorHover:z,clearColorPressed:ae,clearSize:V,arrowSize:oe,[B(`height`,t)]:se,[B(`fontSize`,t)]:H}}=_.value,U=N(c),W=N(l);return{"--n-bezier":n,"--n-border":y,"--n-border-active":S,"--n-border-focus":b,"--n-border-hover":x,"--n-border-radius":i,"--n-box-shadow-active":g,"--n-box-shadow-focus":h,"--n-box-shadow-hover":v,"--n-caret-color":u,"--n-color":a,"--n-color-active":m,"--n-color-disabled":d,"--n-font-size":H,"--n-height":se,"--n-padding-single-top":U.top,"--n-padding-multiple-top":W.top,"--n-padding-single-right":U.right,"--n-padding-multiple-right":W.right,"--n-padding-single-left":U.left,"--n-padding-multiple-left":W.left,"--n-padding-single-bottom":U.bottom,"--n-padding-multiple-bottom":W.bottom,"--n-placeholder-color":o,"--n-placeholder-color-disabled":p,"--n-text-color":s,"--n-text-color-disabled":f,"--n-arrow-color":C,"--n-arrow-color-disabled":ee,"--n-loading-color":w,"--n-color-active-warning":te,"--n-box-shadow-focus-warning":T,"--n-box-shadow-active-warning":E,"--n-box-shadow-hover-warning":D,"--n-border-warning":O,"--n-border-focus-warning":k,"--n-border-hover-warning":A,"--n-border-active-warning":j,"--n-color-active-error":ne,"--n-box-shadow-focus-error":M,"--n-box-shadow-active-error":P,"--n-box-shadow-hover-error":F,"--n-border-error":re,"--n-border-focus-error":I,"--n-border-hover-error":ie,"--n-border-active-error":L,"--n-clear-size":V,"--n-clear-color":R,"--n-clear-color-hover":z,"--n-clear-color-pressed":ae,"--n-arrow-size":oe,"--n-font-weight":r}}),xe=be?ge(`internal-selection`,X(()=>e.size[0]),$,e):void 0;return{mergedTheme:_,mergedClearable:v,mergedClsPrefix:t,rtlEnabled:r,patternInputFocused:h,filterablePlaceholder:y,label:b,selected:x,showTagsPanel:m,isComposing:z,counterRef:u,counterWrapperRef:d,patternInputMirrorRef:i,patternInputRef:a,selfRef:o,multipleElRef:s,singleElRef:c,patternInputWrapperRef:l,overflowRef:f,inputTagElRef:p,handleMouseDown:L,handleFocusin:j,handleClear:re,handleMouseEnter:I,handleMouseLeave:ie,handleDeleteOption:R,handlePatternKeyDown:ae,handlePatternInputInput:oe,handlePatternInputBlur:W,handlePatternInputFocus:U,handleMouseEnterCounter:Q,handleMouseLeaveCounter:_e,handleFocusout:ne,handleCompositionEnd:H,handleCompositionStart:se,onPopoverUpdateShow:ve,focus:le,focusInput:ue,blur:ce,blurInput:G,updateCounter:q,getCounter:pe,getTail:Y,renderLabel:e.renderLabel,cssVars:be?void 0:$,themeClass:xe?.themeClass,onRender:xe?.onRender}},render(){let{status:e,multiple:t,size:n,disabled:r,filterable:i,maxTagCount:a,bordered:o,clsPrefix:s,ellipsisTagPopoverProps:l,onRender:u,renderTag:d,renderLabel:p}=this;u?.();let m=a===`responsive`,h=typeof a==`number`,g=m||h,_=U(O,null,{default:()=>U(f,{clsPrefix:s,loading:this.loading,showArrow:this.showArrow,showClear:this.mergedClearable&&this.selected,onClear:this.handleClear},{default:()=>{var e;return(e=this.$slots).arrow?.call(e)}})}),v;if(t){let{labelField:e}=this,t=t=>U(`div`,{class:`${s}-base-selection-tag-wrapper`,key:t.value},d?d({option:t,handleClose:()=>{this.handleDeleteOption(t)}}):U(y,{size:n,closable:!t.disabled,disabled:r,onClose:()=>{this.handleDeleteOption(t)},internalCloseIsButtonTag:!1,internalCloseFocusable:!1},{default:()=>p?p(t,!0):J(t[e],t,!0)})),o=()=>(h?this.selectedOptions.slice(0,a):this.selectedOptions).map(t),u=i?U(`div`,{class:`${s}-base-selection-input-tag`,ref:`inputTagElRef`,key:`__input-tag__`},U(`input`,Object.assign({},this.inputProps,{ref:`patternInputRef`,tabindex:-1,disabled:r,value:this.pattern,autofocus:this.autofocus,class:`${s}-base-selection-input-tag__input`,onBlur:this.handlePatternInputBlur,onFocus:this.handlePatternInputFocus,onKeydown:this.handlePatternKeyDown,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd})),U(`span`,{ref:`patternInputMirrorRef`,class:`${s}-base-selection-input-tag__mirror`},this.pattern)):null,f=m?()=>U(`div`,{class:`${s}-base-selection-tag-wrapper`,ref:`counterWrapperRef`},U(y,{size:n,ref:`counterRef`,onMouseenter:this.handleMouseEnterCounter,onMouseleave:this.handleMouseLeaveCounter,disabled:r})):void 0,b;if(h){let e=this.selectedOptions.length-a;e>0&&(b=U(`div`,{class:`${s}-base-selection-tag-wrapper`,key:`__counter__`},U(y,{size:n,ref:`counterRef`,onMouseenter:this.handleMouseEnterCounter,disabled:r},{default:()=>`+${e}`})))}let x=m?i?U(ve,{ref:`overflowRef`,updateCounter:this.updateCounter,getCounter:this.getCounter,getTail:this.getTail,style:{width:`100%`,display:`flex`,overflow:`hidden`}},{default:o,counter:f,tail:()=>u}):U(ve,{ref:`overflowRef`,updateCounter:this.updateCounter,getCounter:this.getCounter,style:{width:`100%`,display:`flex`,overflow:`hidden`}},{default:o,counter:f}):h&&b?o().concat(b):o(),S=g?()=>U(`div`,{class:`${s}-base-selection-popover`},m?o():this.selectedOptions.map(t)):void 0,C=g?Object.assign({show:this.showTagsPanel,trigger:`hover`,overlap:!0,placement:`top`,width:`trigger`,onUpdateShow:this.onPopoverUpdateShow,theme:this.mergedTheme.peers.Popover,themeOverrides:this.mergedTheme.peerOverrides.Popover},l):null,ee=!this.selected&&(!this.active||!this.pattern&&!this.isComposing)?U(`div`,{class:`${s}-base-selection-placeholder ${s}-base-selection-overlay`},U(`div`,{class:`${s}-base-selection-placeholder__inner`},this.placeholder)):null,w=i?U(`div`,{ref:`patternInputWrapperRef`,class:`${s}-base-selection-tags`},x,m?null:u,_):U(`div`,{ref:`multipleElRef`,class:`${s}-base-selection-tags`,tabindex:r?void 0:0},x,_);v=U(V,null,g?U(c,Object.assign({},C,{scrollable:!0,style:`max-height: calc(var(--v-target-height) * 6.6);`}),{trigger:()=>w,default:S}):w,ee)}else if(i){let e=this.pattern||this.isComposing,t=this.active?!e:!this.selected,n=this.active?!1:this.selected;v=U(`div`,{ref:`patternInputWrapperRef`,class:`${s}-base-selection-label`,title:this.patternInputFocused?void 0:be(this.label)},U(`input`,Object.assign({},this.inputProps,{ref:`patternInputRef`,class:`${s}-base-selection-input`,value:this.active?this.pattern:``,placeholder:``,readonly:r,disabled:r,tabindex:-1,autofocus:this.autofocus,onFocus:this.handlePatternInputFocus,onBlur:this.handlePatternInputBlur,onInput:this.handlePatternInputInput,onCompositionstart:this.handleCompositionStart,onCompositionend:this.handleCompositionEnd})),n?U(`div`,{class:`${s}-base-selection-label__render-label ${s}-base-selection-overlay`,key:`input`},U(`div`,{class:`${s}-base-selection-overlay__wrapper`},d?d({option:this.selectedOption,handleClose:()=>{}}):p?p(this.selectedOption,!0):J(this.label,this.selectedOption,!0))):null,t?U(`div`,{class:`${s}-base-selection-placeholder ${s}-base-selection-overlay`,key:`placeholder`},U(`div`,{class:`${s}-base-selection-overlay__wrapper`},this.filterablePlaceholder)):null,_)}else v=U(`div`,{ref:`singleElRef`,class:`${s}-base-selection-label`,tabindex:this.disabled?void 0:0},this.label===void 0?U(`div`,{class:`${s}-base-selection-placeholder ${s}-base-selection-overlay`,key:`placeholder`},U(`div`,{class:`${s}-base-selection-placeholder__inner`},this.placeholder)):U(`div`,{class:`${s}-base-selection-input`,title:be(this.label),key:`input`},U(`div`,{class:`${s}-base-selection-input__content`},d?d({option:this.selectedOption,handleClose:()=>{}}):p?p(this.selectedOption,!0):J(this.label,this.selectedOption,!0))),_);return U(`div`,{ref:`selfRef`,class:[`${s}-base-selection`,this.rtlEnabled&&`${s}-base-selection--rtl`,this.themeClass,e&&`${s}-base-selection--${e}-status`,{[`${s}-base-selection--active`]:this.active,[`${s}-base-selection--selected`]:this.selected||this.active&&this.pattern,[`${s}-base-selection--disabled`]:this.disabled,[`${s}-base-selection--multiple`]:this.multiple,[`${s}-base-selection--focus`]:this.focused}],style:this.cssVars,onClick:this.onClick,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onKeydown:this.onKeydown,onFocusin:this.handleFocusin,onFocusout:this.handleFocusout,onMousedown:this.handleMouseDown},v,o?U(`div`,{class:`${s}-base-selection__border`}):null,o?U(`div`,{class:`${s}-base-selection__state-border`}):null)}});function ke(e){return e.type===`group`}function Ae(e){return e.type===`ignored`}function je(e,t){try{return!!(1+t.toString().toLowerCase().indexOf(e.trim().toLowerCase()))}catch{return!1}}function Me(e,t){return{getIsGroup:ke,getIgnored:Ae,getKey(t){return ke(t)?t.name||t.key||`key-required`:t[e]},getChildren(e){return e[t]}}}function Ne(e,t,n,r){if(!t)return e;function i(e){if(!Array.isArray(e))return[];let a=[];for(let o of e)if(ke(o)){let e=i(o[r]);e.length&&a.push(Object.assign({},o,{[r]:e}))}else if(Ae(o))continue;else t(n,o)&&a.push(o);return a}return i(e)}function Pe(e,t,n){let r=new Map;return e.forEach(e=>{ke(e)?e[n].forEach(e=>{r.set(e[t],e)}):r.set(e[t],e)}),r}var Fe=D([k(`select`,`
 z-index: auto;
 outline: none;
 width: 100%;
 position: relative;
 font-weight: var(--n-font-weight);
 `),k(`select-menu`,`
 margin: 4px 0;
 box-shadow: var(--n-menu-box-shadow);
 `,[S({originalTransition:`background-color .3s var(--n-bezier), box-shadow .3s var(--n-bezier)`})])]),Ie=G({name:`Select`,props:Object.assign(Object.assign({},fe.props),{to:i.propTo,bordered:{type:Boolean,default:void 0},clearable:Boolean,clearFilterAfterSelect:{type:Boolean,default:!0},options:{type:Array,default:()=>[]},defaultValue:{type:[String,Number,Array],default:null},keyboard:{type:Boolean,default:!0},value:[String,Number,Array],placeholder:String,menuProps:Object,multiple:Boolean,size:String,menuSize:{type:String},filterable:Boolean,disabled:{type:Boolean,default:void 0},remote:Boolean,loading:Boolean,filter:Function,placement:{type:String,default:`bottom-start`},widthMode:{type:String,default:`trigger`},tag:Boolean,onCreate:Function,fallbackOption:{type:[Function,Boolean],default:void 0},show:{type:Boolean,default:void 0},showArrow:{type:Boolean,default:!0},maxTagCount:[Number,String],ellipsisTagPopoverProps:Object,consistentMenuWidth:{type:Boolean,default:!0},virtualScroll:{type:Boolean,default:!0},labelField:{type:String,default:`label`},valueField:{type:String,default:`value`},childrenField:{type:String,default:`children`},renderLabel:Function,renderOption:Function,renderTag:Function,"onUpdate:value":[Function,Array],inputProps:Object,nodeProps:Function,ignoreComposition:{type:Boolean,default:!0},showOnFocus:Boolean,onUpdateValue:[Function,Array],onBlur:[Function,Array],onClear:[Function,Array],onFocus:[Function,Array],onScroll:[Function,Array],onSearch:[Function,Array],onUpdateShow:[Function,Array],"onUpdate:show":[Function,Array],displayDirective:{type:String,default:`show`},resetMenuOnOptionsChange:{type:Boolean,default:!0},status:String,showCheckmark:{type:Boolean,default:!0},onChange:[Function,Array],items:Array}),slots:Object,setup(e){let{mergedClsPrefixRef:t,mergedBorderedRef:n,namespaceRef:r,inlineThemeDisabled:a}=ee(e),s=fe(`Select`,`-select`,Fe,te,e,t),c=P(e.defaultValue),l=u(F(e,`value`),c),f=P(!1),m=P(``),h=d(e,[`items`,`options`]),g=P([]),_=P([]),y=X(()=>_.value.concat(g.value).concat(h.value)),x=X(()=>{let{filter:t}=e;if(t)return t;let{labelField:n,valueField:r}=e;return(e,t)=>{if(!t)return!1;let i=t[n];if(typeof i==`string`)return je(e,i);let a=t[r];return typeof a==`string`?je(e,a):typeof a==`number`?je(e,String(a)):!1}}),S=X(()=>{if(e.remote)return h.value;{let{value:t}=y,{value:n}=m;return!n.length||!e.filterable?t:Ne(t,x.value,n,e.childrenField)}}),C=X(()=>{let{valueField:t,childrenField:n}=e,r=Me(t,n);return v(S.value,r)}),w=X(()=>Pe(y.value,e.valueField,e.childrenField)),T=P(!1),D=u(F(e,`show`),T),O=P(null),k=P(null),A=P(null),{localeRef:j}=p(`Select`),ne=X(()=>e.placeholder??j.value.placeholder),M=[],N=P(new Map),I=X(()=>{let{fallbackOption:t}=e;if(t===void 0){let{labelField:t,valueField:n}=e;return e=>({[t]:String(e),[n]:e})}return t===!1?!1:e=>Object.assign(t(e),{value:e})});function L(t){let n=e.remote,{value:r}=N,{value:i}=w,{value:a}=I,o=[];return t.forEach(e=>{if(i.has(e))o.push(i.get(e));else if(n&&r.has(e))o.push(r.get(e));else if(a){let t=a(e);t&&o.push(t)}}),o}let R=X(()=>{if(e.multiple){let{value:e}=l;return Array.isArray(e)?L(e):[]}return null}),z=X(()=>{let{value:t}=l;return!e.multiple&&!Array.isArray(t)?t===null?null:L([t])[0]||null:null}),B=ie(e),{mergedSizeRef:ae,mergedDisabledRef:V,mergedStatusRef:oe}=B;function H(t,n){let{onChange:r,"onUpdate:value":i,onUpdateValue:a}=e,{nTriggerFormChange:o,nTriggerFormInput:s}=B;r&&b(r,t,n),a&&b(a,t,n),i&&b(i,t,n),c.value=t,o(),s()}function U(t){let{onBlur:n}=e,{nTriggerFormBlur:r}=B;n&&b(n,t),r()}function W(){let{onClear:t}=e;t&&b(t)}function ce(t){let{onFocus:n,showOnFocus:r}=e,{nTriggerFormFocus:i}=B;n&&b(n,t),i(),r&&K()}function le(t){let{onSearch:n}=e;n&&b(n,t)}function ue(t){let{onScroll:n}=e;n&&b(n,t)}function G(){var t;let{remote:n,multiple:r}=e;if(n){let{value:n}=N;if(r){let{valueField:r}=e;(t=R.value)==null||t.forEach(e=>{n.set(e[r],e)})}else{let t=z.value;t&&n.set(t[e.valueField],t)}}}function de(t){let{onUpdateShow:n,"onUpdate:show":r}=e;n&&b(n,t),r&&b(r,t),T.value=t}function K(){V.value||(de(!0),T.value=!0,e.filterable&&Ie())}function q(){de(!1)}function J(){m.value=``,_.value=M}let Y=P(!1);function me(){e.filterable&&(Y.value=!0)}function he(){e.filterable&&(Y.value=!1,D.value||J())}function Z(){V.value||(D.value?e.filterable?Ie():q():K())}function Q(e){(A.value?.selfRef)?.contains(e.relatedTarget)||(f.value=!1,U(e),q())}function _e(e){ce(e),f.value=!0}function ve(){f.value=!0}function ye(e){O.value?.$el.contains(e.relatedTarget)||(f.value=!1,U(e),q())}function be(){var e;(e=O.value)==null||e.focus(),q()}function $(e){D.value&&(O.value?.$el.contains(re(e))||q())}function xe(t){if(!Array.isArray(t))return[];if(I.value)return Array.from(t);{let{remote:n}=e,{value:r}=w;if(n){let{value:e}=N;return t.filter(t=>r.has(t)||e.has(t))}else return t.filter(e=>r.has(e))}}function Se(e){Ce(e.rawNode)}function Ce(t){if(V.value)return;let{tag:n,remote:r,clearFilterAfterSelect:i,valueField:a}=e;if(n&&!r){let{value:e}=_,t=e[0]||null;if(t){let e=g.value;e.length?e.push(t):g.value=[t],_.value=M}}if(r&&N.value.set(t[a],t),e.multiple){let e=xe(l.value),o=e.findIndex(e=>e===t[a]);if(~o){if(e.splice(o,1),n&&!r){let e=we(t[a]);~e&&(g.value.splice(e,1),i&&(m.value=``))}}else e.push(t[a]),i&&(m.value=``);H(e,L(e))}else{if(n&&!r){let e=we(t[a]);~e?g.value=[g.value[e]]:g.value=M}Ae(),q(),H(t[a],t)}}function we(t){return g.value.findIndex(n=>n[e.valueField]===t)}function Te(t){D.value||K();let{value:n}=t.target;m.value=n;let{tag:r,remote:i}=e;if(le(n),r&&!i){if(!n){_.value=M;return}let{onCreate:t}=e,r=t?t(n):{[e.labelField]:n,[e.valueField]:n},{valueField:i,labelField:a}=e;h.value.some(e=>e[i]===r[i]||e[a]===r[a])||g.value.some(e=>e[i]===r[i]||e[a]===r[a])?_.value=M:_.value=[r]}}function Ee(t){t.stopPropagation();let{multiple:n}=e;!n&&e.filterable&&q(),W(),n?H([],[]):H(null,null)}function De(e){!o(e,`action`)&&!o(e,`empty`)&&!o(e,`header`)&&e.preventDefault()}function Oe(e){ue(e)}function ke(t){var n,r,i;if(!e.keyboard){t.preventDefault();return}switch(t.key){case` `:if(e.filterable)break;t.preventDefault();case`Enter`:if(!O.value?.isComposing){if(D.value){let t=A.value?.getPendingTmNode();t?Se(t):e.filterable||(q(),Ae())}else if(K(),e.tag&&Y.value){let t=_.value[0];if(t){let n=t[e.valueField],{value:r}=l;e.multiple&&Array.isArray(r)&&r.includes(n)||Ce(t)}}}t.preventDefault();break;case`ArrowUp`:if(t.preventDefault(),e.loading)return;D.value&&((n=A.value)==null||n.prev());break;case`ArrowDown`:if(t.preventDefault(),e.loading)return;D.value?(r=A.value)==null||r.next():K();break;case`Escape`:D.value&&(pe(t),q()),(i=O.value)==null||i.focus();break}}function Ae(){var e;(e=O.value)==null||e.focus()}function Ie(){var e;(e=O.value)==null||e.focusInput()}function Le(){var e;D.value&&((e=k.value)==null||e.syncPosition())}G(),E(F(e,`options`),G);let Re={focus:()=>{var e;(e=O.value)==null||e.focus()},focusInput:()=>{var e;(e=O.value)==null||e.focusInput()},blur:()=>{var e;(e=O.value)==null||e.blur()},blurInput:()=>{var e;(e=O.value)==null||e.blurInput()}},ze=X(()=>{let{self:{menuBoxShadow:e}}=s.value;return{"--n-menu-box-shadow":e}}),Be=a?ge(`select`,void 0,ze,e):void 0;return Object.assign(Object.assign({},Re),{mergedStatus:oe,mergedClsPrefix:t,mergedBordered:n,namespace:r,treeMate:C,isMounted:se(),triggerRef:O,menuRef:A,pattern:m,uncontrolledShow:T,mergedShow:D,adjustedTo:i(e),uncontrolledValue:c,mergedValue:l,followerRef:k,localizedPlaceholder:ne,selectedOption:z,selectedOptions:R,mergedSize:ae,mergedDisabled:V,focused:f,activeWithoutMenuOpen:Y,inlineThemeDisabled:a,onTriggerInputFocus:me,onTriggerInputBlur:he,handleTriggerOrMenuResize:Le,handleMenuFocus:ve,handleMenuBlur:ye,handleMenuTabOut:be,handleTriggerClick:Z,handleToggle:Se,handleDeleteOption:Ce,handlePatternInput:Te,handleClear:Ee,handleTriggerBlur:Q,handleTriggerFocus:_e,handleKeydown:ke,handleMenuAfterLeave:J,handleMenuClickOutside:$,handleMenuScroll:Oe,handleMenuKeydown:ke,handleMenuMousedown:De,mergedTheme:s,cssVars:a?void 0:ze,themeClass:Be?.themeClass,onRender:Be?.onRender})},render(){return U(`div`,{class:`${this.mergedClsPrefix}-select`},U(t,null,{default:()=>[U(s,null,{default:()=>U(Oe,{ref:`triggerRef`,inlineThemeDisabled:this.inlineThemeDisabled,status:this.mergedStatus,inputProps:this.inputProps,clsPrefix:this.mergedClsPrefix,showArrow:this.showArrow,maxTagCount:this.maxTagCount,ellipsisTagPopoverProps:this.ellipsisTagPopoverProps,bordered:this.mergedBordered,active:this.activeWithoutMenuOpen||this.mergedShow,pattern:this.pattern,placeholder:this.localizedPlaceholder,selectedOption:this.selectedOption,selectedOptions:this.selectedOptions,multiple:this.multiple,renderTag:this.renderTag,renderLabel:this.renderLabel,filterable:this.filterable,clearable:this.clearable,disabled:this.mergedDisabled,size:this.mergedSize,theme:this.mergedTheme.peers.InternalSelection,labelField:this.labelField,valueField:this.valueField,themeOverrides:this.mergedTheme.peerOverrides.InternalSelection,loading:this.loading,focused:this.focused,onClick:this.handleTriggerClick,onDeleteOption:this.handleDeleteOption,onPatternInput:this.handlePatternInput,onClear:this.handleClear,onBlur:this.handleTriggerBlur,onFocus:this.handleTriggerFocus,onKeydown:this.handleKeydown,onPatternBlur:this.onTriggerInputBlur,onPatternFocus:this.onTriggerInputFocus,onResize:this.handleTriggerOrMenuResize,ignoreComposition:this.ignoreComposition},{arrow:()=>{var e;return[(e=this.$slots).arrow?.call(e)]}})}),U(r,{ref:`followerRef`,show:this.mergedShow,to:this.adjustedTo,teleportDisabled:this.adjustedTo===i.tdkey,containerClass:this.namespace,width:this.consistentMenuWidth?`target`:void 0,minWidth:`target`,placement:this.placement},{default:()=>U(j,{name:`fade-in-scale-up-transition`,appear:this.isMounted,onAfterLeave:this.handleMenuAfterLeave},{default:()=>{var e;return this.mergedShow||this.displayDirective===`show`?((e=this.onRender)==null||e.call(this),le(U(Ee,Object.assign({},this.menuProps,{ref:`menuRef`,onResize:this.handleTriggerOrMenuResize,inlineThemeDisabled:this.inlineThemeDisabled,virtualScroll:this.consistentMenuWidth&&this.virtualScroll,class:[`${this.mergedClsPrefix}-select-menu`,this.themeClass,this.menuProps?.class],clsPrefix:this.mergedClsPrefix,focusable:!0,labelField:this.labelField,valueField:this.valueField,autoPending:!0,nodeProps:this.nodeProps,theme:this.mergedTheme.peers.InternalSelectMenu,themeOverrides:this.mergedTheme.peerOverrides.InternalSelectMenu,treeMate:this.treeMate,multiple:this.multiple,size:this.menuSize,renderOption:this.renderOption,renderLabel:this.renderLabel,value:this.mergedValue,style:[this.menuProps?.style,this.cssVars],onToggle:this.handleToggle,onScroll:this.handleMenuScroll,onFocus:this.handleMenuFocus,onBlur:this.handleMenuBlur,onKeydown:this.handleMenuKeydown,onTabOut:this.handleMenuTabOut,onMousedown:this.handleMenuMousedown,show:this.mergedShow,showCheckmark:this.showCheckmark,resetMenuOnOptionsChange:this.resetMenuOnOptionsChange}),{empty:()=>{var e;return[(e=this.$slots).empty?.call(e)]},header:()=>{var e;return[(e=this.$slots).header?.call(e)]},action:()=>{var e;return[(e=this.$slots).action?.call(e)]}}),this.displayDirective===`show`?[[q,this.mergedShow],[H,this.handleMenuClickOutside,void 0,{capture:!0}]]:[[H,this.handleMenuClickOutside,void 0,{capture:!0}]])):null}})})]}))}});export{$ as i,Me as n,Ee as r,Ie as t};