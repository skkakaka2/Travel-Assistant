import{t as e}from"./Space-Doh6zwh0.js";import"./use-compitable-Bh-IqaE9.js";import{i as t,n,r,t as i}from"./FormItem-DB50B4Ks.js";import{t as a}from"./_plugin-vue_export-helper-H2tEXVNX.js";import{r as o,t as s}from"./Spin-DeQQFz26.js";import{i as c,n as l,r as u,t as d}from"./BaiduMapPicker-Djk3LC02.js";import{t as f}from"./Icon-DS2OP600.js";import{A as p,Bn as m,Bt as h,Dr as g,Er as _,Fn as v,Fr as y,Hn as b,In as x,Kt as S,Lr as C,Mr as w,N as T,Or as E,Rn as D,Un as O,Vn as k,Wt as A,Zn as j,_r as M,ar as N,cr as P,dr as F,fr as I,in as ee,ir as te,k as L,lr as R,n as z,nr as B,on as V,ot as H,s as U,sr as W,tr as G,v as K,xr as q,yn as J,yr as Y,zn as X,zt as Z}from"./index-cT_2Xr_W.js";import{n as Q,t as ne}from"./LocationOutline-B5tb6n4e.js";const re=J(`n-avatar-group`);var $=x(`avatar`,`
 width: var(--n-merged-size);
 height: var(--n-merged-size);
 color: #FFF;
 font-size: var(--n-font-size);
 display: inline-flex;
 position: relative;
 overflow: hidden;
 text-align: center;
 border: var(--n-border);
 border-radius: var(--n-border-radius);
 --n-merged-color: var(--n-color);
 background-color: var(--n-merged-color);
 transition:
 border-color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[b(v(`&`,`--n-merged-color: var(--n-color-modal);`)),O(v(`&`,`--n-merged-color: var(--n-color-popover);`)),v(`img`,`
 width: 100%;
 height: 100%;
 `),D(`text`,`
 white-space: nowrap;
 display: inline-block;
 position: absolute;
 left: 50%;
 top: 50%;
 `),x(`icon`,`
 vertical-align: bottom;
 font-size: calc(var(--n-merged-size) - 6px);
 `),D(`text`,`line-height: 1.25`)]),ie=R({name:`Avatar`,props:Object.assign(Object.assign({},H.props),{size:[String,Number],src:String,circle:{type:Boolean,default:void 0},objectFit:String,round:{type:Boolean,default:void 0},bordered:{type:Boolean,default:void 0},onError:Function,fallbackSrc:String,intersectionObserverOptions:Object,lazy:Boolean,onLoad:Function,renderPlaceholder:Function,renderFallback:Function,imgProps:Object,color:String}),slots:Object,setup(e){let{mergedClsPrefixRef:t,inlineThemeDisabled:n}=h(e),r=w(!1),i=null,a=w(null),s=w(null),c=()=>{let{value:e}=a;if(e&&(i===null||i!==e.innerHTML)){i=e.innerHTML;let{value:t}=s;if(t){let{offsetWidth:n,offsetHeight:r}=t,{offsetWidth:i,offsetHeight:a}=e,o=.9,s=Math.min(n/i*o,r/a*o,1);e.style.transform=`translateX(-50%) translateY(-50%) scale(${s})`}}},l=I(re,null),d=G(()=>{let{size:t}=e;if(t)return t;let{size:n}=l||{};return n||`medium`}),f=H(`Avatar`,`-avatar`,$,T,e,t),p=I(o,null),m=G(()=>{if(l)return!0;let{round:t,circle:n}=e;return t!==void 0||n!==void 0?t||n:p?p.roundRef.value:!1}),v=G(()=>l?!0:e.bordered||!1),y=G(()=>{let t=d.value,n=m.value,r=v.value,{color:i}=e,{self:{borderRadius:a,fontSize:o,color:s,border:c,colorModal:l,colorPopover:u},common:{cubicBezierEaseInOut:p}}=f.value,h;return h=typeof t==`number`?`${t}px`:f.value.self[k(`height`,t)],{"--n-font-size":o,"--n-border":r?c:`none`,"--n-border-radius":n?`50%`:a,"--n-color":i||s,"--n-color-modal":i||l,"--n-color-popover":i||u,"--n-bezier":p,"--n-merged-size":`var(--n-avatar-size-override, ${h})`}}),b=n?Z(`avatar`,G(()=>{let t=d.value,n=m.value,r=v.value,{color:i}=e,a=``;return t&&(typeof t==`number`?a+=`a${t}`:a+=t[0]),n&&(a+=`b`),r&&(a+=`c`),i&&(a+=ee(i)),a}),y,e):void 0,x=w(!e.lazy);Y(()=>{if(e.lazy&&e.intersectionObserverOptions){let t,n=g(()=>{t?.(),t=void 0,e.lazy&&(t=u(s.value,e.intersectionObserverOptions,x))});M(()=>{n(),t?.()})}}),_(()=>e.src||e.imgProps?.src,()=>{r.value=!1});let S=w(!e.lazy);return{textRef:a,selfRef:s,mergedRoundRef:m,mergedClsPrefix:t,fitTextTransform:c,cssVars:n?void 0:y,themeClass:b?.themeClass,onRender:b?.onRender,hasLoadError:r,shouldStartLoading:x,loaded:S,mergedOnError:t=>{if(!x.value)return;r.value=!0;let{onError:n,imgProps:{onError:i}={}}=e;n?.(t),i?.(t)},mergedOnLoad:t=>{let{onLoad:n,imgProps:{onLoad:r}={}}=e;n?.(t),r?.(t),S.value=!0}}},render(){var e;let{$slots:t,src:n,mergedClsPrefix:r,lazy:i,onRender:a,loaded:o,hasLoadError:s,imgProps:l={}}=this;a?.();let u,d=!o&&!s&&(this.renderPlaceholder?this.renderPlaceholder():(e=this.$slots).placeholder?.call(e));return u=this.hasLoadError?this.renderFallback?this.renderFallback():A(t.fallback,()=>[F(`img`,{src:this.fallbackSrc,style:{objectFit:this.objectFit}})]):S(t.default,e=>{if(e)return F(V,{onResize:this.fitTextTransform},{default:()=>F(`span`,{ref:`textRef`,class:`${r}-avatar__text`},e)});if(n||l.src){let e=this.src||l.src;return F(`img`,Object.assign(Object.assign({},l),{loading:c&&!this.intersectionObserverOptions&&i?`lazy`:`eager`,src:i&&this.intersectionObserverOptions?this.shouldStartLoading?e:void 0:e,"data-image-src":e,onLoad:this.mergedOnLoad,onError:this.mergedOnError,style:[l.style||``,{objectFit:this.objectFit},d?{height:`0`,width:`0`,visibility:`hidden`,position:`absolute`}:``]}))}}),F(`span`,{ref:`selfRef`,class:[`${r}-avatar`,this.themeClass],style:this.cssVars},u,i&&d)}}),ae=x(`divider`,`
 position: relative;
 display: flex;
 width: 100%;
 box-sizing: border-box;
 font-size: 16px;
 color: var(--n-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
`,[m(`vertical`,`
 margin-top: 24px;
 margin-bottom: 24px;
 `,[m(`no-title`,`
 display: flex;
 align-items: center;
 `)]),D(`title`,`
 display: flex;
 align-items: center;
 margin-left: 12px;
 margin-right: 12px;
 white-space: nowrap;
 font-weight: var(--n-font-weight);
 `),X(`title-position-left`,[D(`line`,[X(`left`,{width:`28px`})])]),X(`title-position-right`,[D(`line`,[X(`right`,{width:`28px`})])]),X(`dashed`,[D(`line`,`
 background-color: #0000;
 height: 0px;
 width: 100%;
 border-style: dashed;
 border-width: 1px 0 0;
 `)]),X(`vertical`,`
 display: inline-block;
 height: 1em;
 margin: 0 8px;
 vertical-align: middle;
 width: 1px;
 `),D(`line`,`
 border: none;
 transition: background-color .3s var(--n-bezier), border-color .3s var(--n-bezier);
 height: 1px;
 width: 100%;
 margin: 0;
 `),m(`dashed`,[D(`line`,{backgroundColor:`var(--n-color)`})]),X(`dashed`,[D(`line`,{borderColor:`var(--n-color)`})]),X(`vertical`,{backgroundColor:`var(--n-color)`})]),oe=R({name:`Divider`,props:Object.assign(Object.assign({},H.props),{titlePlacement:{type:String,default:`center`},dashed:Boolean,vertical:Boolean}),setup(e){let{mergedClsPrefixRef:t,inlineThemeDisabled:n}=h(e),r=H(`Divider`,`-divider`,ae,K,e,t),i=G(()=>{let{common:{cubicBezierEaseInOut:e},self:{color:t,textColor:n,fontWeight:i}}=r.value;return{"--n-bezier":e,"--n-color":t,"--n-text-color":n,"--n-font-weight":i}}),a=n?Z(`divider`,void 0,i,e):void 0;return{mergedClsPrefix:t,cssVars:n?void 0:i,themeClass:a?.themeClass,onRender:a?.onRender}},render(){var e;let{$slots:t,titlePlacement:n,vertical:r,dashed:i,cssVars:a,mergedClsPrefix:o}=this;return(e=this.onRender)==null||e.call(this),F(`div`,{role:`separator`,class:[`${o}-divider`,this.themeClass,{[`${o}-divider--vertical`]:r,[`${o}-divider--no-title`]:!t.default,[`${o}-divider--dashed`]:i,[`${o}-divider--title-position-${n}`]:t.default&&n}],style:a},r?null:F(`div`,{class:`${o}-divider__line ${o}-divider__line--left`}),!r&&t.default?F(j,null,F(`div`,{class:`${o}-divider__title`},this.$slots),F(`div`,{class:`${o}-divider__line ${o}-divider__line--right`})):null)}}),se={class:`settings-page`},ce={class:`page-header`},le={key:0,class:`settings-content`},ue={class:`user-profile`},de={class:`user-details`},fe={class:`user-name`},pe={class:`user-email`},me={class:`user-username`},he={class:`card-header`},ge={class:`home-form-container`},_e={class:`form-section`},ve={class:`coordinates-display`},ye={key:0},be={key:1,class:`no-location`},xe={class:`map-section`},Se=a(R({__name:`index`,setup(a){let o=z(),c=r(),u=w(!0),m=w(!1),h=w(null),g=w(null),_=w({name:``,homeAddress:``,homeLatitude:void 0,homeLongitude:void 0});async function v(){u.value=!0;try{h.value=(await U.getCurrentUser()).data.data,_.value={name:h.value.name||``,homeAddress:h.value.homeAddress||``,homeLatitude:h.value.homeLatitude?h.value.homeLatitude.toString():void 0,homeLongitude:h.value.homeLongitude?h.value.homeLongitude.toString():void 0}}catch{c.error(`加载用户信息失败`)}finally{u.value=!1}}async function b(){if(h.value){m.value=!0;try{let e={homeAddress:_.value.homeAddress||void 0,homeLatitude:_.value.homeLatitude?_.value.homeLatitude.toString():void 0,homeLongitude:_.value.homeLongitude?_.value.homeLongitude.toString():void 0};await U.setHome(e),c.success(`设置保存成功`),await v()}catch{c.error(`保存设置失败`)}finally{m.value=!1}}}function x(e){_.value.homeLatitude=e.latitude.toString(),_.value.homeLongitude=e.longitude.toString(),_.value.homeAddress||(_.value.homeAddress=e.address)}function S(){_.value.homeAddress=``,_.value.homeLatitude=void 0,_.value.homeLongitude=void 0}let T=G(()=>h.value?.name?h.value.name.charAt(0).toUpperCase():h.value?.username?h.value.username.charAt(0).toUpperCase():`U`);return Y(()=>{v()}),(r,a)=>(q(),N(`div`,se,[B(`header`,ce,[P(y(p),{quaternary:``,onClick:a[0]||=e=>y(o).push(`/trips`)},{icon:E(()=>[P(y(f),null,{default:E(()=>[P(y(Q))]),_:1})]),default:E(()=>[a[4]||=W(` 返回 `,-1)]),_:1}),a[5]||=B(`h1`,{class:`page-title`},`设置`,-1)]),P(y(s),{show:u.value},{default:E(()=>[h.value?(q(),N(`div`,le,[P(y(L),{class:`user-info-card`},{default:E(()=>[B(`div`,ue,[P(y(ie),{size:80,round:``,style:{backgroundColor:`var(--primary-color)`}},{default:E(()=>[W(C(T.value),1)]),_:1}),B(`div`,de,[B(`h2`,fe,C(h.value.name||h.value.username),1),B(`p`,pe,C(h.value.email),1),B(`p`,me,`@`+C(h.value.username),1)])])]),_:1}),P(y(L),{class:`home-settings-card`},{header:E(()=>[B(`div`,he,[P(y(f),{size:20},{default:E(()=>[P(y(l))]),_:1}),a[6]||=B(`span`,null,`家庭位置`,-1)])]),default:E(()=>[B(`div`,ge,[B(`div`,_e,[P(y(n),{ref_key:`formRef`,ref:g,model:_.value,"label-placement":`top`},{default:E(()=>[P(y(i),{label:`家庭地址`},{default:E(()=>[P(y(t),{value:_.value.homeAddress,"onUpdate:value":a[1]||=e=>_.value.homeAddress=e,placeholder:`请输入您的家庭地址`,type:`textarea`,rows:2},null,8,[`value`])]),_:1}),P(y(e),{vertical:``,size:8},{default:E(()=>[B(`div`,ve,[P(y(f),{size:16},{default:E(()=>[P(y(ne))]),_:1}),_.value.homeLatitude&&_.value.homeLongitude?(q(),N(`span`,ye,C(_.value.homeLatitude)+`, `+C(_.value.homeLongitude),1)):(q(),N(`span`,be,`未选择位置`))])]),_:1}),P(y(oe)),P(y(e),null,{default:E(()=>[P(y(p),{type:`primary`,loading:m.value,onClick:b},{default:E(()=>[...a[7]||=[W(` 保存设置 `,-1)]]),_:1},8,[`loading`]),P(y(p),{onClick:S},{default:E(()=>[...a[8]||=[W(` 清除位置 `,-1)]]),_:1})]),_:1})]),_:1},8,[`model`]),a[9]||=B(`div`,{class:`tip-text`},[B(`p`,null,`💡 设置您的家庭位置有助于计算旅行距离并更高效地规划路线。`)],-1)]),B(`div`,xe,[P(d,{latitude:_.value.homeLatitude,"onUpdate:latitude":a[2]||=e=>_.value.homeLatitude=e,longitude:_.value.homeLongitude,"onUpdate:longitude":a[3]||=e=>_.value.homeLongitude=e,address:_.value.homeAddress,onLocationSelected:x},null,8,[`latitude`,`longitude`,`address`])])])]),_:1})])):te(``,!0)]),_:1},8,[`show`])]))}}),[[`__scopeId`,`data-v-cf87c25a`]]);export{Se as default};