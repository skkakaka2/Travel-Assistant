import{c as e,f as t,i as n,n as r,p as i,r as a,s as o,t as s}from"./Popover-Ds51FOht.js";import{s as c,t as l}from"./Space-Doh6zwh0.js";import"./use-compitable-Bh-IqaE9.js";import{t as u}from"./_plugin-vue_export-helper-H2tEXVNX.js";import{t as d}from"./create-ref-setter-CV2uREZl.js";import{t as f}from"./create-C0ev3hp9.js";import{t as p}from"./Icon-DS2OP600.js";import{$t as m,A as h,B as g,Bn as _,Bt as v,Cn as y,Er as b,Fn as x,Fr as S,G as C,In as w,K as ee,Kn as T,Mr as E,Nr as D,On as O,Or as k,Rn as A,Sr as j,T as te,Tr as M,U as N,Vn as P,W as F,Xt as I,Zn as L,_n as ne,a as re,ar as R,at as ie,cr as z,dr as B,fr as V,gn as ae,lr as H,mn as oe,n as se,nn as ce,nr as U,ot as W,pr as le,qt as G,r as ue,rr as K,tr as q,vn as de,xr as J,yn as Y,zn as X,zt as Z}from"./index-cT_2Xr_W.js";import{n as fe,t as pe}from"./SunnyOutline-BV8N2M06.js";function me(e,t,n){if(!t)return e;let r=E(e.value),i=null;return b(e,e=>{i!==null&&window.clearTimeout(i),e===!0?n&&!n.value?r.value=!0:i=window.setTimeout(()=>{r.value=!0},t):r.value=!1}),r}var he=H({name:`ChevronRight`,render(){return B(`svg`,{viewBox:`0 0 16 16`,fill:`none`,xmlns:`http://www.w3.org/2000/svg`},B(`path`,{d:`M5.64645 3.14645C5.45118 3.34171 5.45118 3.65829 5.64645 3.85355L9.79289 8L5.64645 12.1464C5.45118 12.3417 5.45118 12.6583 5.64645 12.8536C5.84171 13.0488 6.15829 13.0488 6.35355 12.8536L10.8536 8.35355C11.0488 8.15829 11.0488 7.84171 10.8536 7.64645L6.35355 3.14645C6.15829 2.95118 5.84171 2.95118 5.64645 3.14645Z`,fill:`currentColor`}))}});const Q=Y(`n-dropdown-menu`),$=Y(`n-dropdown`),ge=Y(`n-dropdown-option`);var _e=H({name:`DropdownDivider`,props:{clsPrefix:{type:String,required:!0}},render(){return B(`div`,{class:`${this.clsPrefix}-dropdown-divider`})}}),ve=H({name:`DropdownGroupHeader`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0}},setup(){let{showIconRef:e,hasSubmenuRef:t}=V(Q),{renderLabelRef:n,labelFieldRef:r,nodePropsRef:i,renderOptionRef:a}=V($);return{labelField:r,showIcon:e,hasSubmenu:t,renderLabel:n,nodeProps:i,renderOption:a}},render(){let{clsPrefix:e,hasSubmenu:t,showIcon:n,nodeProps:r,renderLabel:i,renderOption:a}=this,{rawNode:o}=this.tmNode,s=B(`div`,Object.assign({class:`${e}-dropdown-option`},r?.(o)),B(`div`,{class:`${e}-dropdown-option-body ${e}-dropdown-option-body--group`},B(`div`,{"data-dropdown-option":!0,class:[`${e}-dropdown-option-body__prefix`,n&&`${e}-dropdown-option-body__prefix--show-icon`]},G(o.icon)),B(`div`,{class:`${e}-dropdown-option-body__label`,"data-dropdown-option":!0},i?i(o):G(o.title??o[this.labelField])),B(`div`,{class:[`${e}-dropdown-option-body__suffix`,t&&`${e}-dropdown-option-body__suffix--has-submenu`],"data-dropdown-option":!0})));return a?a({node:s,option:o}):s}});function ye(e,t){return e.type===`submenu`||e.type===void 0&&e[t]!==void 0}function be(e){return e.type===`group`}function xe(e){return e.type===`divider`}function Se(e){return e.type===`render`}var Ce=H({name:`DropdownOption`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0},parentKey:{type:[String,Number],default:null},placement:{type:String,default:`right-start`},props:Object,scrollable:Boolean},setup(e){let t=V($),{hoverKeyRef:n,keyboardKeyRef:r,lastToggledSubmenuKeyRef:a,pendingKeyPathRef:o,activeKeyPathRef:s,animatedRef:c,mergedShowRef:l,renderLabelRef:u,renderIconRef:d,labelFieldRef:f,childrenFieldRef:p,renderOptionRef:m,nodePropsRef:h,menuPropsRef:g}=t,_=V(ge,null),v=V(Q),b=V(ae),x=q(()=>e.tmNode.rawNode),S=q(()=>{let{value:t}=p;return ye(e.tmNode.rawNode,t)}),C=q(()=>{let{disabled:t}=e.tmNode;return t}),w=me(q(()=>{if(!S.value)return!1;let{key:t,disabled:i}=e.tmNode;if(i)return!1;let{value:s}=n,{value:c}=r,{value:l}=a,{value:u}=o;return s===null?c===null?l===null?!1:u.includes(t):u.includes(t)&&u[u.length-1]!==t:u.includes(t)}),300,q(()=>r.value===null&&!c.value)),ee=q(()=>!!_?.enteringSubmenuRef.value),T=E(!1);j(ge,{enteringSubmenuRef:T});function D(){T.value=!0}function O(){T.value=!1}function k(){let{parentKey:t,tmNode:i}=e;i.disabled||l.value&&(a.value=t,r.value=null,n.value=i.key)}function A(){let{tmNode:t}=e;t.disabled||l.value&&n.value!==t.key&&k()}function te(t){if(e.tmNode.disabled||!l.value)return;let{relatedTarget:r}=t;r&&!i({target:r},`dropdownOption`)&&!i({target:r},`scrollbarRail`)&&(n.value=null)}function M(){let{value:n}=S,{tmNode:r}=e;l.value&&!n&&!r.disabled&&(t.doSelect(r.key,r.rawNode),t.doUpdateShow(!1))}return{labelField:f,renderLabel:u,renderIcon:d,siblingHasIcon:v.showIconRef,siblingHasSubmenu:v.hasSubmenuRef,menuProps:g,popoverBody:b,animated:c,mergedShowSubmenu:q(()=>w.value&&!ee.value),rawNode:x,hasSubmenu:S,pending:y(()=>{let{value:t}=o,{key:n}=e.tmNode;return t.includes(n)}),childActive:y(()=>{let{value:t}=s,{key:n}=e.tmNode,r=t.findIndex(e=>n===e);return r===-1?!1:r<t.length-1}),active:y(()=>{let{value:t}=s,{key:n}=e.tmNode,r=t.findIndex(e=>n===e);return r===-1?!1:r===t.length-1}),mergedDisabled:C,renderOption:m,nodeProps:h,handleClick:M,handleMouseMove:A,handleMouseEnter:k,handleMouseLeave:te,handleSubmenuBeforeEnter:D,handleSubmenuAfterEnter:O}},render(){let{animated:t,rawNode:r,mergedShowSubmenu:i,clsPrefix:a,siblingHasIcon:s,siblingHasSubmenu:c,renderLabel:l,renderIcon:u,renderOption:d,nodeProps:f,props:m,scrollable:h}=this,g=null;if(i){let e=this.menuProps?.call(this,r,r.children);g=B(Ee,Object.assign({},e,{clsPrefix:a,scrollable:this.scrollable,tmNodes:this.tmNode.children,parentKey:this.tmNode.key}))}let _={class:[`${a}-dropdown-option-body`,this.pending&&`${a}-dropdown-option-body--pending`,this.active&&`${a}-dropdown-option-body--active`,this.childActive&&`${a}-dropdown-option-body--child-active`,this.mergedDisabled&&`${a}-dropdown-option-body--disabled`],onMousemove:this.handleMouseMove,onMouseenter:this.handleMouseEnter,onMouseleave:this.handleMouseLeave,onClick:this.handleClick},v=f?.(r),y=B(`div`,Object.assign({class:[`${a}-dropdown-option`,v?.class],"data-dropdown-option":!0},v),B(`div`,le(_,m),[B(`div`,{class:[`${a}-dropdown-option-body__prefix`,s&&`${a}-dropdown-option-body__prefix--show-icon`]},[u?u(r):G(r.icon)]),B(`div`,{"data-dropdown-option":!0,class:`${a}-dropdown-option-body__label`},l?l(r):G(r[this.labelField]??r.title)),B(`div`,{"data-dropdown-option":!0,class:[`${a}-dropdown-option-body__suffix`,c&&`${a}-dropdown-option-body__suffix--has-submenu`]},this.hasSubmenu?B(p,null,{default:()=>B(he,null)}):null)]),this.hasSubmenu?B(e,null,{default:()=>[B(o,null,{default:()=>B(`div`,{class:`${a}-dropdown-offset-container`},B(n,{show:this.mergedShowSubmenu,placement:this.placement,to:h&&this.popoverBody||void 0,teleportDisabled:!h},{default:()=>B(`div`,{class:`${a}-dropdown-menu-wrapper`},t?B(T,{onBeforeEnter:this.handleSubmenuBeforeEnter,onAfterEnter:this.handleSubmenuAfterEnter,name:`fade-in-scale-up-transition`,appear:!0},{default:()=>g}):g)}))})]}):null);return d?d({node:y,option:r}):y}}),we=H({name:`NDropdownGroup`,props:{clsPrefix:{type:String,required:!0},tmNode:{type:Object,required:!0},parentKey:{type:[String,Number],default:null}},render(){let{tmNode:e,parentKey:t,clsPrefix:n}=this,{children:r}=e;return B(L,null,B(ve,{clsPrefix:n,tmNode:e,key:e.key}),r?.map(e=>{let{rawNode:r}=e;return r.show===!1?null:xe(r)?B(_e,{clsPrefix:n,key:e.key}):e.isGroup?(ce(`dropdown`,"`group` node is not allowed to be put in `group` node."),null):B(Ce,{clsPrefix:n,tmNode:e,parentKey:t,key:e.key})}))}}),Te=H({name:`DropdownRenderOption`,props:{tmNode:{type:Object,required:!0}},render(){let{rawNode:{render:e,props:t}}=this.tmNode;return B(`div`,t,[e?.()])}}),Ee=H({name:`DropdownMenu`,props:{scrollable:Boolean,showArrow:Boolean,arrowStyle:[String,Object],clsPrefix:{type:String,required:!0},tmNodes:{type:Array,default:()=>[]},parentKey:{type:[String,Number],default:null}},setup(e){let{renderIconRef:t,childrenFieldRef:n}=V($);j(Q,{showIconRef:q(()=>{let n=t.value;return e.tmNodes.some(e=>{if(e.isGroup)return e.children?.some(({rawNode:e})=>n?n(e):e.icon);let{rawNode:t}=e;return n?n(t):t.icon})}),hasSubmenuRef:q(()=>{let{value:t}=n;return e.tmNodes.some(e=>{if(e.isGroup)return e.children?.some(({rawNode:e})=>ye(e,t));let{rawNode:n}=e;return ye(n,t)})})});let r=E(null);return j(ne,null),j(de,null),j(ae,r),{bodyRef:r}},render(){let{parentKey:e,clsPrefix:t,scrollable:n}=this,r=this.tmNodes.map(r=>{let{rawNode:i}=r;return i.show===!1?null:Se(i)?B(Te,{tmNode:r,key:r.key}):xe(i)?B(_e,{clsPrefix:t,key:r.key}):be(i)?B(we,{clsPrefix:t,tmNode:r,parentKey:e,key:r.key}):B(Ce,{clsPrefix:t,tmNode:r,parentKey:e,key:r.key,props:i.props,scrollable:n})});return B(`div`,{class:[`${t}-dropdown-menu`,n&&`${t}-dropdown-menu--scrollable`],ref:`bodyRef`},n?B(F,{contentClass:`${t}-dropdown-menu__content`},{default:()=>r}):r,this.showArrow?a({clsPrefix:t,arrowStyle:this.arrowStyle,arrowClass:void 0,arrowWrapperClass:void 0,arrowWrapperStyle:void 0}):null)}}),De=w(`dropdown-menu`,`
 transform-origin: var(--v-transform-origin);
 background-color: var(--n-color);
 border-radius: var(--n-border-radius);
 box-shadow: var(--n-box-shadow);
 position: relative;
 transition:
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier);
`,[g(),w(`dropdown-option`,`
 position: relative;
 `,[x(`a`,`
 text-decoration: none;
 color: inherit;
 outline: none;
 `,[x(`&::before`,`
 content: "";
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]),w(`dropdown-option-body`,`
 display: flex;
 cursor: pointer;
 position: relative;
 height: var(--n-option-height);
 line-height: var(--n-option-height);
 font-size: var(--n-font-size);
 color: var(--n-option-text-color);
 transition: color .3s var(--n-bezier);
 `,[x(`&::before`,`
 content: "";
 position: absolute;
 top: 0;
 bottom: 0;
 left: 4px;
 right: 4px;
 transition: background-color .3s var(--n-bezier);
 border-radius: var(--n-border-radius);
 `),_(`disabled`,[X(`pending`,`
 color: var(--n-option-text-color-hover);
 `,[A(`prefix, suffix`,`
 color: var(--n-option-text-color-hover);
 `),x(`&::before`,`background-color: var(--n-option-color-hover);`)]),X(`active`,`
 color: var(--n-option-text-color-active);
 `,[A(`prefix, suffix`,`
 color: var(--n-option-text-color-active);
 `),x(`&::before`,`background-color: var(--n-option-color-active);`)]),X(`child-active`,`
 color: var(--n-option-text-color-child-active);
 `,[A(`prefix, suffix`,`
 color: var(--n-option-text-color-child-active);
 `)])]),X(`disabled`,`
 cursor: not-allowed;
 opacity: var(--n-option-opacity-disabled);
 `),X(`group`,`
 font-size: calc(var(--n-font-size) - 1px);
 color: var(--n-group-header-text-color);
 `,[A(`prefix`,`
 width: calc(var(--n-option-prefix-width) / 2);
 `,[X(`show-icon`,`
 width: calc(var(--n-option-icon-prefix-width) / 2);
 `)])]),A(`prefix`,`
 width: var(--n-option-prefix-width);
 display: flex;
 justify-content: center;
 align-items: center;
 color: var(--n-prefix-color);
 transition: color .3s var(--n-bezier);
 z-index: 1;
 `,[X(`show-icon`,`
 width: var(--n-option-icon-prefix-width);
 `),w(`icon`,`
 font-size: var(--n-option-icon-size);
 `)]),A(`label`,`
 white-space: nowrap;
 flex: 1;
 z-index: 1;
 `),A(`suffix`,`
 box-sizing: border-box;
 flex-grow: 0;
 flex-shrink: 0;
 display: flex;
 justify-content: flex-end;
 align-items: center;
 min-width: var(--n-option-suffix-width);
 padding: 0 8px;
 transition: color .3s var(--n-bezier);
 color: var(--n-suffix-color);
 z-index: 1;
 `,[X(`has-submenu`,`
 width: var(--n-option-icon-suffix-width);
 `),w(`icon`,`
 font-size: var(--n-option-icon-size);
 `)]),w(`dropdown-menu`,`pointer-events: all;`)]),w(`dropdown-offset-container`,`
 pointer-events: none;
 position: absolute;
 left: 0;
 right: 0;
 top: -4px;
 bottom: -4px;
 `)]),w(`dropdown-divider`,`
 transition: background-color .3s var(--n-bezier);
 background-color: var(--n-divider-color);
 height: 1px;
 margin: 4px 0;
 `),w(`dropdown-menu-wrapper`,`
 transform-origin: var(--v-transform-origin);
 width: fit-content;
 `),x(`>`,[w(`scrollbar`,`
 height: inherit;
 max-height: inherit;
 `)]),_(`scrollable`,`
 padding: var(--n-padding);
 `),X(`scrollable`,[A(`content`,`
 padding: var(--n-padding);
 `)])]),Oe={animated:{type:Boolean,default:!0},keyboard:{type:Boolean,default:!0},size:{type:String,default:`medium`},inverted:Boolean,placement:{type:String,default:`bottom`},onSelect:[Function,Array],options:{type:Array,default:()=>[]},menuProps:Function,showArrow:Boolean,renderLabel:Function,renderIcon:Function,renderOption:Function,nodeProps:Function,labelField:{type:String,default:`label`},keyField:{type:String,default:`key`},childrenField:{type:String,default:`children`},value:[String,Number]},ke=Object.keys(r),Ae=H({name:`Dropdown`,inheritAttrs:!1,props:Object.assign(Object.assign(Object.assign({},r),Oe),W.props),setup(e){let n=E(!1),r=c(D(e,`show`),n),i=q(()=>{let{keyField:t,childrenField:n}=e;return f(e.options,{getKey(e){return e[t]},getDisabled(e){return e.disabled===!0},getIgnored(e){return e.type===`divider`||e.type===`render`},getChildren(e){return e[n]}})}),a=q(()=>i.value.treeNodes),o=E(null),s=E(null),l=E(null),u=q(()=>o.value??s.value??l.value??null),d=q(()=>i.value.getPath(u.value).keyPath),p=q(()=>i.value.getPath(e.value).keyPath),h=y(()=>e.keyboard&&r.value);t({keydown:{ArrowUp:{prevent:!0,handler:k},ArrowRight:{prevent:!0,handler:O},ArrowDown:{prevent:!0,handler:A},ArrowLeft:{prevent:!0,handler:T},Enter:{prevent:!0,handler:M},Escape:ee}},h);let{mergedClsPrefixRef:g,inlineThemeDisabled:_}=v(e),x=W(`Dropdown`,`-dropdown`,De,te,e,g);j($,{labelFieldRef:D(e,`labelField`),childrenFieldRef:D(e,`childrenField`),renderLabelRef:D(e,`renderLabel`),renderIconRef:D(e,`renderIcon`),hoverKeyRef:o,keyboardKeyRef:s,lastToggledSubmenuKeyRef:l,pendingKeyPathRef:d,activeKeyPathRef:p,animatedRef:D(e,`animated`),mergedShowRef:r,nodePropsRef:D(e,`nodeProps`),renderOptionRef:D(e,`renderOption`),menuPropsRef:D(e,`menuProps`),doSelect:S,doUpdateShow:C}),b(r,t=>{!e.animated&&!t&&w()});function S(t,n){let{onSelect:r}=e;r&&m(r,t,n)}function C(t){let{"onUpdate:show":r,onUpdateShow:i}=e;r&&m(r,t),i&&m(i,t),n.value=t}function w(){o.value=null,s.value=null,l.value=null}function ee(){C(!1)}function T(){F(`left`)}function O(){F(`right`)}function k(){F(`up`)}function A(){F(`down`)}function M(){let e=N();e?.isLeaf&&r.value&&(S(e.key,e.rawNode),C(!1))}function N(){let{value:e}=i,{value:t}=u;return!e||t===null?null:e.getNode(t)??null}function F(e){let{value:t}=u,{value:{getFirstAvailableNode:n}}=i,r=null;if(t===null){let e=n();e!==null&&(r=e.key)}else{let t=N();if(t){let n;switch(e){case`down`:n=t.getNext();break;case`up`:n=t.getPrev();break;case`right`:n=t.getChild();break;case`left`:n=t.getParent();break}n&&(r=n.key)}}r!==null&&(o.value=null,s.value=r)}let I=q(()=>{let{size:t,inverted:n}=e,{common:{cubicBezierEaseInOut:r},self:i}=x.value,{padding:a,dividerColor:o,borderRadius:s,optionOpacityDisabled:c,[P(`optionIconSuffixWidth`,t)]:l,[P(`optionSuffixWidth`,t)]:u,[P(`optionIconPrefixWidth`,t)]:d,[P(`optionPrefixWidth`,t)]:f,[P(`fontSize`,t)]:p,[P(`optionHeight`,t)]:m,[P(`optionIconSize`,t)]:h}=i,g={"--n-bezier":r,"--n-font-size":p,"--n-padding":a,"--n-border-radius":s,"--n-option-height":m,"--n-option-prefix-width":f,"--n-option-icon-prefix-width":d,"--n-option-suffix-width":u,"--n-option-icon-suffix-width":l,"--n-option-icon-size":h,"--n-divider-color":o,"--n-option-opacity-disabled":c};return n?(g[`--n-color`]=i.colorInverted,g[`--n-option-color-hover`]=i.optionColorHoverInverted,g[`--n-option-color-active`]=i.optionColorActiveInverted,g[`--n-option-text-color`]=i.optionTextColorInverted,g[`--n-option-text-color-hover`]=i.optionTextColorHoverInverted,g[`--n-option-text-color-active`]=i.optionTextColorActiveInverted,g[`--n-option-text-color-child-active`]=i.optionTextColorChildActiveInverted,g[`--n-prefix-color`]=i.prefixColorInverted,g[`--n-suffix-color`]=i.suffixColorInverted,g[`--n-group-header-text-color`]=i.groupHeaderTextColorInverted):(g[`--n-color`]=i.color,g[`--n-option-color-hover`]=i.optionColorHover,g[`--n-option-color-active`]=i.optionColorActive,g[`--n-option-text-color`]=i.optionTextColor,g[`--n-option-text-color-hover`]=i.optionTextColorHover,g[`--n-option-text-color-active`]=i.optionTextColorActive,g[`--n-option-text-color-child-active`]=i.optionTextColorChildActive,g[`--n-prefix-color`]=i.prefixColor,g[`--n-suffix-color`]=i.suffixColor,g[`--n-group-header-text-color`]=i.groupHeaderTextColor),g}),L=_?Z(`dropdown`,q(()=>`${e.size[0]}${e.inverted?`i`:``}`),I,e):void 0;return{mergedClsPrefix:g,mergedTheme:x,tmNodes:a,mergedShow:r,handleAfterLeave:()=>{e.animated&&w()},doUpdateShow:C,cssVars:_?void 0:I,themeClass:L?.themeClass,onRender:L?.onRender}},render(){let e=(e,t,n,r,i)=>{var a;let{mergedClsPrefix:o,menuProps:s}=this;(a=this.onRender)==null||a.call(this);let c=s?.(void 0,this.tmNodes.map(e=>e.rawNode))||{},l={ref:d(t),class:[e,`${o}-dropdown`,this.themeClass],clsPrefix:o,tmNodes:this.tmNodes,style:[...n,this.cssVars],showArrow:this.showArrow,arrowStyle:this.arrowStyle,scrollable:this.scrollable,onMouseenter:r,onMouseleave:i};return B(Ee,le(this.$attrs,l,c))},{mergedTheme:t}=this,n={show:this.mergedShow,theme:t.peers.Popover,themeOverrides:t.peerOverrides.Popover,internalOnAfterLeave:this.handleAfterLeave,internalRenderBody:e,onUpdateShow:this.doUpdateShow,"onUpdate:show":void 0};return B(s,Object.assign({},I(this.$props,ke),n),{trigger:()=>{var e;return(e=this.$slots).default?.call(e)}})}});function je(e){let{baseColor:t,textColor2:n,bodyColor:r,cardColor:i,dividerColor:a,actionColor:o,scrollbarColor:s,scrollbarColorHover:c,invertedColor:l}=e;return{textColor:n,textColorInverted:`#FFF`,color:r,colorEmbedded:o,headerColor:i,headerColorInverted:l,footerColor:o,footerColorInverted:l,headerBorderColor:a,headerBorderColorInverted:l,footerBorderColor:a,footerBorderColorInverted:l,siderBorderColor:a,siderBorderColorInverted:l,siderColor:i,siderColorInverted:l,siderToggleButtonBorder:`1px solid ${a}`,siderToggleButtonColor:t,siderToggleButtonIconColor:n,siderToggleButtonIconColorInverted:n,siderToggleBarColor:O(r,s),siderToggleBarColorHover:O(r,c),__invertScrollbar:`true`}}var Me=ie({name:`Layout`,common:ee,peers:{Scrollbar:C},self:je});Y(`n-layout-sider`);const Ne={type:String,default:`static`};var Pe=w(`layout`,`
 color: var(--n-text-color);
 background-color: var(--n-color);
 box-sizing: border-box;
 position: relative;
 z-index: auto;
 flex: auto;
 overflow: hidden;
 transition:
 box-shadow .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 color .3s var(--n-bezier);
`,[w(`layout-scroll-container`,`
 overflow-x: hidden;
 box-sizing: border-box;
 height: 100%;
 `),X(`absolute-positioned`,`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 bottom: 0;
 `)]);const Fe={embedded:Boolean,position:Ne,nativeScrollbar:{type:Boolean,default:!0},scrollbarProps:Object,onScroll:Function,contentClass:String,contentStyle:{type:[String,Object],default:``},hasSider:Boolean,siderPlacement:{type:String,default:`left`}},Ie=Y(`n-layout`);function Le(e){return H({name:e?`LayoutContent`:`Layout`,props:Object.assign(Object.assign({},W.props),Fe),setup(e){let t=E(null),n=E(null),{mergedClsPrefixRef:r,inlineThemeDisabled:i}=v(e),a=W(`Layout`,`-layout`,Pe,Me,e,r);function o(r,i){if(e.nativeScrollbar){let{value:e}=t;e&&(i===void 0?e.scrollTo(r):e.scrollTo(r,i))}else{let{value:e}=n;e&&e.scrollTo(r,i)}}j(Ie,e);let s=0,c=0,l=t=>{var n;let r=t.target;s=r.scrollLeft,c=r.scrollTop,(n=e.onScroll)==null||n.call(e,t)};oe(()=>{if(e.nativeScrollbar){let e=t.value;e&&(e.scrollTop=c,e.scrollLeft=s)}});let u={display:`flex`,flexWrap:`nowrap`,width:`100%`,flexDirection:`row`},d={scrollTo:o},f=q(()=>{let{common:{cubicBezierEaseInOut:t},self:n}=a.value;return{"--n-bezier":t,"--n-color":e.embedded?n.colorEmbedded:n.color,"--n-text-color":n.textColor}}),p=i?Z(`layout`,q(()=>e.embedded?`e`:``),f,e):void 0;return Object.assign({mergedClsPrefix:r,scrollableElRef:t,scrollbarInstRef:n,hasSiderStyle:u,mergedTheme:a,handleNativeElScroll:l,cssVars:i?void 0:f,themeClass:p?.themeClass,onRender:p?.onRender},d)},render(){var t;let{mergedClsPrefix:n,hasSider:r}=this;(t=this.onRender)==null||t.call(this);let i=r?this.hasSiderStyle:void 0;return B(`div`,{class:[this.themeClass,e&&`${n}-layout-content`,`${n}-layout`,`${n}-layout--${this.position}-positioned`],style:this.cssVars},this.nativeScrollbar?B(`div`,{ref:`scrollableElRef`,class:[`${n}-layout-scroll-container`,this.contentClass],style:[this.contentStyle,i],onScroll:this.handleNativeElScroll},this.$slots):B(N,Object.assign({},this.scrollbarProps,{onScroll:this.onScroll,ref:`scrollbarInstRef`,theme:this.mergedTheme.peers.Scrollbar,themeOverrides:this.mergedTheme.peerOverrides.Scrollbar,contentClass:this.contentClass,contentStyle:[this.contentStyle,i]}),this.$slots))}})}var Re=Le(!1),ze=Le(!0),Be=w(`layout-header`,`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 box-shadow .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 box-sizing: border-box;
 width: 100%;
 background-color: var(--n-color);
 color: var(--n-text-color);
`,[X(`absolute-positioned`,`
 position: absolute;
 left: 0;
 right: 0;
 top: 0;
 `),X(`bordered`,`
 border-bottom: solid 1px var(--n-border-color);
 `)]);const Ve={position:Ne,inverted:Boolean,bordered:{type:Boolean,default:!1}};var He=H({name:`LayoutHeader`,props:Object.assign(Object.assign({},W.props),Ve),setup(e){let{mergedClsPrefixRef:t,inlineThemeDisabled:n}=v(e),r=W(`Layout`,`-layout-header`,Be,Me,e,t),i=q(()=>{let{common:{cubicBezierEaseInOut:t},self:n}=r.value,i={"--n-bezier":t};return e.inverted?(i[`--n-color`]=n.headerColorInverted,i[`--n-text-color`]=n.textColorInverted,i[`--n-border-color`]=n.headerBorderColorInverted):(i[`--n-color`]=n.headerColor,i[`--n-text-color`]=n.textColor,i[`--n-border-color`]=n.headerBorderColor),i}),a=n?Z(`layout-header`,q(()=>e.inverted?`a`:`b`),i,e):void 0;return{mergedClsPrefix:t,cssVars:n?void 0:i,themeClass:a?.themeClass,onRender:a?.onRender}},render(){var e;let{mergedClsPrefix:t}=this;return(e=this.onRender)==null||e.call(this),B(`div`,{class:[`${t}-layout-header`,this.themeClass,this.position&&`${t}-layout-header--${this.position}-positioned`,this.bordered&&`${t}-layout-header--bordered`],style:this.cssVars},this.$slots)}}),Ue={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},We=H({name:`LogOutOutline`,render:function(e,t){return J(),R(`svg`,Ue,t[0]||=[U(`path`,{d:`M304 336v40a40 40 0 0 1-40 40H104a40 40 0 0 1-40-40V136a40 40 0 0 1 40-40h152c22.09 0 48 17.91 48 40v40`,fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`},null,-1),U(`path`,{fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`,d:`M368 336l80-80l-80-80`},null,-1),U(`path`,{fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`,d:`M176 256h256`},null,-1)])}}),Ge={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Ke=H({name:`PersonCircleOutline`,render:function(e,t){return J(),R(`svg`,Ge,t[0]||=[U(`path`,{d:`M258.9 48C141.92 46.42 46.42 141.92 48 258.9c1.56 112.19 92.91 203.54 205.1 205.1c117 1.6 212.48-93.9 210.88-210.88C462.44 140.91 371.09 49.56 258.9 48zm126.42 327.25a4 4 0 0 1-6.14-.32a124.27 124.27 0 0 0-32.35-29.59C321.37 329 289.11 320 256 320s-65.37 9-90.83 25.34a124.24 124.24 0 0 0-32.35 29.58a4 4 0 0 1-6.14.32A175.32 175.32 0 0 1 80 259c-1.63-97.31 78.22-178.76 175.57-179S432 158.81 432 256a175.32 175.32 0 0 1-46.68 119.25z`,fill:`currentColor`},null,-1),U(`path`,{d:`M256 144c-19.72 0-37.55 7.39-50.22 20.82s-19 32-17.57 51.93C191.11 256 221.52 288 256 288s64.83-32 67.79-71.24c1.48-19.74-4.8-38.14-17.68-51.82C293.39 151.44 275.59 144 256 144z`,fill:`currentColor`},null,-1)])}}),qe={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Je=H({name:`SettingsOutline`,render:function(e,t){return J(),R(`svg`,qe,t[0]||=[U(`path`,{d:`M262.29 192.31a64 64 0 1 0 57.4 57.4a64.13 64.13 0 0 0-57.4-57.4zM416.39 256a154.34 154.34 0 0 1-1.53 20.79l45.21 35.46a10.81 10.81 0 0 1 2.45 13.75l-42.77 74a10.81 10.81 0 0 1-13.14 4.59l-44.9-18.08a16.11 16.11 0 0 0-15.17 1.75A164.48 164.48 0 0 1 325 400.8a15.94 15.94 0 0 0-8.82 12.14l-6.73 47.89a11.08 11.08 0 0 1-10.68 9.17h-85.54a11.11 11.11 0 0 1-10.69-8.87l-6.72-47.82a16.07 16.07 0 0 0-9-12.22a155.3 155.3 0 0 1-21.46-12.57a16 16 0 0 0-15.11-1.71l-44.89 18.07a10.81 10.81 0 0 1-13.14-4.58l-42.77-74a10.8 10.8 0 0 1 2.45-13.75l38.21-30a16.05 16.05 0 0 0 6-14.08c-.36-4.17-.58-8.33-.58-12.5s.21-8.27.58-12.35a16 16 0 0 0-6.07-13.94l-38.19-30A10.81 10.81 0 0 1 49.48 186l42.77-74a10.81 10.81 0 0 1 13.14-4.59l44.9 18.08a16.11 16.11 0 0 0 15.17-1.75A164.48 164.48 0 0 1 187 111.2a15.94 15.94 0 0 0 8.82-12.14l6.73-47.89A11.08 11.08 0 0 1 213.23 42h85.54a11.11 11.11 0 0 1 10.69 8.87l6.72 47.82a16.07 16.07 0 0 0 9 12.22a155.3 155.3 0 0 1 21.46 12.57a16 16 0 0 0 15.11 1.71l44.89-18.07a10.81 10.81 0 0 1 13.14 4.58l42.77 74a10.8 10.8 0 0 1-2.45 13.75l-38.21 30a16.05 16.05 0 0 0-6.05 14.08c.33 4.14.55 8.3.55 12.47z`,fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`},null,-1)])}}),Ye={class:`header-content container`},Xe={class:`page-container container`},Ze=u(H({__name:`DefaultLayout`,setup(e){let t=ue(),n=re(),r=se(),i=[{label:`设置`,key:`settings`,icon:()=>B(p,null,{default:()=>B(Je)})},{type:`divider`,key:`d1`},{label:`登出`,key:`logout`,icon:()=>B(p,null,{default:()=>B(We)})}];function a(e){e===`settings`?r.push(`/settings`):e===`logout`&&(n.logout(),r.push(`/login`))}return(e,n)=>{let r=M(`RouterLink`),o=M(`router-view`);return J(),K(S(Re),{class:`layout`},{default:k(()=>[z(S(He),{class:`header glass`,bordered:``},{default:k(()=>[U(`div`,Ye,[z(r,{to:`/trips`,class:`logo`},{default:k(()=>[...n[0]||=[U(`span`,{class:`logo-icon`},`🌍`,-1),U(`span`,{class:`logo-text gradient-text`},`旅行助手`,-1)]]),_:1}),z(S(l),{align:`center`,size:12},{default:k(()=>[z(S(h),{quaternary:``,circle:``,onClick:S(t).toggleTheme},{icon:k(()=>[z(S(p),{size:20},{default:k(()=>[S(t).isDark?(J(),K(S(pe),{key:1})):(J(),K(S(fe),{key:0}))]),_:1})]),_:1},8,[`onClick`]),z(S(Ae),{options:i,onSelect:a},{default:k(()=>[z(S(h),{quaternary:``,circle:``},{icon:k(()=>[z(S(p),{size:20},{default:k(()=>[z(S(Ke))]),_:1})]),_:1})]),_:1})]),_:1})])]),_:1}),z(S(ze),{class:`content`},{default:k(()=>[U(`div`,Xe,[z(o)])]),_:1})]),_:1})}}}),[[`__scopeId`,`data-v-170fb168`]]);export{Ze as default};