import"./Popover-6tp3lNMs.js";import{t as e}from"./Space-DSfbK4ZR.js";import"./use-compitable-C1bpwaTZ.js";import{r as t}from"./FormItem-BceLBxxW.js";import{Z as n,c as r,d as i,f as a,g as o,h as s,i as c,l,m as u,n as d,p as f,r as p,s as ee,t as m}from"./date-C85Pz325.js";import{n as h,t as g}from"./_plugin-vue_export-helper-H2tEXVNX.js";import{i as _,n as v,r as y,t as b}from"./TripForm-gH_WZrGc.js";import{n as x,t as te}from"./Spin-CstuVNQr.js";import{t as S}from"./Icon-mZ5EVH3c.js";import{A as C,Bt as w,Cr as T,Er as E,Fn as D,Fr as O,In as k,K as A,Kt as j,Lr as M,Mr as N,Or as P,Rn as F,Sr as I,Vn as L,Wt as R,Yn as ne,Zn as z,ar as B,b as re,br as ie,cr as V,dr as H,f as ae,fr as U,hn as oe,i as se,ir as W,k as ce,l as le,lr as G,n as ue,nr as K,or as q,ot as de,rr as J,s as fe,sr as Y,t as pe,tn as me,tr as X,u as he,xr as Z,yn as ge,yr as _e,zn as Q,zt as ve}from"./index-CpWi_OZp.js";import{n as ye,r as be,t as xe}from"./useBaiduMap-wMMfDKg9.js";import{a as Se,i as Ce,n as we,r as Te,t as $}from"./api-bXth2mgv.js";var Ee=!1;function De(){if(oe&&window.CSS&&!Ee&&(Ee=!0,`registerProperty`in(window==null?void 0:window.CSS)))try{CSS.registerProperty({name:`--n-color-start`,syntax:`<color>`,inherits:!1,initialValue:`#0000`}),CSS.registerProperty({name:`--n-color-end`,syntax:`<color>`,inherits:!1,initialValue:`#0000`})}catch{}}function Oe(e){let{textColor3:t,infoColor:n,errorColor:r,successColor:i,warningColor:a,textColor1:o,textColor2:s,railColor:c,fontWeightStrong:l,fontSize:u}=e;return Object.assign(Object.assign({},ae),{contentFontSize:u,titleFontWeight:l,circleBorder:`2px solid ${t}`,circleBorderInfo:`2px solid ${n}`,circleBorderError:`2px solid ${r}`,circleBorderSuccess:`2px solid ${i}`,circleBorderWarning:`2px solid ${a}`,iconColor:t,iconColorInfo:n,iconColorError:r,iconColorSuccess:i,iconColorWarning:a,titleTextColor:o,contentTextColor:s,metaTextColor:t,lineColor:c})}var ke={name:`Timeline`,common:A,self:Oe},Ae=1.25,je=k(`timeline`,`
 position: relative;
 width: 100%;
 display: flex;
 flex-direction: column;
 line-height: ${Ae};
`,[Q(`horizontal`,`
 flex-direction: row;
 `,[D(`>`,[k(`timeline-item`,`
 flex-shrink: 0;
 padding-right: 40px;
 `,[Q(`dashed-line-type`,[D(`>`,[k(`timeline-item-timeline`,[F(`line`,`
 background-image: linear-gradient(90deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 10px 1px;
 `)])])]),D(`>`,[k(`timeline-item-content`,`
 margin-top: calc(var(--n-icon-size) + 12px);
 `,[D(`>`,[F(`meta`,`
 margin-top: 6px;
 margin-bottom: unset;
 `)])]),k(`timeline-item-timeline`,`
 width: 100%;
 height: calc(var(--n-icon-size) + 12px);
 `,[F(`line`,`
 left: var(--n-icon-size);
 top: calc(var(--n-icon-size) / 2 - 1px);
 right: 0px;
 width: unset;
 height: 2px;
 `)])])])])]),Q(`right-placement`,[k(`timeline-item`,[k(`timeline-item-content`,`
 text-align: right;
 margin-right: calc(var(--n-icon-size) + 12px);
 `),k(`timeline-item-timeline`,`
 width: var(--n-icon-size);
 right: 0;
 `)])]),Q(`left-placement`,[k(`timeline-item`,[k(`timeline-item-content`,`
 margin-left: calc(var(--n-icon-size) + 12px);
 `),k(`timeline-item-timeline`,`
 left: 0;
 `)])]),k(`timeline-item`,`
 position: relative;
 `,[D(`&:last-child`,[k(`timeline-item-timeline`,[F(`line`,`
 display: none;
 `)]),k(`timeline-item-content`,[F(`meta`,`
 margin-bottom: 0;
 `)])]),k(`timeline-item-content`,[F(`title`,`
 margin: var(--n-title-margin);
 font-size: var(--n-title-font-size);
 transition: color .3s var(--n-bezier);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),F(`content`,`
 transition: color .3s var(--n-bezier);
 font-size: var(--n-content-font-size);
 color: var(--n-content-text-color);
 `),F(`meta`,`
 transition: color .3s var(--n-bezier);
 font-size: 12px;
 margin-top: 6px;
 margin-bottom: 20px;
 color: var(--n-meta-text-color);
 `)]),Q(`dashed-line-type`,[k(`timeline-item-timeline`,[F(`line`,`
 --n-color-start: var(--n-line-color);
 transition: --n-color-start .3s var(--n-bezier);
 background-color: transparent;
 background-image: linear-gradient(180deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 1px 10px;
 `)])]),k(`timeline-item-timeline`,`
 width: calc(var(--n-icon-size) + 12px);
 position: absolute;
 top: calc(var(--n-title-font-size) * ${Ae} / 2 - var(--n-icon-size) / 2);
 height: 100%;
 `,[F(`circle`,`
 border: var(--n-circle-border);
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 border-radius: var(--n-icon-size);
 box-sizing: border-box;
 `),F(`icon`,`
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 height: var(--n-icon-size);
 width: var(--n-icon-size);
 display: flex;
 align-items: center;
 justify-content: center;
 `),F(`line`,`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 top: var(--n-icon-size);
 left: calc(var(--n-icon-size) / 2 - 1px);
 bottom: 0px;
 width: 2px;
 background-color: var(--n-line-color);
 `)])])]);const Me=Object.assign(Object.assign({},de.props),{horizontal:Boolean,itemPlacement:{type:String,default:`left`},size:{type:String,default:`medium`},iconSize:Number}),Ne=ge(`n-timeline`);var Pe=G({name:`Timeline`,props:Me,setup(e,{slots:t}){let{mergedClsPrefixRef:n}=w(e);return I(Ne,{props:e,mergedThemeRef:de(`Timeline`,`-timeline`,je,ke,e,n),mergedClsPrefixRef:n}),()=>{let{value:r}=n;return H(`div`,{class:[`${r}-timeline`,e.horizontal&&`${r}-timeline--horizontal`,`${r}-timeline--${e.size}-size`,!e.horizontal&&`${r}-timeline--${e.itemPlacement}-placement`]},t)}}}),Fe=G({name:`TimelineItem`,props:{time:[String,Number],title:String,content:String,color:String,lineType:{type:String,default:`default`},type:{type:String,default:`default`}},slots:Object,setup(e){let t=U(Ne);t||me(`timeline-item`,"`n-timeline-item` must be placed inside `n-timeline`."),De();let{inlineThemeDisabled:n}=w(),r=X(()=>{let{props:{size:n,iconSize:r},mergedThemeRef:i}=t,{type:a}=e,{self:{titleTextColor:o,contentTextColor:s,metaTextColor:c,lineColor:l,titleFontWeight:u,contentFontSize:d,[L(`iconSize`,n)]:f,[L(`titleMargin`,n)]:p,[L(`titleFontSize`,n)]:ee,[L(`circleBorder`,a)]:m,[L(`iconColor`,a)]:g},common:{cubicBezierEaseInOut:_}}=i.value;return{"--n-bezier":_,"--n-circle-border":m,"--n-icon-color":g,"--n-content-font-size":d,"--n-content-text-color":s,"--n-line-color":l,"--n-meta-text-color":c,"--n-title-font-size":ee,"--n-title-font-weight":u,"--n-title-margin":p,"--n-title-text-color":o,"--n-icon-size":h(r)||f}}),i=n?ve(`timeline-item`,X(()=>{let{props:{size:n,iconSize:r}}=t,{type:i}=e;return`${n[0]}${r||`a`}${i[0]}`}),r,t.props):void 0;return{mergedClsPrefix:t.mergedClsPrefixRef,cssVars:n?void 0:r,themeClass:i?.themeClass,onRender:i?.onRender}},render(){let{mergedClsPrefix:e,color:t,onRender:n,$slots:r}=this;return n?.(),H(`div`,{class:[`${e}-timeline-item`,this.themeClass,`${e}-timeline-item--${this.type}-type`,`${e}-timeline-item--${this.lineType}-line-type`],style:this.cssVars},H(`div`,{class:`${e}-timeline-item-timeline`},H(`div`,{class:`${e}-timeline-item-timeline__line`}),j(r.icon,n=>n?H(`div`,{class:`${e}-timeline-item-timeline__icon`,style:{color:t}},n):H(`div`,{class:`${e}-timeline-item-timeline__circle`,style:{borderColor:t}}))),H(`div`,{class:`${e}-timeline-item-content`},j(r.header,t=>t||this.title?H(`div`,{class:`${e}-timeline-item-content__title`},t||this.title):null),H(`div`,{class:`${e}-timeline-item-content__content`},R(r.default,()=>[this.content])),H(`div`,{class:`${e}-timeline-item-content__meta`},R(r.footer,()=>[this.time]))))}}),Ie={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Le=G({name:`BedOutline`,render:function(e,t){return Z(),B(`svg`,Ie,t[0]||=[q(`<path d="M384 240H96V136a40.12 40.12 0 0 1 40-40h240a40.12 40.12 0 0 1 40 40v104z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path d="M48 416V304a64.19 64.19 0 0 1 64-64h288a64.19 64.19 0 0 1 64 64v112" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path d="M48 416v-8a24.07 24.07 0 0 1 24-24h368a24.07 24.07 0 0 1 24 24v8" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path d="M112 240v-16a32.09 32.09 0 0 1 32-32h80a32.09 32.09 0 0 1 32 32v16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path d="M256 240v-16a32.09 32.09 0 0 1 32-32h80a32.09 32.09 0 0 1 32 32v16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path>`,5)])}}),Re={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},ze=G({name:`CarOutline`,render:function(e,t){return Z(),B(`svg`,Re,t[0]||=[q(`<path d="M80 224l37.78-88.15C123.93 121.5 139.6 112 157.11 112h197.78c17.51 0 33.18 9.5 39.33 23.85L432 224" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M80 224h352v144H80z"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M112 368v32H80v-32"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M432 368v32h-32v-32"></path><circle cx="144" cy="288" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle><circle cx="368" cy="288" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle>`,6)])}}),Be={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Ve=G({name:`CloseOutline`,render:function(e,t){return Z(),B(`svg`,Be,t[0]||=[K(`path`,{fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`,d:`M368 368L144 144`},null,-1),K(`path`,{fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`,d:`M368 144L144 368`},null,-1)])}}),He={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Ue=G({name:`EllipsisHorizontalOutline`,render:function(e,t){return Z(),B(`svg`,He,t[0]||=[K(`circle`,{cx:`256`,cy:`256`,r:`32`,fill:`none`,stroke:`currentColor`,"stroke-miterlimit":`10`,"stroke-width":`32`},null,-1),K(`circle`,{cx:`416`,cy:`256`,r:`32`,fill:`none`,stroke:`currentColor`,"stroke-miterlimit":`10`,"stroke-width":`32`},null,-1),K(`circle`,{cx:`96`,cy:`256`,r:`32`,fill:`none`,stroke:`currentColor`,"stroke-miterlimit":`10`,"stroke-width":`32`},null,-1)])}}),We={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Ge=G({name:`GameControllerOutline`,render:function(e,t){return Z(),B(`svg`,We,t[0]||=[q(`<path d="M467.51 248.83c-18.4-83.18-45.69-136.24-89.43-149.17A91.5 91.5 0 0 0 352 96c-26.89 0-48.11 16-96 16s-69.15-16-96-16a99.09 99.09 0 0 0-27.2 3.66C89 112.59 61.94 165.7 43.33 248.83c-19 84.91-15.56 152 21.58 164.88c26 9 49.25-9.61 71.27-37c25-31.2 55.79-40.8 119.82-40.8s93.62 9.6 118.66 40.8c22 27.41 46.11 45.79 71.42 37.16c41.02-14.01 40.44-79.13 21.43-165.04z" fill="none" stroke="currentColor" stroke-miterlimit="10" stroke-width="32"></path><circle cx="292" cy="224" r="20" fill="currentColor"></circle><path d="M336 288a20 20 0 1 1 20-19.95A20 20 0 0 1 336 288z" fill="currentColor"></path><circle cx="336" cy="180" r="20" fill="currentColor"></circle><circle cx="380" cy="224" r="20" fill="currentColor"></circle><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M160 176v96"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M208 224h-96"></path>`,7)])}}),Ke={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},qe=G({name:`ImageOutline`,render:function(e,t){return Z(),B(`svg`,Ke,t[0]||=[K(`rect`,{x:`48`,y:`80`,width:`416`,height:`352`,rx:`48`,ry:`48`,fill:`none`,stroke:`currentColor`,"stroke-linejoin":`round`,"stroke-width":`32`},null,-1),K(`circle`,{cx:`336`,cy:`176`,r:`32`,fill:`none`,stroke:`currentColor`,"stroke-miterlimit":`10`,"stroke-width":`32`},null,-1),K(`path`,{d:`M304 335.79l-90.66-90.49a32 32 0 0 0-43.87-1.3L48 352`,fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`},null,-1),K(`path`,{d:`M224 432l123.34-123.34a32 32 0 0 1 43.11-2L464 368`,fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`},null,-1)])}}),Je={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Ye=G({name:`MapOutline`,render:function(e,t){return Z(),B(`svg`,Je,t[0]||=[K(`path`,{d:`M313.27 124.64L198.73 51.36a32 32 0 0 0-29.28.35L56.51 127.49A16 16 0 0 0 48 141.63v295.8a16 16 0 0 0 23.49 14.14l97.82-63.79a32 32 0 0 1 29.5-.24l111.86 73a32 32 0 0 0 29.27-.11l115.43-75.94a16 16 0 0 0 8.63-14.2V74.57a16 16 0 0 0-23.49-14.14l-98 63.86a32 32 0 0 1-29.24.35z`,fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`},null,-1),K(`path`,{fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`,d:`M328 128v336`},null,-1),K(`path`,{fill:`none`,stroke:`currentColor`,"stroke-linecap":`round`,"stroke-linejoin":`round`,"stroke-width":`32`,d:`M184 48v336`},null,-1)])}}),Xe={xmlns:`http://www.w3.org/2000/svg`,"xmlns:xlink":`http://www.w3.org/1999/xlink`,viewBox:`0 0 512 512`},Ze=G({name:`RestaurantOutline`,render:function(e,t){return Z(),B(`svg`,Xe,t[0]||=[q(`<path d="M57.49 47.74l368.43 368.43a37.28 37.28 0 0 1 0 52.72h0a37.29 37.29 0 0 1-52.72 0l-90-91.55a32 32 0 0 1-9.2-22.43v-5.53a32 32 0 0 0-9.52-22.78l-11.62-10.73a32 32 0 0 0-29.8-7.44h0a48.53 48.53 0 0 1-46.56-12.63l-85.43-85.44C40.39 159.68 21.74 83.15 57.49 47.74z" fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="32"></path><path d="M400 32l-77.25 77.25A64 64 0 0 0 304 154.51v14.86a16 16 0 0 1-4.69 11.32L288 192" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path d="M320 224l11.31-11.31a16 16 0 0 1 11.32-4.69h14.86a64 64 0 0 0 45.26-18.75L480 112" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M440 72l-80 80"></path><path d="M200 368l-99.72 100.28a40 40 0 0 1-56.56 0h0a40 40 0 0 1 0-56.56L128 328" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></path>`,5)])}}),Qe={style:{display:`flex`,"align-items":`center`,"justify-content":`space-between`,width:`100%`}},$e={style:{"font-size":`1.25rem`,"font-weight":`600`}},et={class:`map-view-container`},tt=g(G({__name:`TripMapView`,props:{show:{type:Boolean},trip:{},dayPlans:{}},emits:[`update:show`],setup(e,{emit:t}){let n=e,o=t,s=N(null),c=N(null),{loading:u,initMap:d,getMap:f,destroyMap:p,setViewport:m}=xe(s),h=null,g=[],_=[],v=null,y=null,b=X(()=>{let e=[];return n.dayPlans.forEach(t=>{t.dayPlanItems&&t.dayPlanItems.forEach(n=>{n.latitude&&n.longitude&&e.push({item:n,dayPlan:t})})}),e.sort((e,t)=>e.dayPlan.date===t.dayPlan.date?e.item.startTime&&t.item.startTime?e.item.startTime.localeCompare(t.item.startTime):e.item.order-t.item.order:e.dayPlan.date.localeCompare(t.dayPlan.date))});function x(e){return{[$.HOTEL]:`#1890ff`,[$.ATTRACTION]:`#52c41a`,[$.RESTAURANT]:`#faad14`,[$.TRANSPORT]:`#722ed1`,[$.ACTIVITY]:`#eb2f96`,[$.OTHER]:`#8c8c8c`}[e]||`#8c8c8c`}async function w(){try{c.value=(await fe.getCurrentUser()).data.data}catch(e){console.error(`Failed to load user info:`,e)}}async function T(){if(!(!s.value||!n.trip))try{if(await w(),h=await d({enableScrollWheelZoom:!0,controls:!0}),!h){console.error(`Failed to initialize map`);return}let e=window.BMapGL,t=[];c.value?.homeLatitude&&c.value?.homeLongitude&&t.push(new e.Point(Number(c.value.homeLongitude),Number(c.value.homeLatitude))),b.value.forEach(({item:n})=>{n.latitude&&n.longitude&&t.push(new e.Point(Number(n.longitude),Number(n.latitude)))}),t.length>0&&m(t,{enableAnimation:!0,margins:[50,50,50,50]}),D(),await j()}catch(e){console.error(`Failed to initialize Baidu Map:`,e)}}function D(){if(!h||!window.BMapGL||!c.value?.homeLatitude||!c.value?.homeLongitude)return;let e=window.BMapGL;v&&h.removeOverlay(v);let t=new e.Point(Number(c.value.homeLongitude),Number(c.value.homeLatitude)),n=new e.Icon(k(),new e.Size(32,32),{anchor:new e.Size(16,32)});v=new e.Marker(t,{icon:n}),h.addOverlay(v);let r=new e.InfoWindow(`<div style="padding: 8px; min-width: 200px;">
      <div style="font-weight: bold; margin-bottom: 4px; color: #1890ff;">
        🏠 家
      </div>
      ${c.value.homeAddress?`<div style="font-size: 12px; color: #666;">📍 ${c.value.homeAddress}</div>`:``}
    </div>`,{width:250,height:100});v.addEventListener(`click`,()=>{h.openInfoWindow(r,t)})}function k(){return`data:image/svg+xml;base64,${btoa(unescape(`%0A%20%20%20%20%3Csvg%20width%3D%2232%22%20height%3D%2232%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%3E%0A%20%20%20%20%20%20%3Ccircle%20cx%3D%2216%22%20cy%3D%2216%22%20r%3D%2214%22%20fill%3D%22%231890ff%22%20stroke%3D%22white%22%20stroke-width%3D%222%22%2F%3E%0A%20%20%20%20%20%20%3Cpath%20d%3D%22M16%2010%20L20%2014%20L20%2024%20L12%2024%20L12%2014%20Z%22%20fill%3D%22white%22%20stroke%3D%22white%22%20stroke-width%3D%221%22%2F%3E%0A%20%20%20%20%3C%2Fsvg%3E%0A%20%20`))}`}async function A(e,t){if(!window.BMapGL)return null;let n=window.BMapGL;return new Promise(r=>{let i=new n.DrivingRoute(h,{renderOptions:{map:h,autoViewport:!1,hideMarkers:!0},onSearchComplete:e=>{if(i.getStatus()===0){let t=e.getPlan(0);if(t){let e=t.getRoute(0);if(e){r(e.getPath());return}}}r(null)}});i.search(e,t)})}async function j(){if(h||=f(),!h||!window.BMapGL)return;let e=window.BMapGL;g.forEach(e=>h.removeOverlay(e)),_.forEach(e=>h.removeOverlay(e)),g=[],_=[],c.value?.homeLatitude&&c.value?.homeLongitude&&D();let t=new Map;b.value.forEach(e=>{let n=e.dayPlan.dayNumber;t.has(n)||t.set(n,[]),t.get(n).push(e)});let n=[`#1890ff`,`#52c41a`,`#faad14`,`#eb2f96`,`#722ed1`,`#13c2c2`,`#f5222d`],r=Array.from(t.keys()).sort((e,t)=>e-t),i=b.value.length>0?b.value[0]:null;if(c.value?.homeLatitude&&c.value?.homeLongitude&&i){let e=window.BMapGL,t=new e.Point(Number(c.value.homeLongitude),Number(c.value.homeLatitude)),n=new e.Point(Number(i.item.longitude),Number(i.item.latitude));try{let r=await A(t,n);if(r&&r.length>0){let t=new e.Polyline(r,{strokeColor:`#ff4d4f`,strokeWeight:4,strokeOpacity:.8,strokeStyle:`solid`});h.addOverlay(t),_.push(t)}else{let r=new e.Polyline([t,n],{strokeColor:`#ff4d4f`,strokeWeight:3,strokeOpacity:.6,strokeStyle:`dashed`});h.addOverlay(r),_.push(r)}}catch(r){console.error(`Failed to get route from home to first item:`,r);let i=new e.Polyline([t,n],{strokeColor:`#ff4d4f`,strokeWeight:3,strokeOpacity:.6,strokeStyle:`dashed`});h.addOverlay(i),_.push(i)}await new Promise(e=>setTimeout(e,100))}for(let i=0;i<r.length;i++){let a=r[i],o=t.get(a),s=n[(a-1)%n.length],c=[];if(o.forEach(({item:t,dayPlan:n},r)=>{let i=new e.Point(Number(t.longitude),Number(t.latitude));c.push(i);let a=new e.Icon(F(s,r+1,x(t.type)),new e.Size(32,32),{anchor:new e.Size(16,32)}),o=new e.Marker(i,{icon:a,zIndex:1e3});h.addOverlay(o),g.push(o),o.addEventListener(`click`,()=>{I(o,t,n)})}),c.length>1)for(let t=0;t<c.length-1;t++){let n=c[t],r=c[t+1];try{let t=await A(n,r);if(t&&t.length>0){let n=new e.Polyline(t,{strokeColor:s,strokeWeight:4,strokeOpacity:.8,strokeStyle:`solid`});h.addOverlay(n),_.push(n)}else{let t=new e.Polyline([n,r],{strokeColor:s,strokeWeight:3,strokeOpacity:.6,strokeStyle:`dashed`});h.addOverlay(t),_.push(t)}}catch(i){console.error(`Failed to get route from point ${t} to ${t+1}:`,i);let a=new e.Polyline([n,r],{strokeColor:s,strokeWeight:3,strokeOpacity:.6,strokeStyle:`dashed`});h.addOverlay(a),_.push(a)}await new Promise(e=>setTimeout(e,100))}else if(c.length===1&&i>0){let n=r[i-1],a=t.get(n);if(a&&a.length>0){let t=a[a.length-1],n=new e.Point(Number(t.item.longitude),Number(t.item.latitude)),r=c[0];try{let t=await A(n,r);if(t&&t.length>0){let n=new e.Polyline(t,{strokeColor:s,strokeWeight:4,strokeOpacity:.8,strokeStyle:`solid`});h.addOverlay(n),_.push(n)}else{let t=new e.Polyline([n,r],{strokeColor:s,strokeWeight:3,strokeOpacity:.6,strokeStyle:`dashed`});h.addOverlay(t),_.push(t)}}catch(t){console.error(`Failed to get route from previous day to current day:`,t);let i=new e.Polyline([n,r],{strokeColor:s,strokeWeight:3,strokeOpacity:.6,strokeStyle:`dashed`});h.addOverlay(i),_.push(i)}await new Promise(e=>setTimeout(e,100))}}}}function F(e,t,n){let r=`
    <svg width="32" height="32" xmlns="http://www.w3.org/2000/svg">
      <circle cx="16" cy="16" r="14" fill="${e}" stroke="white" stroke-width="2"/>
      <text x="16" y="20" font-size="12" font-weight="bold" fill="white" text-anchor="middle">${t}</text>
    </svg>
  `;return`data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(r)))}`}function I(e,t,n){if(!h||!window.BMapGL)return;let o=window.BMapGL;y&&y.close();let s=e=>`http://localhost:3000/uploads/${e}`,c=``;t.imgList&&t.imgList.length>0&&(c=`
      <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #e0e0e0;">
        <div style="font-size: 12px; color: #666; margin-bottom: 8px;">图片：</div>
        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
          ${t.imgList.map(e=>s(e)).map(e=>`
            <img 
              src="${e}" 
              alt="Photo" 
              style="width: 80px; height: 80px; object-fit: cover; border-radius: 6px; cursor: pointer;"
              onclick="window.open('${e}', '_blank')"
            />
          `).join(``)}
        </div>
      </div>
    `);let u=t.startTime&&t.endTime?`${t.startTime} - ${t.endTime}`:t.startTime||t.endTime||`-`,d=`
    <div style="padding: 16px; min-width: 300px; max-width: 400px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;">
      <div style="display: flex; align-items: flex-start; gap: 12px; margin-bottom: 12px; padding-bottom: 12px; border-bottom: 1px solid #e0e0e0;">
        <span style="font-size: 2rem; flex-shrink: 0; color: ${x(t.type)};">
          ${i(t.type)}
        </span>
        <div style="flex: 1;">
          <h3 style="margin: 0 0 4px 0; font-size: 1.1rem; font-weight: 600; color: #333;">
            ${t.name}
          </h3>
          <div style="display: inline-block; padding: 2px 8px; background: ${x(t.type)}20; color: ${x(t.type)}; border-radius: 4px; font-size: 12px; font-weight: 500;">
            ${a(t.type)}
          </div>
        </div>
      </div>

      <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.9rem;">
        ${t.address?`
          <div style="display: flex; align-items: center; gap: 8px; color: #666;">
            <span style="font-size: 16px;">📍</span>
            <span>${t.address}</span>
          </div>
        `:``}

        ${u===`-`?``:`
          <div style="display: flex; align-items: center; gap: 8px; color: #666;">
            <span style="font-size: 16px;">🕐</span>
            <span>${u}</span>
          </div>
        `}

        ${t.distance&&t.distance>0?`
          <div style="display: flex; align-items: center; gap: 8px; color: #666;">
            <span style="font-size: 16px;">🚗</span>
            <span>${r(t.distance)}</span>
          </div>
        `:``}

        ${t.duration&&t.duration>0?`
          <div style="display: flex; align-items: center; gap: 8px; color: #666;">
            <span style="font-size: 16px;">⏱️</span>
            <span>${l(t.duration)}</span>
          </div>
        `:``}

        ${t.cost?`
          <div style="display: flex; align-items: center; gap: 8px; color: #666;">
            <span style="font-size: 16px;">💰</span>
            <span>${ee(t.cost)}</span>
          </div>
        `:``}

        <div style="font-size: 12px; color: #999; margin-top: 4px;">
          ${n.date} 第${n.dayNumber}天
        </div>

        ${t.notes?`
          <div style="margin-top: 8px; padding-top: 12px; border-top: 1px solid #e0e0e0;">
            <p style="margin: 0; color: #666; font-size: 0.9rem; line-height: 1.5;">${t.notes}</p>
          </div>
        `:``}

        ${c}
      </div>
    </div>
  `,f=new o.InfoWindow(d,{width:400,maxHeight:600,enableMessage:!1,offset:new o.Size(0,-10)}),p=e.getPosition();h.openInfoWindow(f,p),y=f}function L(){g.forEach(e=>h.removeOverlay(e)),_.forEach(e=>h.removeOverlay(e)),v&&=(h.removeOverlay(v),null),y&&h&&(h.closeInfoWindow(),y=null),g=[],_=[]}E(()=>n.show,e=>{e?setTimeout(()=>{T()},100):(L(),h&&=null)}),E(()=>b.value,()=>{n.show&&(h||=f(),h&&j())},{deep:!0}),ie(()=>{L(),p(),h=null});function R(){o(`update:show`,!1)}return(t,n)=>(Z(),J(O(re),{show:e.show,preset:`card`,style:{width:`90vw`,"max-width":`1400px`,height:`90vh`},"mask-closable":!1,"onUpdate:show":n[0]||=e=>o(`update:show`,e)},{header:P(()=>[K(`div`,Qe,[K(`span`,$e,M(e.trip?.name||`行程地图`),1),V(O(C),{quaternary:``,circle:``,onClick:R},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(Ve))]),_:1})]),_:1})])]),default:P(()=>[K(`div`,et,[V(O(te),{show:O(u),description:`加载地图中...`},{default:P(()=>[K(`div`,{ref_key:`mapContainer`,ref:s,class:`map-container`},null,512)]),_:1},8,[`show`])])]),_:1},8,[`show`]))}}),[[`__scopeId`,`data-v-41ceb0be`]]),nt={key:0,class:`trip-detail`},rt={class:`page-header`},it={class:`trip-title`},at={key:0,class:`trip-description`},ot={class:`trip-meta`},st={class:`meta-item`},ct={class:`meta-item`},lt={class:`meta-item`},ut={class:`timeline-section`},dt={class:`section-header`},ft=[`onClick`],pt={class:`day-number`},mt={class:`day-date`},ht={class:`day-card-content`},gt={class:`day-info`},_t={key:0,class:`day-items`},vt={class:`item-name`},yt={key:0,class:`item-time`},bt={key:1,class:`day-notes-empty`},xt={key:2,class:`day-summary`},St={key:0,class:`summary-item`},Ct={key:1,class:`summary-item`},wt=g(G({__name:`index`,setup(i){let a=pe(),h=ue(),g=t(),w=se(),E=X(()=>Number(a.params.id)),D=N(!0),k=N(null),A=N([]),j=N(!1),F=N(!1);N(!1);let I=N(!1),L=N(!1);_e(()=>{R()});async function R(){D.value=!0;try{k.value=(await he.getById(E.value)).data.data,A.value=k.value.dayPlans||[]}catch{g.error(`加载行程失败`),h.push(`/trips`)}finally{D.value=!1}}async function re(e){try{await w.updateTrip(E.value,e),g.success(`行程更新成功`),R()}catch{g.error(`更新行程失败`)}}async function ie(){try{await w.deleteTrip(E.value),g.success(`行程删除成功`),h.push(`/trips`)}catch{g.error(`删除行程失败`)}}async function H(){if(!k.value)return;let e=new Set(A.value.map(e=>e.date)),t=(0,c.default)(k.value.startDate),n=(0,c.default)(k.value.endDate);for(;t.isBefore(n)||t.isSame(n);){let n=t.format(`YYYY-MM-DD`);if(!e.has(n))break;t=t.add(1,`day`)}if(t.isAfter(n)){g.warning(`行程范围内的所有日期都已创建日期计划`);return}let r={tripId:E.value,date:t.format(`YYYY-MM-DD`),dayNumber:A.value.length+1};try{let e=await le.create(r);e.data.code===200?(g.success(`日期计划已添加`),R()):g.error(e.data.message)}catch(e){g.error(e.message)}}async function ae(e){try{await le.delete(e),g.success(`日期计划已删除`),R()}catch{g.error(`删除日期计划失败`)}}function U(e){h.push(`/trips/${E.value}/day/${e.id}`)}let oe=X(()=>k.value?p(k.value.startDate,k.value.endDate):0),G={[$.HOTEL]:Le,[$.ATTRACTION]:ye,[$.RESTAURANT]:Ze,[$.TRANSPORT]:ze,[$.ACTIVITY]:Ge,[$.OTHER]:Ue},q={[$.HOTEL]:`住宿`,[$.ATTRACTION]:`景点`,[$.RESTAURANT]:`餐饮`,[$.TRANSPORT]:`交通`,[$.ACTIVITY]:`活动`,[$.OTHER]:`其他`},de={[$.HOTEL]:`info`,[$.ATTRACTION]:`success`,[$.RESTAURANT]:`warning`,[$.TRANSPORT]:`default`,[$.ACTIVITY]:`error`,[$.OTHER]:`default`};function fe(e){return G[e]||Ue}function me(e){return q[e]||`其他`}function ge(e){return de[e]||`default`}async function Q(){if(k.value){D.value=!0;try{await R()}catch{g.error(`刷新失败`)}finally{D.value=!1}}}async function ve(){if(k.value){I.value=!0;try{let e=`${k.value.name||`trip`}.png`;await he.exportToImage(E.value,e),g.success(`图片导出成功`)}catch(e){g.error(e.message||`导出图片失败`)}finally{I.value=!1}}}return(t,i)=>(Z(),J(O(te),{show:D.value},{default:P(()=>[k.value?(Z(),B(`div`,nt,[K(`header`,rt,[V(O(C),{quaternary:``,onClick:i[0]||=e=>O(h).push(`/trips`)},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(be))]),_:1})]),default:P(()=>[i[6]||=Y(` 返回行程列表 `,-1)]),_:1}),V(O(e),null,{default:P(()=>[V(O(C),{type:`primary`,onClick:i[1]||=e=>L.value=!0},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(Ye))]),_:1})]),default:P(()=>[i[7]||=Y(` 查看地图 `,-1)]),_:1}),V(O(C),{onClick:ve,loading:I.value},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(qe))]),_:1})]),default:P(()=>[i[8]||=Y(` 导出图片 `,-1)]),_:1},8,[`loading`]),V(O(C),{onClick:i[2]||=e=>j.value=!0},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(u))]),_:1})]),default:P(()=>[i[9]||=Y(` 编辑 `,-1)]),_:1}),V(O(o),{onPositiveClick:ie},{trigger:P(()=>[V(O(C),{type:`error`},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(f))]),_:1})]),default:P(()=>[i[10]||=Y(` 删除 `,-1)]),_:1})]),default:P(()=>[i[11]||=Y(` 您确定要删除此行程吗？ `,-1)]),_:1})]),_:1})]),V(O(ce),{class:`trip-info-card`},{default:P(()=>[K(`h1`,it,M(k.value.name),1),k.value.description?(Z(),B(`p`,at,M(k.value.description),1)):W(``,!0),K(`div`,ot,[K(`div`,st,[V(O(S),{size:18},{default:P(()=>[V(O(_))]),_:1}),K(`span`,null,M(O(m)(k.value.startDate))+` - `+M(O(m)(k.value.endDate)),1),V(O(x),{type:`primary`,size:`small`},{default:P(()=>[Y(M(oe.value)+` 天`,1)]),_:1})]),K(`div`,ct,[V(O(S),{size:18},{default:P(()=>[V(O(y))]),_:1}),K(`span`,null,M(k.value.userCount)+` 人`,1)]),K(`div`,lt,[V(O(S),{size:18},{default:P(()=>[V(O(v))]),_:1}),K(`span`,null,M(O(ee)(k.value.budget))+` 预算`,1)])])]),_:1}),K(`section`,ut,[K(`div`,dt,[i[14]||=K(`h2`,{class:`section-title`},`行程安排`,-1),K(`div`,null,[V(O(C),{onClick:Q,loading:F.value},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(Te))]),_:1})]),default:P(()=>[i[12]||=Y(` 刷新行程 `,-1)]),_:1},8,[`loading`]),V(O(C),{style:{"margin-left":`10px`},type:`primary`,onClick:H},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(s))]),_:1})]),default:P(()=>[i[13]||=Y(` 添加日期 `,-1)]),_:1})])]),A.value.length>0?(Z(),J(O(Pe),{key:0,class:`day-timeline`},{default:P(()=>[(Z(!0),B(z,null,T(A.value,(t,n)=>(Z(),J(O(Fe),{key:t.id,type:`success`},{header:P(()=>[K(`div`,{class:`timeline-header`,onClick:e=>U(t)},[K(`span`,pt,`第 `+M(t.dayNumber)+` 天`,1),K(`span`,mt,M(O(m)(t.date))+` (`+M(O(d)(t.date))+`) `,1)],8,ft)]),default:P(()=>[V(O(ce),{class:`day-card`,hoverable:``,onClick:e=>U(t)},{default:P(()=>[K(`div`,ht,[K(`div`,gt,[t.dayPlanItems&&t.dayPlanItems.length>0?(Z(),B(`div`,_t,[(Z(!0),B(z,null,T(t.dayPlanItems,e=>(Z(),B(`div`,{key:e.id,class:`day-item`},[V(O(x),{type:ge(e.type),size:`small`,round:``},{icon:P(()=>[V(O(S),{component:fe(e.type)},null,8,[`component`])]),default:P(()=>[Y(` `+M(me(e.type)),1)]),_:2},1032,[`type`]),K(`span`,vt,M(e.name),1),e.startTime?(Z(),B(`span`,yt,[V(O(S),{size:12},{default:P(()=>[V(O(we))]),_:1}),Y(` `+M(e.startTime)+` `,1),e.endTime?(Z(),B(z,{key:0},[Y(`- `+M(e.endTime),1)],64)):W(``,!0)])):W(``,!0)]))),128))])):(Z(),B(`p`,bt,`尚未计划活动`)),t.distance||t.duration?(Z(),B(`div`,xt,[t.distance&&t.distance>0?(Z(),B(`span`,St,[V(O(S),{size:14},{default:P(()=>[V(O(Ce))]),_:1}),K(`span`,null,M(O(r)(t.distance)),1)])):W(``,!0),t.duration&&t.duration>0?(Z(),B(`span`,Ct,[V(O(S),{size:14},{default:P(()=>[V(O(Se))]),_:1}),K(`span`,null,M(O(l)(t.duration)),1)])):W(``,!0)])):W(``,!0)]),V(O(e),{class:`day-actions`},{default:P(()=>[V(O(C),{quaternary:``,circle:``,size:`small`,onClick:ne(e=>U(t),[`stop`])},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(u))]),_:1})]),_:1},8,[`onClick`]),n===A.value.length-1?(Z(),J(O(o),{key:0,onPositiveClick:e=>ae(t.id)},{trigger:P(()=>[V(O(C),{quaternary:``,circle:``,size:`small`,onClick:i[3]||=ne(()=>{},[`stop`])},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(f))]),_:1})]),_:1})]),default:P(()=>[i[15]||=Y(` 删除此日期计划？ `,-1)]),_:1},8,[`onPositiveClick`])):W(``,!0)]),_:2},1024)])]),_:2},1032,[`onClick`])]),_:2},1024))),128))]),_:1})):(Z(),J(O(n),{key:1,description:`还没有日期计划。添加您的第一天！`},{extra:P(()=>[V(O(C),{type:`primary`,onClick:H},{icon:P(()=>[V(O(S),null,{default:P(()=>[V(O(s))]),_:1})]),default:P(()=>[i[16]||=Y(` 添加第一天 `,-1)]),_:1})]),_:1}))]),V(b,{show:j.value,"onUpdate:show":i[4]||=e=>j.value=e,trip:k.value,onSubmit:re},null,8,[`show`,`trip`]),V(tt,{show:L.value,"onUpdate:show":i[5]||=e=>L.value=e,trip:k.value,"day-plans":A.value},null,8,[`show`,`trip`,`day-plans`])])):W(``,!0)]),_:1},8,[`show`]))}}),[[`__scopeId`,`data-v-99fc99cb`]]);export{wt as default};