import { MigrationInterface, QueryRunner } from "typeorm";
export declare class ModifyDistanceType1767610074033 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
