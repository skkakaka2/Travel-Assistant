import { MigrationInterface, QueryRunner } from "typeorm";
export declare class FixRelation1767617174593 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
