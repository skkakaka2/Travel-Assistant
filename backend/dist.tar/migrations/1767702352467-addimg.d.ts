import { MigrationInterface, QueryRunner } from "typeorm";
export declare class Addimg1767702352467 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
