"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddUserRelation1767612719862 = void 0;
class AddUserRelation1767612719862 {
    name = 'AddUserRelation1767612719862';
    async up(queryRunner) {
        const dayPlanItemsTable = await queryRunner.getTable('day_plan_items');
        const hasDayPlanItemsUserId = dayPlanItemsTable?.findColumnByName('userId');
        if (!hasDayPlanItemsUserId) {
            await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`userId\` int NULL`);
        }
        const dayPlansTable = await queryRunner.getTable('day_plans');
        const hasDayPlansUserId = dayPlansTable?.findColumnByName('userId');
        if (!hasDayPlansUserId) {
            await queryRunner.query(`ALTER TABLE \`day_plans\` ADD \`userId\` int NOT NULL`);
        }
        const dayPlanItemsForeignKeys = dayPlanItemsTable?.foreignKeys || [];
        const hasDayPlanItemsFK = dayPlanItemsForeignKeys.some(fk => fk.columnNames.includes('userId'));
        if (!hasDayPlanItemsFK) {
            await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD CONSTRAINT \`FK_47ba7a1efef75696d09210958a6\` FOREIGN KEY (\`userId\`) REFERENCES \`user\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        }
        const dayPlansForeignKeys = dayPlansTable?.foreignKeys || [];
        const hasDayPlansFK = dayPlansForeignKeys.some(fk => fk.columnNames.includes('userId'));
        if (!hasDayPlansFK) {
            await queryRunner.query(`ALTER TABLE \`day_plans\` ADD CONSTRAINT \`FK_e2532f3856bb1bfcd5669514297\` FOREIGN KEY (\`userId\`) REFERENCES \`user\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        }
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plans\` DROP FOREIGN KEY \`FK_e2532f3856bb1bfcd5669514297\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP FOREIGN KEY \`FK_47ba7a1efef75696d09210958a6\``);
        await queryRunner.query(`ALTER TABLE \`day_plans\` DROP COLUMN \`userId\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`userId\``);
    }
}
exports.AddUserRelation1767612719862 = AddUserRelation1767612719862;
//# sourceMappingURL=1767612719862-add_user_relation.js.map