import { MigrationInterface, QueryRunner } from "typeorm";
export declare class Addlatitude1767506330471 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
