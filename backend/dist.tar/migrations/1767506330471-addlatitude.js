"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Addlatitude1767506330471 = void 0;
class Addlatitude1767506330471 {
    name = 'Addlatitude1767506330471';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`latitude\` decimal(10,8) NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`longitude\` decimal(11,8) NULL`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`longitude\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`latitude\``);
    }
}
exports.Addlatitude1767506330471 = Addlatitude1767506330471;
//# sourceMappingURL=1767506330471-addlatitude.js.map