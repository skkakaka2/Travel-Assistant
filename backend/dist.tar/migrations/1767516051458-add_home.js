"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddHome1767516051458 = void 0;
class AddHome1767516051458 {
    name = 'AddHome1767516051458';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`user\` ADD \`homeAddress\` varchar(191) NULL`);
        await queryRunner.query(`ALTER TABLE \`user\` ADD \`homeLatitude\` decimal(10,8) NULL`);
        await queryRunner.query(`ALTER TABLE \`user\` ADD \`homeLongitude\` decimal(11,8) NULL`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`user\` DROP COLUMN \`homeLongitude\``);
        await queryRunner.query(`ALTER TABLE \`user\` DROP COLUMN \`homeLatitude\``);
        await queryRunner.query(`ALTER TABLE \`user\` DROP COLUMN \`homeAddress\``);
    }
}
exports.AddHome1767516051458 = AddHome1767516051458;
//# sourceMappingURL=1767516051458-add_home.js.map