"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddDistance1767515947273 = void 0;
class AddDistance1767515947273 {
    name = 'AddDistance1767515947273';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`distance\` int NULL`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`distance\``);
    }
}
exports.AddDistance1767515947273 = AddDistance1767515947273;
//# sourceMappingURL=1767515947273-add_distance.js.map