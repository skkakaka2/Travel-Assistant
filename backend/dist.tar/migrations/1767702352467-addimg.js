"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Addimg1767702352467 = void 0;
class Addimg1767702352467 {
    name = 'Addimg1767702352467';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`imgList\` json NULL`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`imgList\``);
    }
}
exports.Addimg1767702352467 = Addimg1767702352467;
//# sourceMappingURL=1767702352467-addimg.js.map