import { MigrationInterface, QueryRunner } from "typeorm";
export declare class Addtripid1767159375864 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
