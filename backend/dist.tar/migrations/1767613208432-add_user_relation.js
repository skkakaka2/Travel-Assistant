"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddUserRelation1767613208432 = void 0;
class AddUserRelation1767613208432 {
    name = 'AddUserRelation1767613208432';
    async up(queryRunner) {
        const dayPlansTable = await queryRunner.getTable('day_plans');
        const dayPlansForeignKeys = dayPlansTable?.foreignKeys || [];
        const hasDayPlansFK = dayPlansForeignKeys.some(fk => fk.name === 'FK_e2532f3856bb1bfcd5669514297' ||
            (fk.columnNames.includes('userId') && fk.referencedTableName === 'user'));
        if (!hasDayPlansFK) {
            await queryRunner.query(`ALTER TABLE \`day_plans\` ADD CONSTRAINT \`FK_e2532f3856bb1bfcd5669514297\` FOREIGN KEY (\`userId\`) REFERENCES \`user\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
        }
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plans\` DROP FOREIGN KEY \`FK_e2532f3856bb1bfcd5669514297\``);
    }
}
exports.AddUserRelation1767613208432 = AddUserRelation1767613208432;
//# sourceMappingURL=1767613208432-add_user_relation.js.map