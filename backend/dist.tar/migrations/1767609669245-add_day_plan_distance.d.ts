import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddDayPlanDistance1767609669245 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
