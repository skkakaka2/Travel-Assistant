import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddUserRelation1767612719862 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
