"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddDayPlanDistance1767609669245 = void 0;
class AddDayPlanDistance1767609669245 {
    name = 'AddDayPlanDistance1767609669245';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plans\` ADD \`distance\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plans\` ADD \`duration\` int NULL`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plans\` DROP COLUMN \`duration\``);
        await queryRunner.query(`ALTER TABLE \`day_plans\` DROP COLUMN \`distance\``);
    }
}
exports.AddDayPlanDistance1767609669245 = AddDayPlanDistance1767609669245;
//# sourceMappingURL=1767609669245-add_day_plan_distance.js.map