"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ModifyDistanceType1767610074033 = void 0;
class ModifyDistanceType1767610074033 {
    name = 'ModifyDistanceType1767610074033';
    async up(queryRunner) {
        await queryRunner.query(`UPDATE \`day_plan_items\` SET \`duration\` = 0 WHERE \`duration\` IS NULL`);
        await queryRunner.query(`UPDATE \`day_plan_items\` SET \`distance\` = 0 WHERE \`distance\` IS NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` CHANGE \`duration\` \`duration\` int NOT NULL DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` CHANGE \`distance\` \`distance\` int NOT NULL DEFAULT '0'`);
        await queryRunner.query(`UPDATE \`day_plans\` SET \`distance\` = 0 WHERE \`distance\` IS NULL`);
        await queryRunner.query(`UPDATE \`day_plans\` SET \`duration\` = 0 WHERE \`duration\` IS NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plans\` CHANGE \`distance\` \`distance\` int NOT NULL DEFAULT '0'`);
        await queryRunner.query(`ALTER TABLE \`day_plans\` CHANGE \`duration\` \`duration\` int NOT NULL DEFAULT '0'`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plans\` CHANGE \`duration\` \`duration\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plans\` CHANGE \`distance\` \`distance\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` CHANGE \`distance\` \`distance\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` CHANGE \`duration\` \`duration\` int NULL`);
    }
}
exports.ModifyDistanceType1767610074033 = ModifyDistanceType1767610074033;
//# sourceMappingURL=1767610074033-modify_distance_type.js.map