"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Addtripid1767159375864 = void 0;
class Addtripid1767159375864 {
    name = 'Addtripid1767159375864';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`tripId\` int NOT NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`tripIdId\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD CONSTRAINT \`FK_d596f92b2b33d2a6ac4c264f63a\` FOREIGN KEY (\`tripIdId\`) REFERENCES \`trips\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP FOREIGN KEY \`FK_d596f92b2b33d2a6ac4c264f63a\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`tripIdId\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`tripId\``);
    }
}
exports.Addtripid1767159375864 = Addtripid1767159375864;
//# sourceMappingURL=1767159375864-addtripid.js.map