import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddDistance1767515947273 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
