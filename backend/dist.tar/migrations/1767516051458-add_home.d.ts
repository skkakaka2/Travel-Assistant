import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddHome1767516051458 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
