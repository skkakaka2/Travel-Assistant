"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Modifytime1767159150459 = void 0;
class Modifytime1767159150459 {
    name = 'Modifytime1767159150459';
    async up(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP FOREIGN KEY \`FK_773b65da92373d248afb814a361\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`dayPlanIdId\` int NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`startTime\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`startTime\` varchar(5) NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`endTime\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`endTime\` varchar(5) NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD CONSTRAINT \`FK_e35f9e54fcbf1f7819c7a34ce38\` FOREIGN KEY (\`dayPlanIdId\`) REFERENCES \`day_plans\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP FOREIGN KEY \`FK_e35f9e54fcbf1f7819c7a34ce38\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`endTime\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`endTime\` datetime(3) NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`startTime\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD \`startTime\` datetime(3) NULL`);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` DROP COLUMN \`dayPlanIdId\``);
        await queryRunner.query(`ALTER TABLE \`day_plan_items\` ADD CONSTRAINT \`FK_773b65da92373d248afb814a361\` FOREIGN KEY (\`dayPlanId\`) REFERENCES \`day_plans\`(\`id\`) ON DELETE CASCADE ON UPDATE NO ACTION`);
    }
}
exports.Modifytime1767159150459 = Modifytime1767159150459;
//# sourceMappingURL=1767159150459-modifytime.js.map