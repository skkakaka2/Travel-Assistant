import { MigrationInterface, QueryRunner } from "typeorm";
export declare class Modifytime1767159150459 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
