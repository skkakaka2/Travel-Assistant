import { MigrationInterface, QueryRunner } from "typeorm";
export declare class MigrationName1767097664754 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
