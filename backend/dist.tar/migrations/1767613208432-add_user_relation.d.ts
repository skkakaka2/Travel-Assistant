import { MigrationInterface, QueryRunner } from "typeorm";
export declare class AddUserRelation1767613208432 implements MigrationInterface {
    name: string;
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
