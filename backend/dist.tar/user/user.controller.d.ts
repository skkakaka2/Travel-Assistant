import { UserService } from './user.service';
import { CreateUserDto, SetHomeDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    create(createUserDto: CreateUserDto): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("./entities/user.entity").User>>;
    findAll(): Promise<import("../http-response/http-response").HttpResponse<import("./entities/user.entity").User[]>>;
    findOne(id: string): Promise<import("../http-response/http-response").HttpResponse<import("./entities/user.entity").User | null>>;
    update(id: string, updateUserDto: UpdateUserDto): Promise<import("../http-response/http-response").HttpResponse<import("./entities/user.entity").User | null>>;
    remove(id: string): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("./entities/user.entity").User>>;
    setHome(setHomeDto: SetHomeDto, user: ContextUser): Promise<import("../http-response/http-response").HttpResponse<SetHomeDto>>;
    me(user: ContextUser): Promise<import("../http-response/http-response").HttpResponse<import("./entities/user.entity").User | null>>;
    hasHome(user: ContextUser): Promise<import("../http-response/http-response").HttpResponse<boolean>>;
}
