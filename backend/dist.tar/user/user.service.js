"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const bcrypt = __importStar(require("bcrypt"));
const http_response_1 = require("../http-response/http-response");
const typeorm_1 = require("@nestjs/typeorm");
const user_entity_1 = require("./entities/user.entity");
const typeorm_2 = require("typeorm");
let UserService = class UserService {
    userRepository;
    constructor(userRepository) {
        this.userRepository = userRepository;
    }
    async create(createUserDto) {
        const user = await this.userRepository.findOne({
            where: {
                username: createUserDto.username,
            },
        });
        if (user) {
            return (0, http_response_1.errorResponse)('User already exists', null);
        }
        const hashedPassword = await bcrypt.hash(createUserDto.password, 10);
        const entity = this.userRepository.create({
            ...createUserDto,
            password: hashedPassword,
        });
        const result = await this.userRepository.save(entity);
        return (0, http_response_1.successResponse)(result);
    }
    async findAll() {
        const result = await this.userRepository.find();
        return (0, http_response_1.successResponse)(result);
    }
    async findOne(id) {
        const result = await this.userRepository.findOne({
            where: { id },
        });
        return (0, http_response_1.successResponse)(result);
    }
    async update(id, updateUserDto) {
        await this.userRepository.update({ id }, updateUserDto);
        const updated = await this.userRepository.findOne({ where: { id } });
        return (0, http_response_1.successResponse)(updated);
    }
    async remove(id) {
        const user = await this.userRepository.findOne({ where: { id } });
        if (!user) {
            return (0, http_response_1.errorResponse)('User not found', null);
        }
        await this.userRepository.delete({ id });
        return (0, http_response_1.successResponse)(user);
    }
    async setHome(setHomeDto, user) {
        await this.userRepository.update({ id: user.userId }, setHomeDto);
        return (0, http_response_1.successResponse)(setHomeDto);
    }
    async hasHome(user) {
        const result = await this.userRepository.findOne({
            where: { id: user.userId },
        });
        return (0, http_response_1.successResponse)(result?.homeAddress && result?.homeLatitude && result?.homeLongitude
            ? true
            : false);
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], UserService);
//# sourceMappingURL=user.service.js.map