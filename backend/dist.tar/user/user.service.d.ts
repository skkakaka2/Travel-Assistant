import { CreateUserDto, SetHomeDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from './entities/user.entity';
import { Repository } from 'typeorm';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
export declare class UserService {
    private readonly userRepository;
    constructor(userRepository: Repository<User>);
    create(createUserDto: CreateUserDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<User>>;
    findAll(): Promise<import("src/http-response/http-response").HttpResponse<User[]>>;
    findOne(id: number): Promise<import("src/http-response/http-response").HttpResponse<User | null>>;
    update(id: number, updateUserDto: UpdateUserDto): Promise<import("src/http-response/http-response").HttpResponse<User | null>>;
    remove(id: number): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<User>>;
    setHome(setHomeDto: SetHomeDto, user: ContextUser): Promise<import("src/http-response/http-response").HttpResponse<SetHomeDto>>;
    hasHome(user: ContextUser): Promise<import("src/http-response/http-response").HttpResponse<boolean>>;
}
