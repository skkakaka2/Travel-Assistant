import { Trip } from 'src/trip/entities/trip.entity';
export declare class User {
    id: number;
    email: string;
    username: string;
    password: string;
    name?: string | null;
    avatar?: string | null;
    homeAddress?: string | null;
    homeLatitude?: number | null;
    homeLongitude?: number | null;
    createdAt: Date;
    updatedAt: Date;
    trips: Trip[];
}
