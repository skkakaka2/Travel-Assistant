export declare class CreateUserDto {
    username: string;
    email: string;
    password: string;
    name: string;
    avatar: string;
}
export declare class SetHomeDto {
    homeAddress: string;
    homeLatitude: number;
    homeLongitude: number;
}
