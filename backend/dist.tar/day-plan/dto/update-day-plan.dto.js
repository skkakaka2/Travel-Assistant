"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateDayPlanDto = exports.UpdateDayPlanItemDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const day_plan_item_entity_1 = require("../../day-plan-item/entities/day-plan-item.entity");
class UpdateDayPlanItemDto {
    id;
    name;
    notes;
    type;
    address;
    startTime;
    endTime;
    duration;
    cost;
}
exports.UpdateDayPlanItemDto = UpdateDayPlanItemDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Item ID (required for updating existing items)',
        example: 1,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateDayPlanItemDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Item name',
        example: 'Visit the Great Wall',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanItemDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Notes for this item',
        example: 'Remember to bring water',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanItemDto.prototype, "notes", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Type of plan item',
        enum: day_plan_item_entity_1.PlanItemType,
        example: day_plan_item_entity_1.PlanItemType.ATTRACTION,
    }),
    (0, class_validator_1.IsEnum)(day_plan_item_entity_1.PlanItemType),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanItemDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Address of the location',
        example: 'Badaling, Beijing, China',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanItemDto.prototype, "address", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Start time (ISO 8601 format)',
        example: '09:00',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanItemDto.prototype, "startTime", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'End time (ISO 8601 format)',
        example: '12:00',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanItemDto.prototype, "endTime", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Duration in minutes',
        example: 180,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateDayPlanItemDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Cost in cents',
        example: 5000,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], UpdateDayPlanItemDto.prototype, "cost", void 0);
class UpdateDayPlanDto {
    date;
    dayNumber;
    notes;
}
exports.UpdateDayPlanDto = UpdateDayPlanDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Date of the day plan (ISO 8601 format)',
        example: '2024-01-15',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], UpdateDayPlanDto.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Day number in the trip',
        example: 1,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], UpdateDayPlanDto.prototype, "dayNumber", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        description: 'Notes for this day',
        example: 'First day of the trip',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], UpdateDayPlanDto.prototype, "notes", void 0);
//# sourceMappingURL=update-day-plan.dto.js.map