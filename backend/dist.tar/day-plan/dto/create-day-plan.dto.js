"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDayPlanDto = exports.CreateDayPlanItemDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const class_validator_1 = require("class-validator");
const day_plan_item_entity_1 = require("../../day-plan-item/entities/day-plan-item.entity");
class CreateDayPlanItemDto {
    name;
    notes;
    type;
    address;
    startTime;
    endTime;
    duration;
    cost;
}
exports.CreateDayPlanItemDto = CreateDayPlanItemDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Item name',
        example: 'Visit the Great Wall',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateDayPlanItemDto.prototype, "name", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Notes for this item',
        example: 'Remember to bring water',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDayPlanItemDto.prototype, "notes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Type of plan item',
        enum: day_plan_item_entity_1.PlanItemType,
        example: day_plan_item_entity_1.PlanItemType.ATTRACTION,
    }),
    (0, class_validator_1.IsEnum)(day_plan_item_entity_1.PlanItemType),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateDayPlanItemDto.prototype, "type", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Address of the location',
        example: 'Badaling, Beijing, China',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDayPlanItemDto.prototype, "address", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Start time (ISO 8601 format)',
        example: '09:00',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDayPlanItemDto.prototype, "startTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'End time (ISO 8601 format)',
        example: '12:00',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDayPlanItemDto.prototype, "endTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Duration in minutes',
        example: 180,
        required: false,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateDayPlanItemDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Cost in cents',
        example: 5000,
        required: false,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateDayPlanItemDto.prototype, "cost", void 0);
class CreateDayPlanDto {
    tripId;
    date;
    dayNumber;
    notes;
}
exports.CreateDayPlanDto = CreateDayPlanDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Trip ID',
        example: 1,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateDayPlanDto.prototype, "tripId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Date of the day plan (ISO 8601 format)',
        example: '2024-01-15',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateDayPlanDto.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Day number in the trip',
        example: 1,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsInt)(),
    (0, class_transformer_1.Type)(() => Number),
    __metadata("design:type", Number)
], CreateDayPlanDto.prototype, "dayNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Notes for this day',
        example: 'First day of the trip',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateDayPlanDto.prototype, "notes", void 0);
//# sourceMappingURL=create-day-plan.dto.js.map