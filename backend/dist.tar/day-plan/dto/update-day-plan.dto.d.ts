import { PlanItemType } from '../../day-plan-item/entities/day-plan-item.entity';
export declare class UpdateDayPlanItemDto {
    id?: number;
    name?: string;
    notes?: string;
    type?: PlanItemType;
    address?: string;
    startTime?: string;
    endTime?: string;
    duration?: number;
    cost?: number;
}
export declare class UpdateDayPlanDto {
    date?: string;
    dayNumber?: number;
    notes?: string;
}
