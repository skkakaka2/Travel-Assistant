import { PlanItemType } from '../../day-plan-item/entities/day-plan-item.entity';
export declare class CreateDayPlanItemDto {
    name: string;
    notes?: string;
    type: PlanItemType;
    address?: string;
    startTime?: string;
    endTime?: string;
    duration?: number;
    cost?: number;
}
export declare class CreateDayPlanDto {
    tripId: number;
    date: string;
    dayNumber: number;
    notes?: string;
}
