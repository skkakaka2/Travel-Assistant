"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlanService = void 0;
const common_1 = require("@nestjs/common");
const http_response_1 = require("../http-response/http-response");
const pagination_1 = require("../common/pagination");
const typeorm_1 = require("@nestjs/typeorm");
const day_plan_entity_1 = require("./entities/day-plan.entity");
const typeorm_2 = require("typeorm");
const trip_entity_1 = require("../trip/entities/trip.entity");
const day_plan_item_service_1 = require("../day-plan-item/day-plan-item.service");
let DayPlanService = class DayPlanService {
    dayPlanRepository;
    tripRepository;
    dayPlanItemService;
    constructor(dayPlanRepository, tripRepository, dayPlanItemService) {
        this.dayPlanRepository = dayPlanRepository;
        this.tripRepository = tripRepository;
        this.dayPlanItemService = dayPlanItemService;
    }
    async create(createDayPlanDto, user) {
        const trip = await this.tripRepository.findOne({
            where: {
                id: createDayPlanDto.tripId,
            },
        });
        if (!trip) {
            return (0, http_response_1.errorResponse)('Trip not found', null);
        }
        if (createDayPlanDto.date < trip.startDate ||
            createDayPlanDto.date > trip.endDate) {
            return (0, http_response_1.errorResponse)('Date is not in the trip range', null);
        }
        const exist = await this.dayPlanRepository.findOne({
            where: {
                tripId: createDayPlanDto.tripId,
                date: createDayPlanDto.date,
            },
        });
        if (exist) {
            return (0, http_response_1.errorResponse)('Day plan already exists', null);
        }
        if (createDayPlanDto.dayNumber > 1) {
            const previousDayPlan = await this.dayPlanRepository.findOne({
                where: {
                    tripId: createDayPlanDto.tripId,
                    dayNumber: createDayPlanDto.dayNumber - 1,
                },
            });
            if (previousDayPlan) {
                const previousDayPlanItems = await this.dayPlanItemService.findAllByDayPlanId(previousDayPlan.id);
                if (previousDayPlanItems.length === 0) {
                    return (0, http_response_1.errorResponse)('前一天未添加任何行程，请先完成前一天的行程', null);
                }
            }
        }
        const dayPlan = this.dayPlanRepository.create({
            tripId: createDayPlanDto.tripId,
            date: createDayPlanDto.date,
            dayNumber: createDayPlanDto.dayNumber,
            notes: createDayPlanDto.notes,
            userId: Number(user.userId),
        });
        const result = await this.dayPlanRepository.save(dayPlan);
        return (0, http_response_1.successResponse)(result);
    }
    async findAll(query) {
        const [result, total] = await this.dayPlanRepository.findAndCount({
            skip: (query.page - 1) * query.pageSize,
            take: query.pageSize,
            order: {
                date: 'DESC',
            },
        });
        const paginationResponse = new pagination_1.PaginationResponse(result, total, query.page, query.pageSize);
        return (0, http_response_1.successResponse)(paginationResponse);
    }
    async findAllItems(dayPlanId) {
        const result = await this.dayPlanItemService.findAllByDayPlanId(dayPlanId);
        return (0, http_response_1.successResponse)(result);
    }
    async findOne(id) {
        const result = await this.dayPlanRepository.findOne({
            where: {
                id,
            },
        });
        return (0, http_response_1.successResponse)(result);
    }
    async update(id, updateDayPlanDto) {
        const exist = await this.dayPlanRepository.findOne({
            where: {
                id,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Day plan not found', null);
        }
        const result = await this.dayPlanRepository.update(id, updateDayPlanDto);
        return (0, http_response_1.successResponse)(result);
    }
    async remove(id) {
        const exist = await this.dayPlanRepository.findOne({
            where: {
                id,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Day plan not found', null);
        }
        const result = await this.dayPlanRepository.delete(id);
        return (0, http_response_1.successResponse)(result);
    }
};
exports.DayPlanService = DayPlanService;
exports.DayPlanService = DayPlanService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(day_plan_entity_1.DayPlan)),
    __param(1, (0, typeorm_1.InjectRepository)(trip_entity_1.Trip)),
    __param(2, (0, common_1.Inject)((0, common_1.forwardRef)(() => day_plan_item_service_1.DayPlanItemService))),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        day_plan_item_service_1.DayPlanItemService])
], DayPlanService);
//# sourceMappingURL=day-plan.service.js.map