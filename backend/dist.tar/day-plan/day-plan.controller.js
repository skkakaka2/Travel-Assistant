"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlanController = void 0;
const common_1 = require("@nestjs/common");
const day_plan_service_1 = require("./day-plan.service");
const create_day_plan_dto_1 = require("./dto/create-day-plan.dto");
const update_day_plan_dto_1 = require("./dto/update-day-plan.dto");
const swagger_1 = require("@nestjs/swagger");
const pagination_1 = require("../common/pagination");
const contextuser_decorator_1 = require("../auth/decorators/contextuser.decorator");
let DayPlanController = class DayPlanController {
    dayPlanService;
    constructor(dayPlanService) {
        this.dayPlanService = dayPlanService;
    }
    create(createDayPlanDto, user) {
        return this.dayPlanService.create(createDayPlanDto, user);
    }
    findAll(query) {
        return this.dayPlanService.findAll(query);
    }
    findAllItems(id) {
        return this.dayPlanService.findAllItems(id);
    }
    findOne(id) {
        return this.dayPlanService.findOne(id);
    }
    update(id, updateDayPlanDto) {
        return this.dayPlanService.update(id, updateDayPlanDto);
    }
    remove(id) {
        return this.dayPlanService.remove(id);
    }
};
exports.DayPlanController = DayPlanController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create a day plan' }),
    (0, swagger_1.ApiBody)({ type: create_day_plan_dto_1.CreateDayPlanDto }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, contextuser_decorator_1.ContextUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_day_plan_dto_1.CreateDayPlanDto, Object]),
    __metadata("design:returntype", void 0)
], DayPlanController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all day plans' }),
    (0, swagger_1.ApiQuery)({ name: 'query', type: pagination_1.PaginationQuery }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pagination_1.PaginationQuery]),
    __metadata("design:returntype", void 0)
], DayPlanController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id/items'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all items of a day plan' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Day plan ID',
        type: Number,
        example: 1,
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DayPlanController.prototype, "findAllItems", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get a day plan by id' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Day plan ID',
        type: Number,
        example: 1,
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DayPlanController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update a day plan' }),
    (0, swagger_1.ApiParam)({
        type: Number,
        name: 'id',
        description: 'Day plan ID',
        example: 1,
    }),
    (0, swagger_1.ApiBody)({ type: update_day_plan_dto_1.UpdateDayPlanDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_day_plan_dto_1.UpdateDayPlanDto]),
    __metadata("design:returntype", void 0)
], DayPlanController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a day plan' }),
    (0, swagger_1.ApiParam)({
        type: Number,
        name: 'id',
        description: 'Day plan ID',
        example: 1,
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], DayPlanController.prototype, "remove", null);
exports.DayPlanController = DayPlanController = __decorate([
    (0, common_1.Controller)('dayplan'),
    __metadata("design:paramtypes", [day_plan_service_1.DayPlanService])
], DayPlanController);
//# sourceMappingURL=day-plan.controller.js.map