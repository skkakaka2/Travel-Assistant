"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlanModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const day_plan_service_1 = require("./day-plan.service");
const day_plan_controller_1 = require("./day-plan.controller");
const day_plan_entity_1 = require("./entities/day-plan.entity");
const day_plan_item_entity_1 = require("../day-plan-item/entities/day-plan-item.entity");
const trip_entity_1 = require("../trip/entities/trip.entity");
const user_module_1 = require("../user/user.module");
const day_plan_item_module_1 = require("../day-plan-item/day-plan-item.module");
let DayPlanModule = class DayPlanModule {
};
exports.DayPlanModule = DayPlanModule;
exports.DayPlanModule = DayPlanModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([day_plan_entity_1.DayPlan, day_plan_item_entity_1.DayPlanItem, trip_entity_1.Trip]),
            user_module_1.UserModule,
            day_plan_item_module_1.DayPlanItemModule,
        ],
        controllers: [day_plan_controller_1.DayPlanController],
        providers: [day_plan_service_1.DayPlanService],
    })
], DayPlanModule);
//# sourceMappingURL=day-plan.module.js.map