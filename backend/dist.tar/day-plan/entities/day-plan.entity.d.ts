import { Trip } from 'src/trip/entities/trip.entity';
import { DayPlanItem } from '../../day-plan-item/entities/day-plan-item.entity';
import { User } from 'src/user/entities/user.entity';
export declare class DayPlan {
    id: number;
    date: string;
    dayNumber: number;
    notes?: string | null;
    distance?: number;
    duration?: number;
    user: User;
    userId: number;
    createdAt: Date;
    updatedAt: Date;
    trip: Trip;
    tripId: number;
    dayPlanItems: DayPlanItem[];
}
