"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlan = void 0;
const typeorm_1 = require("typeorm");
const trip_entity_1 = require("../../trip/entities/trip.entity");
const day_plan_item_entity_1 = require("../../day-plan-item/entities/day-plan-item.entity");
const user_entity_1 = require("../../user/entities/user.entity");
let DayPlan = class DayPlan {
    id;
    date;
    dayNumber;
    notes;
    distance;
    duration;
    user;
    userId;
    createdAt;
    updatedAt;
    trip;
    tripId;
    dayPlanItems;
};
exports.DayPlan = DayPlan;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], DayPlan.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 191 }),
    __metadata("design:type", String)
], DayPlan.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], DayPlan.prototype, "dayNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], DayPlan.prototype, "notes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], DayPlan.prototype, "distance", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], DayPlan.prototype, "duration", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, (user) => user.id, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'userId' }),
    __metadata("design:type", user_entity_1.User)
], DayPlan.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], DayPlan.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        name: 'createdAt',
        type: 'datetime',
        precision: 3,
        default: () => 'CURRENT_TIMESTAMP(3)',
    }),
    __metadata("design:type", Date)
], DayPlan.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        name: 'updatedAt',
        type: 'datetime',
        precision: 3,
        default: () => 'CURRENT_TIMESTAMP(3)',
        onUpdate: 'CURRENT_TIMESTAMP(3)',
    }),
    __metadata("design:type", Date)
], DayPlan.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => trip_entity_1.Trip, (trip) => trip.dayPlans, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'tripId' }),
    __metadata("design:type", trip_entity_1.Trip)
], DayPlan.prototype, "trip", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], DayPlan.prototype, "tripId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => day_plan_item_entity_1.DayPlanItem, (dayPlanItem) => dayPlanItem.dayPlan),
    __metadata("design:type", Array)
], DayPlan.prototype, "dayPlanItems", void 0);
exports.DayPlan = DayPlan = __decorate([
    (0, typeorm_1.Entity)('day_plans'),
    (0, typeorm_1.Index)('day_plans_tripId_idx', ['tripId']),
    (0, typeorm_1.Index)('day_plans_date_idx', ['date']),
    (0, typeorm_1.Unique)('day_plans_tripId_date_key', ['tripId', 'date'])
], DayPlan);
//# sourceMappingURL=day-plan.entity.js.map