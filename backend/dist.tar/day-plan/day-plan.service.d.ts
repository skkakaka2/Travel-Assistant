import { CreateDayPlanDto } from './dto/create-day-plan.dto';
import { UpdateDayPlanDto } from './dto/update-day-plan.dto';
import { PaginationQuery, PaginationResponse } from 'src/common/pagination';
import { DayPlan } from './entities/day-plan.entity';
import { Repository } from 'typeorm';
import { Trip } from 'src/trip/entities/trip.entity';
import { DayPlanItemService } from 'src/day-plan-item/day-plan-item.service';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
export declare class DayPlanService {
    private readonly dayPlanRepository;
    private readonly tripRepository;
    private readonly dayPlanItemService;
    constructor(dayPlanRepository: Repository<DayPlan>, tripRepository: Repository<Trip>, dayPlanItemService: DayPlanItemService);
    create(createDayPlanDto: CreateDayPlanDto, user: ContextUser): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<DayPlan>>;
    findAll(query: PaginationQuery): Promise<import("src/http-response/http-response").HttpResponse<PaginationResponse<DayPlan>>>;
    findAllItems(dayPlanId: number): Promise<import("src/http-response/http-response").HttpResponse<import("../day-plan-item/entities/day-plan-item.entity").DayPlanItem[]>>;
    findOne(id: number): Promise<import("src/http-response/http-response").HttpResponse<DayPlan | null>>;
    update(id: number, updateDayPlanDto: UpdateDayPlanDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("typeorm").UpdateResult>>;
    remove(id: number): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("typeorm").DeleteResult>>;
}
