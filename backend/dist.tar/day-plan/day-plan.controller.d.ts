import { DayPlanService } from './day-plan.service';
import { CreateDayPlanDto } from './dto/create-day-plan.dto';
import { UpdateDayPlanDto } from './dto/update-day-plan.dto';
import { PaginationQuery } from 'src/common/pagination';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
export declare class DayPlanController {
    private readonly dayPlanService;
    constructor(dayPlanService: DayPlanService);
    create(createDayPlanDto: CreateDayPlanDto, user: ContextUser): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("./entities/day-plan.entity").DayPlan>>;
    findAll(query: PaginationQuery): Promise<import("../http-response/http-response").HttpResponse<import("src/common/pagination").PaginationResponse<import("./entities/day-plan.entity").DayPlan>>>;
    findAllItems(id: number): Promise<import("../http-response/http-response").HttpResponse<import("../day-plan-item/entities/day-plan-item.entity").DayPlanItem[]>>;
    findOne(id: number): Promise<import("../http-response/http-response").HttpResponse<import("./entities/day-plan.entity").DayPlan | null>>;
    update(id: number, updateDayPlanDto: UpdateDayPlanDto): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("typeorm").UpdateResult>>;
    remove(id: number): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("typeorm").DeleteResult>>;
}
