export declare class DayPlanModule {
}
