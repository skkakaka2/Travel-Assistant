export declare class AppController {
}
