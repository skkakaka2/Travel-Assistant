export declare class DayPlanItemModule {
}
