import { CreateDayPlanItemDto } from './dto/create-day-plan-item.dto';
import { UpdateDayPlanItemDto } from './dto/update-day-plan-item.dto';
import { Repository } from 'typeorm';
import { DayPlanItem } from './entities/day-plan-item.entity';
import { DayPlan } from 'src/day-plan/entities/day-plan.entity';
import { User } from 'src/user/entities/user.entity';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
import { CalculateItemDistanceJob } from 'src/queue';
import { Queue } from 'bullmq';
export declare class DayPlanItemService {
    private readonly dayPlanItemRepository;
    private readonly dayPlanRepository;
    private readonly userRepository;
    private readonly distanceCalculationQueue;
    constructor(dayPlanItemRepository: Repository<DayPlanItem>, dayPlanRepository: Repository<DayPlan>, userRepository: Repository<User>, distanceCalculationQueue: Queue<CalculateItemDistanceJob>);
    create(createDayPlanItemDto: CreateDayPlanItemDto, user: ContextUser): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<DayPlanItem>>;
    findAll(): string;
    findOne(id: number): string;
    findAllByDayPlanId(dayPlanId: number): Promise<DayPlanItem[]>;
    update(id: number, updateDayPlanItemDto: UpdateDayPlanItemDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("typeorm").UpdateResult>>;
    remove(id: number): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("typeorm").DeleteResult>>;
    checkTime(startTime: string, endTime: string): {
        check: boolean;
        message: string;
    };
    checkOverlap(startTime: string, endTime: string, items: DayPlanItem[]): boolean;
    uploadImg(itemId: number, img: string): Promise<import("src/http-response/http-response").HttpResponse<null> | undefined>;
    private calculateItemDistanceAndTime;
}
