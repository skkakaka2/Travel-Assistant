import { DayPlanItemService } from './day-plan-item.service';
import { CreateDayPlanItemDto } from './dto/create-day-plan-item.dto';
import { UpdateDayPlanItemDto } from './dto/update-day-plan-item.dto';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
export declare class DayPlanItemController {
    private readonly dayPlanItemService;
    constructor(dayPlanItemService: DayPlanItemService);
    create(createDayPlanItemDto: CreateDayPlanItemDto, user: ContextUser): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("./entities/day-plan-item.entity").DayPlanItem>>;
    findAll(): string;
    findOne(id: string): string;
    update(id: string, updateDayPlanItemDto: UpdateDayPlanItemDto): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("typeorm").UpdateResult>>;
    remove(id: string): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("typeorm").DeleteResult>>;
}
