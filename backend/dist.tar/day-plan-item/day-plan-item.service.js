"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlanItemService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const http_response_1 = require("../http-response/http-response");
const typeorm_2 = require("typeorm");
const day_plan_item_entity_1 = require("./entities/day-plan-item.entity");
const day_plan_entity_1 = require("../day-plan/entities/day-plan.entity");
const user_entity_1 = require("../user/entities/user.entity");
const bullmq_1 = require("@nestjs/bullmq");
const queue_1 = require("../queue");
const bullmq_2 = require("bullmq");
let DayPlanItemService = class DayPlanItemService {
    dayPlanItemRepository;
    dayPlanRepository;
    userRepository;
    distanceCalculationQueue;
    constructor(dayPlanItemRepository, dayPlanRepository, userRepository, distanceCalculationQueue) {
        this.dayPlanItemRepository = dayPlanItemRepository;
        this.dayPlanRepository = dayPlanRepository;
        this.userRepository = userRepository;
        this.distanceCalculationQueue = distanceCalculationQueue;
    }
    async create(createDayPlanItemDto, user) {
        const dayPlan = await this.dayPlanRepository.findOne({
            where: {
                id: createDayPlanItemDto.dayPlanId,
            },
        });
        if (!dayPlan) {
            return (0, http_response_1.errorResponse)('Day plan not found', null);
        }
        const userInfo = await this.userRepository.findOne({
            where: {
                id: user.userId,
            },
        });
        const { dayPlanId, startTime, endTime } = createDayPlanItemDto;
        const { check, message } = this.checkTime(startTime, endTime);
        if (!check) {
            return (0, http_response_1.errorResponse)(message, null);
        }
        const items = await this.dayPlanItemRepository.find({
            where: { dayPlanId },
            order: {
                order: 'ASC',
            },
        });
        const isOverlap = this.checkOverlap(startTime, endTime, items);
        if (isOverlap) {
            return (0, http_response_1.errorResponse)('存在时间重叠的行程', null);
        }
        const result = this.dayPlanItemRepository.create({
            ...createDayPlanItemDto,
            userId: Number(user.userId),
        });
        const savedResult = await this.dayPlanItemRepository.save(result);
        await this.calculateItemDistanceAndTime(savedResult.tripId, userInfo);
        return (0, http_response_1.successResponse)(savedResult);
    }
    findAll() {
        return `This action returns all dayPlanItem`;
    }
    findOne(id) {
        return `This action returns a #${id} dayPlanItem`;
    }
    async findAllByDayPlanId(dayPlanId) {
        const result = await this.dayPlanItemRepository.find({
            where: {
                dayPlanId,
            },
            order: {
                order: 'ASC',
            },
        });
        return result;
    }
    async update(id, updateDayPlanItemDto) {
        const exist = await this.dayPlanItemRepository.findOne({
            where: {
                id,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Day plan item not found', null);
        }
        const dayPlan = await this.dayPlanRepository.findOne({
            where: {
                id: exist.dayPlanId,
            },
        });
        if (!dayPlan) {
            return (0, http_response_1.errorResponse)('Day plan not found', null);
        }
        const { check, message } = this.checkTime(updateDayPlanItemDto.startTime, updateDayPlanItemDto.endTime);
        if (!check) {
            return (0, http_response_1.errorResponse)(message, null);
        }
        const { startTime, endTime } = updateDayPlanItemDto;
        const items = await this.dayPlanItemRepository.find({
            where: {
                dayPlanId: exist.dayPlanId,
            },
        });
        const isOverlap = this.checkOverlap(startTime, endTime, items.filter((item) => item.id !== id));
        if (isOverlap) {
            return (0, http_response_1.errorResponse)('存在时间重叠的行程', null);
        }
        const result = await this.dayPlanItemRepository.update(id, updateDayPlanItemDto);
        if (updateDayPlanItemDto.latitude || updateDayPlanItemDto.longitude) {
            const updatedItem = await this.dayPlanItemRepository.findOne({
                where: { id },
            });
            if (!updatedItem) {
                return (0, http_response_1.errorResponse)('Day plan item not found after update', null);
            }
            const userInfo = await this.userRepository.findOne({
                where: {
                    id: dayPlan.userId,
                },
            });
            const otherItems = items.filter((item) => item.id !== id);
            const latitude = updateDayPlanItemDto.latitude ?? updatedItem.latitude ?? undefined;
            const longitude = updateDayPlanItemDto.longitude ?? updatedItem.longitude ?? undefined;
            if (latitude && longitude) {
                await this.calculateItemDistanceAndTime(updatedItem.tripId, userInfo);
            }
        }
        return (0, http_response_1.successResponse)(result);
    }
    async remove(id) {
        const exist = await this.dayPlanItemRepository.findOne({
            where: {
                id,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Day plan item not found', null);
        }
        const dayPlan = await this.dayPlanRepository.findOne({
            where: {
                id: exist.dayPlanId,
            },
        });
        if (!dayPlan) {
            return (0, http_response_1.errorResponse)('Day plan not found', null);
        }
        const { distance, duration } = exist;
        if (distance && duration && (distance > 0 || duration > 0)) {
            const newDistance = dayPlan.distance - distance < 0
                ? 0
                : Math.floor(dayPlan.distance - distance);
            const newDuration = dayPlan.duration - duration < 0
                ? 0
                : Math.floor(dayPlan.duration - duration);
            await this.dayPlanRepository.update(exist.dayPlanId, {
                distance: newDistance,
                duration: newDuration,
            });
        }
        const result = await this.dayPlanItemRepository.delete(id);
        const userInfo = await this.userRepository.findOne({
            where: {
                id: dayPlan.userId,
            },
        });
        await this.calculateItemDistanceAndTime(exist.tripId, userInfo);
        return (0, http_response_1.successResponse)(result);
    }
    checkTime(startTime, endTime) {
        if (endTime === startTime) {
            return {
                check: false,
                message: '活动时间最少1小时',
            };
        }
        if (endTime < startTime) {
            return {
                check: false,
                message: '结束时间不能小于开始时间',
            };
        }
        return {
            check: true,
            message: '时间合法',
        };
    }
    checkOverlap(startTime, endTime, items) {
        return items.some((item) => {
            if (!item.startTime || !item.endTime)
                return false;
            return startTime < item.endTime && item.startTime < endTime;
        });
    }
    async uploadImg(itemId, img) {
        const exist = await this.dayPlanItemRepository.findOne({
            where: {
                id: itemId,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Day plan item not found', null);
        }
    }
    async calculateItemDistanceAndTime(tripId, userInfo) {
        this.distanceCalculationQueue.add(queue_1.JOB_NAMES.CALCULATE_ITEM_DISTANCE, {
            tripId,
            userInfo,
        });
    }
};
exports.DayPlanItemService = DayPlanItemService;
exports.DayPlanItemService = DayPlanItemService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(day_plan_item_entity_1.DayPlanItem)),
    __param(1, (0, typeorm_1.InjectRepository)(day_plan_entity_1.DayPlan)),
    __param(2, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(3, (0, bullmq_1.InjectQueue)(queue_1.QUEUE_NAMES.DISTANCE_CALCULATION)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        bullmq_2.Queue])
], DayPlanItemService);
//# sourceMappingURL=day-plan-item.service.js.map