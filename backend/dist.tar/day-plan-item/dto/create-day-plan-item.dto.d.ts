import { PlanItemType } from '../entities/day-plan-item.entity';
export declare class CreateDayPlanItemDto {
    dayPlanId: number;
    tripId: number;
    name: string;
    type: PlanItemType;
    address: string;
    startTime: string;
    endTime: string;
    cost?: number;
    notes?: string;
    latitude: number;
    longitude: number;
}
