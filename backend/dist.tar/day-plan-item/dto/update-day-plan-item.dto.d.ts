import { PlanItemType } from '../entities/day-plan-item.entity';
export declare class UpdateDayPlanItemDto {
    id?: number;
    name?: string;
    notes?: string;
    type?: PlanItemType;
    address?: string;
    startTime?: string;
    endTime?: string;
    cost?: number;
    latitude?: number;
    longitude?: number;
}
