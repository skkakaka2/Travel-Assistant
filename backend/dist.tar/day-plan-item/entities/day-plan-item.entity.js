"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlanItem = exports.PlanItemType = void 0;
const typeorm_1 = require("typeorm");
const day_plan_entity_1 = require("../../day-plan/entities/day-plan.entity");
const trip_entity_1 = require("../../trip/entities/trip.entity");
const user_entity_1 = require("../../user/entities/user.entity");
var PlanItemType;
(function (PlanItemType) {
    PlanItemType["HOTEL"] = "HOTEL";
    PlanItemType["ATTRACTION"] = "ATTRACTION";
    PlanItemType["RESTAURANT"] = "RESTAURANT";
    PlanItemType["TRANSPORT"] = "TRANSPORT";
    PlanItemType["ACTIVITY"] = "ACTIVITY";
    PlanItemType["OTHER"] = "OTHER";
})(PlanItemType || (exports.PlanItemType = PlanItemType = {}));
let DayPlanItem = class DayPlanItem {
    id;
    dayPlan;
    dayPlanId;
    trip;
    tripId;
    type;
    name;
    address;
    startTime;
    endTime;
    duration;
    cost;
    notes;
    order;
    latitude;
    longitude;
    distance;
    imgList;
    createdAt;
    updatedAt;
    user;
    userId;
};
exports.DayPlanItem = DayPlanItem;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], DayPlanItem.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => day_plan_entity_1.DayPlan, (dayPlan) => dayPlan.dayPlanItems, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'dayPlanId' }),
    __metadata("design:type", day_plan_entity_1.DayPlan)
], DayPlanItem.prototype, "dayPlan", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], DayPlanItem.prototype, "dayPlanId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => trip_entity_1.Trip, (trip) => trip.dayPlanItems, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'tripId' }),
    __metadata("design:type", trip_entity_1.Trip)
], DayPlanItem.prototype, "trip", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], DayPlanItem.prototype, "tripId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: PlanItemType }),
    __metadata("design:type", String)
], DayPlanItem.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], DayPlanItem.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "address", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 5, nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "startTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 5, nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "endTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "duration", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "cost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "notes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], DayPlanItem.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 8, nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "latitude", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 11, scale: 8, nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "longitude", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "distance", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'json', nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "imgList", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        name: 'createdAt',
        type: 'datetime',
        precision: 3,
        default: () => 'CURRENT_TIMESTAMP(3)',
    }),
    __metadata("design:type", Date)
], DayPlanItem.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        name: 'updatedAt',
        type: 'datetime',
        precision: 3,
        default: () => 'CURRENT_TIMESTAMP(3)',
        onUpdate: 'CURRENT_TIMESTAMP(3)',
    }),
    __metadata("design:type", Date)
], DayPlanItem.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, (user) => user.id, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'userId' }),
    __metadata("design:type", user_entity_1.User)
], DayPlanItem.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Object)
], DayPlanItem.prototype, "userId", void 0);
exports.DayPlanItem = DayPlanItem = __decorate([
    (0, typeorm_1.Entity)('day_plan_items'),
    (0, typeorm_1.Index)('day_plan_items_dayPlanId_idx', ['dayPlanId']),
    (0, typeorm_1.Index)('day_plan_items_type_idx', ['type'])
], DayPlanItem);
//# sourceMappingURL=day-plan-item.entity.js.map