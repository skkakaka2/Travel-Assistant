import { DayPlan } from '../../day-plan/entities/day-plan.entity';
import { Trip } from 'src/trip/entities/trip.entity';
import { User } from 'src/user/entities/user.entity';
export declare enum PlanItemType {
    HOTEL = "HOTEL",
    ATTRACTION = "ATTRACTION",
    RESTAURANT = "RESTAURANT",
    TRANSPORT = "TRANSPORT",
    ACTIVITY = "ACTIVITY",
    OTHER = "OTHER"
}
export declare class DayPlanItem {
    id: number;
    dayPlan: DayPlan;
    dayPlanId: number;
    trip: Trip;
    tripId: number;
    type: PlanItemType;
    name: string;
    address?: string | null;
    startTime?: string | null;
    endTime?: string | null;
    duration?: number | null;
    cost?: number | null;
    notes?: string | null;
    order: number;
    latitude?: number | null;
    longitude?: number | null;
    distance?: number | null;
    imgList?: string[] | null;
    createdAt: Date;
    updatedAt: Date;
    user: User;
    userId?: number | null;
}
