"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DayPlanItemController = void 0;
const common_1 = require("@nestjs/common");
const day_plan_item_service_1 = require("./day-plan-item.service");
const create_day_plan_item_dto_1 = require("./dto/create-day-plan-item.dto");
const update_day_plan_item_dto_1 = require("./dto/update-day-plan-item.dto");
const contextuser_decorator_1 = require("../auth/decorators/contextuser.decorator");
const swagger_1 = require("@nestjs/swagger");
let DayPlanItemController = class DayPlanItemController {
    dayPlanItemService;
    constructor(dayPlanItemService) {
        this.dayPlanItemService = dayPlanItemService;
    }
    create(createDayPlanItemDto, user) {
        return this.dayPlanItemService.create(createDayPlanItemDto, user);
    }
    findAll() {
        return this.dayPlanItemService.findAll();
    }
    findOne(id) {
        return this.dayPlanItemService.findOne(+id);
    }
    update(id, updateDayPlanItemDto) {
        return this.dayPlanItemService.update(+id, updateDayPlanItemDto);
    }
    remove(id) {
        return this.dayPlanItemService.remove(+id);
    }
};
exports.DayPlanItemController = DayPlanItemController;
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Create a day plan item' }),
    (0, swagger_1.ApiBody)({ type: create_day_plan_item_dto_1.CreateDayPlanItemDto }),
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, contextuser_decorator_1.ContextUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_day_plan_item_dto_1.CreateDayPlanItemDto, Object]),
    __metadata("design:returntype", void 0)
], DayPlanItemController.prototype, "create", null);
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Get all day plan items' }),
    (0, common_1.Get)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], DayPlanItemController.prototype, "findAll", null);
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Get a day plan item by id' }),
    (0, swagger_1.ApiParam)({ name: 'id', type: Number, example: 1 }),
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], DayPlanItemController.prototype, "findOne", null);
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Update a day plan item' }),
    (0, swagger_1.ApiParam)({ name: 'id', type: Number, example: 1 }),
    (0, swagger_1.ApiBody)({ type: update_day_plan_item_dto_1.UpdateDayPlanItemDto }),
    (0, common_1.Patch)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_day_plan_item_dto_1.UpdateDayPlanItemDto]),
    __metadata("design:returntype", void 0)
], DayPlanItemController.prototype, "update", null);
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Delete a day plan item' }),
    (0, swagger_1.ApiParam)({ name: 'id', type: Number, example: 1 }),
    (0, common_1.Delete)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], DayPlanItemController.prototype, "remove", null);
exports.DayPlanItemController = DayPlanItemController = __decorate([
    (0, common_1.Controller)('day-plan-item'),
    __metadata("design:paramtypes", [day_plan_item_service_1.DayPlanItemService])
], DayPlanItemController);
//# sourceMappingURL=day-plan-item.controller.js.map