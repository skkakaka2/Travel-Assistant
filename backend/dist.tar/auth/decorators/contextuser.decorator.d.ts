export interface ContextUser {
    userId: number;
    username: string;
}
export declare const ContextUser: (...dataOrPipes: unknown[]) => ParameterDecorator;
