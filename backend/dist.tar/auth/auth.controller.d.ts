import { AuthService } from './auth.service';
import { LoginDto } from './dto/create-auth.dto';
import type { FastifyReply } from 'fastify';
import { UserService } from 'src/user/user.service';
import { CreateUserDto } from 'src/user/dto/create-user.dto';
export declare class AuthController {
    private readonly authService;
    private readonly userService;
    constructor(authService: AuthService, userService: UserService);
    login(loginDto: LoginDto, res: FastifyReply): Promise<import("src/http-response/http-response").HttpResponse<any>>;
    register(createUserDto: CreateUserDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("../user/entities/user.entity").User>>;
}
