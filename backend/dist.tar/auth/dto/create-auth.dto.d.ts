export declare class CreateAuthDto {
    username: string;
    email: string;
    password: string;
    name?: string;
}
export declare class LoginDto {
    username: string;
    password: string;
}
