import { LoginDto } from './dto/create-auth.dto';
import { User } from 'src/user/entities/user.entity';
import { Repository } from 'typeorm';
export declare class AuthService {
    private readonly userRepository;
    constructor(userRepository: Repository<User>);
    login(loginDto: LoginDto): Promise<import("src/http-response/http-response").HttpResponse<any>>;
}
