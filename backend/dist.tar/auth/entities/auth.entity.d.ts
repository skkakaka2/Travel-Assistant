export declare class Auth {
}
