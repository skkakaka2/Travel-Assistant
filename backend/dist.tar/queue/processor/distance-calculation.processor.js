"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var DistanceCalculationProcessor_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DistanceCalculationProcessor = void 0;
const bullmq_1 = require("@nestjs/bullmq");
const typeorm_1 = require("@nestjs/typeorm");
const common_1 = require("@nestjs/common");
const day_plan_item_entity_1 = require("../../day-plan-item/entities/day-plan-item.entity");
const day_plan_entity_1 = require("../../day-plan/entities/day-plan.entity");
const queue_constants_1 = require("../queue.constants");
const typeorm_2 = require("typeorm");
const trip_entity_1 = require("../../trip/entities/trip.entity");
let DistanceCalculationProcessor = DistanceCalculationProcessor_1 = class DistanceCalculationProcessor extends bullmq_1.WorkerHost {
    dayPlanItemRepository;
    dayPlanRepository;
    tripRepository;
    logger = new common_1.Logger(DistanceCalculationProcessor_1.name);
    constructor(dayPlanItemRepository, dayPlanRepository, tripRepository) {
        super();
        this.dayPlanItemRepository = dayPlanItemRepository;
        this.dayPlanRepository = dayPlanRepository;
        this.tripRepository = tripRepository;
    }
    async process(job) {
        this.logger.log(`Processing job: ${job.name}, Job ID: ${job.id}`);
        try {
            switch (job.name) {
                case queue_constants_1.JOB_NAMES.CALCULATE_ITEM_DISTANCE:
                    return await this.calculateItemDistance(job.data);
                default:
                    this.logger.warn(`Unknown job name: ${job.name}`);
                    return null;
            }
        }
        catch (error) {
            this.logger.error(`Error processing job ${job.id}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async calculateItemDistance(data) {
        this.logger.log(`Calculating distance for trip ${data.tripId}`);
        const { tripId } = data;
        const tripInfo = await this.tripRepository.findOne({
            where: {
                id: tripId,
            },
            relations: {
                dayPlans: {
                    dayPlanItems: true,
                },
            },
            order: {
                dayPlans: {
                    dayPlanItems: {
                        startTime: 'ASC',
                    },
                },
            },
        });
        if (!tripInfo) {
            throw new Error('Trip not found');
        }
        const itemAll = tripInfo.dayPlans.flatMap((dayPlan) => dayPlan.dayPlanItems);
        for (let index = 0; index < itemAll.length; index++) {
            const item = itemAll[index];
            if (!item.latitude || !item.longitude) {
                continue;
            }
            let result;
            if (index === 0) {
                const start = {
                    latitude: data.userInfo.homeLatitude,
                    longitude: data.userInfo.homeLongitude,
                };
                result = await this.calculateDrivingDistance(start, {
                    latitude: item.latitude,
                    longitude: item.longitude,
                });
            }
            else {
                const prevItem = itemAll[index - 1];
                result = await this.calculateDrivingDistance({ latitude: prevItem.latitude, longitude: prevItem.longitude }, { latitude: item.latitude, longitude: item.longitude });
            }
            item.distance = result.distance;
            item.duration = result.duration;
            await this.dayPlanItemRepository.update(item.id, {
                distance: result.distance,
                duration: result.duration,
            });
            await new Promise((resolve) => setTimeout(resolve, 500));
        }
        for (const dayPlan of tripInfo.dayPlans) {
            const dayPlanItems = itemAll.filter((item) => item.dayPlanId === dayPlan.id);
            const dayPlanDistance = dayPlanItems.reduce((acc, item) => acc + (item.distance || 0), 0);
            const dayPlanDuration = dayPlanItems.reduce((acc, item) => acc + (item.duration || 0), 0);
            await this.dayPlanRepository.update(dayPlan.id, {
                distance: dayPlanDistance,
                duration: dayPlanDuration,
            });
        }
    }
    async calculateDrivingDistance(start, end) {
        const BAIDU_AK = process.env.BAIDU_MAP_SERVER_AK;
        if (!BAIDU_AK) {
            this.logger.error('BAIDU_MAP_SERVER_AK is not configured');
            return {
                distance: -1,
                duration: 0,
            };
        }
        const url = `https://api.map.baidu.com/directionlite/v1/driving?origin=${start.latitude},${start.longitude}&destination=${end.latitude},${end.longitude}&ak=${BAIDU_AK}`;
        this.logger.debug(`Requesting Baidu API: ${url.replace(BAIDU_AK, '***')}`);
        try {
            const res = await fetch(url);
            const data = await res.json();
            if (data.status === 0 &&
                data.result &&
                data.result.routes &&
                data.result.routes.length > 0) {
                const result = data.result.routes[0];
                this.logger.debug(`Baidu API success: distance=${result.distance}m, duration=${result.duration}s`);
                return {
                    distance: result.distance,
                    duration: result.duration,
                };
            }
            else {
                this.logger.warn(`Baidu API returned error: status=${data.status}, message=${data.message || 'Unknown error'}`);
                return {
                    distance: -1,
                    duration: 0,
                };
            }
        }
        catch (err) {
            this.logger.error(`Error calling Baidu API: ${err instanceof Error ? err.message : String(err)}`, err instanceof Error ? err.stack : undefined);
            return {
                distance: -1,
                duration: 0,
            };
        }
    }
};
exports.DistanceCalculationProcessor = DistanceCalculationProcessor;
exports.DistanceCalculationProcessor = DistanceCalculationProcessor = DistanceCalculationProcessor_1 = __decorate([
    (0, bullmq_1.Processor)(queue_constants_1.QUEUE_NAMES.DISTANCE_CALCULATION, { concurrency: 1 }),
    __param(0, (0, typeorm_1.InjectRepository)(day_plan_item_entity_1.DayPlanItem)),
    __param(1, (0, typeorm_1.InjectRepository)(day_plan_entity_1.DayPlan)),
    __param(2, (0, typeorm_1.InjectRepository)(trip_entity_1.Trip)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], DistanceCalculationProcessor);
//# sourceMappingURL=distance-calculation.processor.js.map