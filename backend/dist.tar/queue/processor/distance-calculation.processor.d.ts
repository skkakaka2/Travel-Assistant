import { WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { RouteResult } from 'src/common/distance.util';
import { DayPlanItem } from 'src/day-plan-item/entities/day-plan-item.entity';
import { DayPlan } from 'src/day-plan/entities/day-plan.entity';
import { CalculateItemDistanceJob } from '../queue.types';
import { Repository } from 'typeorm';
import { Trip } from 'src/trip/entities/trip.entity';
export declare class DistanceCalculationProcessor extends WorkerHost {
    private readonly dayPlanItemRepository;
    private readonly dayPlanRepository;
    private readonly tripRepository;
    private readonly logger;
    constructor(dayPlanItemRepository: Repository<DayPlanItem>, dayPlanRepository: Repository<DayPlan>, tripRepository: Repository<Trip>);
    process(job: Job<CalculateItemDistanceJob>): Promise<void | null>;
    calculateItemDistance(data: CalculateItemDistanceJob): Promise<void>;
    calculateDrivingDistance(start: {
        latitude: number;
        longitude: number;
    }, end: {
        latitude: number;
        longitude: number;
    }): Promise<RouteResult>;
}
