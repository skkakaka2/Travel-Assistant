import type { QueueOptions, JobsOptions } from 'bullmq';
export interface RedisConfig {
    host: string;
    port: number;
    password?: string;
    db?: number;
}
export declare function getRedisConfig(): RedisConfig;
export declare function getQueueOptions(): QueueOptions;
export declare function getDefaultJobOptions(): JobsOptions;
