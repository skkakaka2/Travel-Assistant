"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRedisConfig = getRedisConfig;
exports.getQueueOptions = getQueueOptions;
exports.getDefaultJobOptions = getDefaultJobOptions;
function getRedisConfig() {
    return {
        host: process.env.REDIS_HOST || 'localhost',
        port: parseInt(process.env.REDIS_PORT || '6379', 10),
        password: process.env.REDIS_PASSWORD || undefined,
        db: parseInt(process.env.REDIS_DB || '1', 10),
    };
}
function getQueueOptions() {
    const redisConfig = getRedisConfig();
    return {
        connection: {
            host: redisConfig.host,
            port: redisConfig.port,
            password: redisConfig.password,
            db: redisConfig.db,
        },
        defaultJobOptions: getDefaultJobOptions(),
    };
}
function getDefaultJobOptions() {
    return {
        attempts: parseInt(process.env.QUEUE_JOB_ATTEMPTS || '3', 10),
        backoff: {
            type: 'exponential',
            delay: 1000,
        },
        removeOnComplete: {
            count: 100,
            age: 24 * 60 * 60,
        },
        removeOnFail: {
            count: 500,
            age: 7 * 24 * 60 * 60,
        },
    };
}
//# sourceMappingURL=queue.config.js.map