"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QueueModule = void 0;
const common_1 = require("@nestjs/common");
const bullmq_1 = require("@nestjs/bullmq");
const queue_config_1 = require("./queue.config");
const queue_constants_1 = require("./queue.constants");
const typeorm_1 = require("@nestjs/typeorm");
const day_plan_item_entity_1 = require("../day-plan-item/entities/day-plan-item.entity");
const distance_calculation_processor_1 = require("./processor/distance-calculation.processor");
const day_plan_entity_1 = require("../day-plan/entities/day-plan.entity");
const trip_entity_1 = require("../trip/entities/trip.entity");
let QueueModule = class QueueModule {
};
exports.QueueModule = QueueModule;
exports.QueueModule = QueueModule = __decorate([
    (0, common_1.Module)({
        imports: [
            bullmq_1.BullModule.forRootAsync({
                useFactory: () => {
                    const redisConfig = (0, queue_config_1.getRedisConfig)();
                    return {
                        connection: {
                            host: redisConfig.host,
                            port: redisConfig.port,
                            password: redisConfig.password,
                            db: redisConfig.db,
                        },
                    };
                },
            }),
            bullmq_1.BullModule.registerQueue({
                name: queue_constants_1.QUEUE_NAMES.DISTANCE_CALCULATION,
            }),
            typeorm_1.TypeOrmModule.forFeature([day_plan_item_entity_1.DayPlanItem, day_plan_entity_1.DayPlan, trip_entity_1.Trip]),
        ],
        providers: [distance_calculation_processor_1.DistanceCalculationProcessor],
        exports: [bullmq_1.BullModule],
    })
], QueueModule);
//# sourceMappingURL=queue.module.js.map