"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JOB_NAMES = exports.QUEUE_NAMES = void 0;
exports.QUEUE_NAMES = {
    DISTANCE_CALCULATION: 'distance-calculation',
};
exports.JOB_NAMES = {
    CALCULATE_ITEM_DISTANCE: 'calculate-item-distance',
    CALCULATE_DAY_PLAN_DISTANCE: 'calculate-day-plan-distance',
};
//# sourceMappingURL=queue.constants.js.map