import { User } from 'src/user/entities/user.entity';
export interface CalculateItemDistanceJob {
    tripId: number;
    userInfo: User;
}
export interface CalculateDayPlanDistanceJob {
    dayPlanId: number;
    tripId: number;
}
export interface DistanceCalculationResult {
    itemId: number;
    distance: number;
    success: boolean;
    error?: string;
}
