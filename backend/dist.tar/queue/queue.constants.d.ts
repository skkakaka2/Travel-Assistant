export declare const QUEUE_NAMES: {
    readonly DISTANCE_CALCULATION: "distance-calculation";
};
export declare const JOB_NAMES: {
    readonly CALCULATE_ITEM_DISTANCE: "calculate-item-distance";
    readonly CALCULATE_DAY_PLAN_DISTANCE: "calculate-day-plan-distance";
};
export type QueueName = (typeof QUEUE_NAMES)[keyof typeof QUEUE_NAMES];
export type JobName = (typeof JOB_NAMES)[keyof typeof JOB_NAMES];
