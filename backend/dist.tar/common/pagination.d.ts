export interface Pagination {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
}
export interface PaginationQuery {
    page: number;
    pageSize: number;
}
export declare class PaginationQuery implements PaginationQuery {
    page: number;
    pageSize: number;
}
export interface PaginationResponse<T> {
    data: T[];
    pagination: Pagination;
}
export declare class Pagination implements Pagination {
    total: number;
    page: number;
    pageSize: number;
    totalPages: number;
    constructor(total: number, page: number, pageSize: number);
}
export declare class PaginationResponse<T> implements PaginationResponse<T> {
    list: T[];
    pagination: Pagination;
    constructor(data: T[], total: number, page: number, pageSize: number);
}
