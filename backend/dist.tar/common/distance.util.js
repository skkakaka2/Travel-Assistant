"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.calculateDrivingDistance = calculateDrivingDistance;
exports.calculateWalkingDistance = calculateWalkingDistance;
exports.calculateHaversineDistance = calculateHaversineDistance;
exports.formatDistance = formatDistance;
exports.formatDuration = formatDuration;
exports.calculateRouteDistances = calculateRouteDistances;
exports.calculateTotalDrivingDistance = calculateTotalDrivingDistance;
function getBaiduMapAK() {
    const ak = process.env.BAIDU_MAP_SERVER_AK;
    if (!ak) {
        throw new Error('BAIDU_MAP_SERVER_AK is not configured');
    }
    return ak;
}
async function calculateDrivingDistance(origin, destination) {
    const ak = getBaiduMapAK();
    const originStr = `${origin.latitude},${origin.longitude}`;
    const destinationStr = `${destination.latitude},${destination.longitude}`;
    const url = new URL('https://api.map.baidu.com/direction/v2/driving');
    url.searchParams.set('origin', originStr);
    url.searchParams.set('destination', destinationStr);
    url.searchParams.set('ak', ak);
    try {
        const response = await fetch(url.toString());
        const data = await response.json();
        if (data.status !== 0) {
            throw new Error(`Baidu Map API error: ${data.message} (status: ${data.status})`);
        }
        if (!data.result?.routes?.length) {
            throw new Error('No route found');
        }
        const route = data.result.routes[0];
        return {
            distance: route.distance,
            duration: route.duration,
        };
    }
    catch (error) {
        console.error('Baidu Map API call failed, falling back to Haversine:', error);
        const distance = calculateHaversineDistance(origin.latitude, origin.longitude, destination.latitude, destination.longitude);
        return {
            distance,
            duration: 0,
        };
    }
}
async function calculateWalkingDistance(origin, destination) {
    const ak = getBaiduMapAK();
    const originStr = `${origin.latitude},${origin.longitude}`;
    const destinationStr = `${destination.latitude},${destination.longitude}`;
    const url = new URL('https://api.map.baidu.com/direction/v2/walking');
    url.searchParams.set('origin', originStr);
    url.searchParams.set('destination', destinationStr);
    url.searchParams.set('ak', ak);
    try {
        const response = await fetch(url.toString());
        const data = await response.json();
        if (data.status !== 0) {
            throw new Error(`Baidu Map API error: ${data.message} (status: ${data.status})`);
        }
        if (!data.result?.routes?.length) {
            throw new Error('No route found');
        }
        const route = data.result.routes[0];
        return {
            distance: route.distance,
            duration: route.duration,
        };
    }
    catch (error) {
        console.error('Baidu Map API call failed, falling back to Haversine:', error);
        const distance = calculateHaversineDistance(origin.latitude, origin.longitude, destination.latitude, destination.longitude);
        return {
            distance,
            duration: 0,
        };
    }
}
function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const dLat = toRadians(lat2 - lat1);
    const dLon = toRadians(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(toRadians(lat1)) *
            Math.cos(toRadians(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
}
function toRadians(degrees) {
    return degrees * (Math.PI / 180);
}
function formatDistance(meters) {
    if (meters < 1000) {
        return `${meters}m`;
    }
    return `${(meters / 1000).toFixed(1)}km`;
}
function formatDuration(seconds) {
    if (seconds < 60) {
        return `${seconds}s`;
    }
    if (seconds < 3600) {
        return `${Math.round(seconds / 60)}min`;
    }
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.round((seconds % 3600) / 60);
    return `${hours}h ${minutes}min`;
}
async function calculateRouteDistances(points) {
    if (points.length < 2) {
        return [];
    }
    const results = [];
    for (let i = 1; i < points.length; i++) {
        const result = await calculateDrivingDistance(points[i - 1], points[i]);
        results.push(result);
    }
    return results;
}
async function calculateTotalDrivingDistance(points) {
    const results = await calculateRouteDistances(points);
    return results.reduce((acc, curr) => ({
        distance: acc.distance + curr.distance,
        duration: acc.duration + curr.duration,
    }), { distance: 0, duration: 0 });
}
//# sourceMappingURL=distance.util.js.map