export interface Coordinate {
    latitude: number;
    longitude: number;
}
export interface RouteResult {
    distance: number;
    duration: number;
}
export declare function calculateDrivingDistance(origin: Coordinate, destination: Coordinate): Promise<RouteResult>;
export declare function calculateWalkingDistance(origin: Coordinate, destination: Coordinate): Promise<RouteResult>;
export declare function calculateHaversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number;
export declare function formatDistance(meters: number): string;
export declare function formatDuration(seconds: number): string;
export declare function calculateRouteDistances(points: Coordinate[]): Promise<RouteResult[]>;
export declare function calculateTotalDrivingDistance(points: Coordinate[]): Promise<RouteResult>;
