"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.successResponse = successResponse;
exports.errorResponse = errorResponse;
function successResponse(data) {
    return {
        code: 200,
        message: 'success',
        data: data,
        timestamp: new Date().toISOString(),
    };
}
function errorResponse(message, data) {
    return {
        code: 400,
        message: message,
        data: data,
        timestamp: new Date().toISOString(),
    };
}
//# sourceMappingURL=http-response.js.map