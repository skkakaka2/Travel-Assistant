export interface HttpResponse<T> {
    code: number;
    message: string;
    data: T;
    timestamp: string;
}
export declare function successResponse<T>(data: T): HttpResponse<T>;
export declare function errorResponse<T>(message: string, data: T): HttpResponse<T>;
