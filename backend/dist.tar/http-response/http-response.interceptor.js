"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpResponseInterceptor = void 0;
const common_1 = require("@nestjs/common");
let HttpResponseInterceptor = class HttpResponseInterceptor {
    intercept(context, next) {
        const request = context.switchToHttp().getRequest();
        if (request && request.body && typeof request.body === 'object') {
            Object.keys(request.body).forEach((key) => {
                if (request.body[key] === '' ||
                    request.body[key] === undefined ||
                    request.body[key] === null) {
                    delete request.body[key];
                }
            });
        }
        if (request && request.query && typeof request.query === 'object') {
            Object.keys(request.query).forEach((key) => {
                if (request.query[key] === '' ||
                    request.query[key] === undefined ||
                    request.query[key] === null) {
                    delete request.query[key];
                }
            });
        }
        return next.handle();
    }
};
exports.HttpResponseInterceptor = HttpResponseInterceptor;
exports.HttpResponseInterceptor = HttpResponseInterceptor = __decorate([
    (0, common_1.Injectable)()
], HttpResponseInterceptor);
//# sourceMappingURL=http-response.interceptor.js.map