"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Trip = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../../user/entities/user.entity");
const day_plan_entity_1 = require("../../day-plan/entities/day-plan.entity");
const day_plan_item_entity_1 = require("../../day-plan-item/entities/day-plan-item.entity");
let Trip = class Trip {
    id;
    name;
    userCount;
    budget;
    startDate;
    endDate;
    description;
    createdAt;
    updatedAt;
    user;
    userId;
    dayPlans;
    dayPlanItems;
};
exports.Trip = Trip;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Trip.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ length: 255 }),
    __metadata("design:type", String)
], Trip.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], Trip.prototype, "userCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0 }),
    __metadata("design:type", Number)
], Trip.prototype, "budget", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 191 }),
    __metadata("design:type", String)
], Trip.prototype, "startDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 191 }),
    __metadata("design:type", String)
], Trip.prototype, "endDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], Trip.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        name: 'createdAt',
        type: 'datetime',
        precision: 3,
        default: () => 'CURRENT_TIMESTAMP(3)',
    }),
    __metadata("design:type", Date)
], Trip.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        name: 'updatedAt',
        type: 'datetime',
        precision: 3,
        default: () => 'CURRENT_TIMESTAMP(3)',
        onUpdate: 'CURRENT_TIMESTAMP(3)',
    }),
    __metadata("design:type", Date)
], Trip.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, (user) => user.trips, { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'userId' }),
    __metadata("design:type", user_entity_1.User)
], Trip.prototype, "user", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], Trip.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => day_plan_entity_1.DayPlan, (dayPlan) => dayPlan.trip),
    __metadata("design:type", Array)
], Trip.prototype, "dayPlans", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => day_plan_item_entity_1.DayPlanItem, (dayPlanItem) => dayPlanItem.trip),
    __metadata("design:type", Array)
], Trip.prototype, "dayPlanItems", void 0);
exports.Trip = Trip = __decorate([
    (0, typeorm_1.Entity)('trips'),
    (0, typeorm_1.Index)('trips_userId_idx', ['userId']),
    (0, typeorm_1.Index)('trips_startDate_idx', ['startDate'])
], Trip);
//# sourceMappingURL=trip.entity.js.map