import { User } from 'src/user/entities/user.entity';
import { DayPlan } from 'src/day-plan/entities/day-plan.entity';
import { DayPlanItem } from 'src/day-plan-item/entities/day-plan-item.entity';
export declare class Trip {
    id: number;
    name: string;
    userCount: number;
    budget: number;
    startDate: string;
    endDate: string;
    description?: string | null;
    createdAt: Date;
    updatedAt: Date;
    user: User;
    userId: number;
    dayPlans: DayPlan[];
    dayPlanItems: DayPlanItem[];
}
