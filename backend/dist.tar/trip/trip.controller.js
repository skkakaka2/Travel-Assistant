"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TripController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const trip_service_1 = require("./trip.service");
const trip_export_service_1 = require("./trip-export.service");
const create_trip_dto_1 = require("./dto/create-trip.dto");
const update_trip_dto_1 = require("./dto/update-trip.dto");
const contextuser_decorator_1 = require("../auth/decorators/contextuser.decorator");
const pagination_1 = require("../common/pagination");
let TripController = class TripController {
    tripService;
    tripExportService;
    constructor(tripService, tripExportService) {
        this.tripService = tripService;
        this.tripExportService = tripExportService;
    }
    create(createTripDto, user) {
        return this.tripService.create(createTripDto, user);
    }
    findAll(paginationQuery) {
        return this.tripService.findAll(paginationQuery);
    }
    findOne(id) {
        return this.tripService.findOne(id);
    }
    update(id, updateTripDto) {
        return this.tripService.update(id, updateTripDto);
    }
    remove(id) {
        return this.tripService.remove(id);
    }
    async exportToImage(id, reply) {
        try {
            const trip = await this.tripExportService.getTripWithDetails(id);
            const imageBuffer = await this.tripExportService.exportToImage(id);
            const tripName = trip.name || 'trip';
            reply
                .type('image/png')
                .header('Content-Disposition', `attachment; filename="${encodeURIComponent(tripName)}.png"`)
                .send(imageBuffer);
        }
        catch (error) {
            reply.status(500).send({
                code: 500,
                message: error.message || '导出图片失败',
                data: null,
            });
        }
    }
};
exports.TripController = TripController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create a trip' }),
    (0, swagger_1.ApiBody)({ type: create_trip_dto_1.CreateTripDto }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, contextuser_decorator_1.ContextUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_trip_dto_1.CreateTripDto, Object]),
    __metadata("design:returntype", void 0)
], TripController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get all trips' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [pagination_1.PaginationQuery]),
    __metadata("design:returntype", void 0)
], TripController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get a trip by id' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Trip ID',
        example: 1,
        type: Number,
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], TripController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update a trip' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Trip ID',
        example: 1,
        type: Number,
    }),
    (0, swagger_1.ApiBody)({ type: update_trip_dto_1.UpdateTripDto }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_trip_dto_1.UpdateTripDto]),
    __metadata("design:returntype", void 0)
], TripController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a trip' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Trip ID',
        example: 1,
        type: Number,
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], TripController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)(':id/export/image'),
    (0, swagger_1.ApiOperation)({ summary: 'Export trip as image (PNG)' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Trip ID',
        example: 1,
        type: Number,
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], TripController.prototype, "exportToImage", null);
exports.TripController = TripController = __decorate([
    (0, swagger_1.ApiTags)('Trip Management'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.Controller)('trip'),
    __metadata("design:paramtypes", [trip_service_1.TripService,
        trip_export_service_1.TripExportService])
], TripController);
//# sourceMappingURL=trip.controller.js.map