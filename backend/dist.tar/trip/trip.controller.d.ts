import { TripService } from './trip.service';
import { CreateTripDto } from './dto/create-trip.dto';
import { UpdateTripDto } from './dto/update-trip.dto';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
import { PaginationQuery } from 'src/common/pagination';
export declare class TripController {
    private readonly tripService;
    constructor(tripService: TripService);
    create(createTripDto: CreateTripDto, user: ContextUser): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("./entities/trip.entity").Trip>>;
    findAll(paginationQuery: PaginationQuery): Promise<import("../http-response/http-response").HttpResponse<import("src/common/pagination").PaginationResponse<import("./entities/trip.entity").Trip>>>;
    findOne(id: number): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("./entities/trip.entity").Trip>>;
    update(id: number, updateTripDto: UpdateTripDto): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("typeorm").UpdateResult>>;
    remove(id: number): Promise<import("../http-response/http-response").HttpResponse<null> | import("../http-response/http-response").HttpResponse<import("typeorm").DeleteResult>>;
}
