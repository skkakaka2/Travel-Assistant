export declare class CreateTripDto {
    name: string;
    userCount?: number;
    budget?: number;
    startDate: string;
    endDate: string;
    description?: string;
}
