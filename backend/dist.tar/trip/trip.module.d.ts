export declare class TripModule {
}
