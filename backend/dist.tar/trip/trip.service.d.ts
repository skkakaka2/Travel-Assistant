import { CreateTripDto } from './dto/create-trip.dto';
import { UpdateTripDto } from './dto/update-trip.dto';
import { ContextUser } from 'src/auth/decorators/contextuser.decorator';
import { PaginationQuery, PaginationResponse } from 'src/common/pagination';
import { Trip } from './entities/trip.entity';
import { Repository } from 'typeorm';
import { User } from 'src/user/entities/user.entity';
export declare class TripService {
    private readonly tripRepository;
    private readonly userRepository;
    constructor(tripRepository: Repository<Trip>, userRepository: Repository<User>);
    create(createTripDto: CreateTripDto, user: ContextUser): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<Trip>>;
    findAll(paginationQuery: PaginationQuery): Promise<import("src/http-response/http-response").HttpResponse<PaginationResponse<Trip>>>;
    findOne(id: number): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<Trip>>;
    update(id: number, updateTripDto: UpdateTripDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("typeorm").UpdateResult>>;
    remove(id: number): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("typeorm").DeleteResult>>;
}
