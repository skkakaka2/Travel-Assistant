"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TripService = void 0;
const common_1 = require("@nestjs/common");
const http_response_1 = require("../http-response/http-response");
const pagination_1 = require("../common/pagination");
const typeorm_1 = require("@nestjs/typeorm");
const trip_entity_1 = require("./entities/trip.entity");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("../user/entities/user.entity");
let TripService = class TripService {
    tripRepository;
    userRepository;
    constructor(tripRepository, userRepository) {
        this.tripRepository = tripRepository;
        this.userRepository = userRepository;
    }
    async create(createTripDto, user) {
        const existTrip = await this.tripRepository.findOne({
            where: {
                name: createTripDto.name,
            },
        });
        if (existTrip) {
            return (0, http_response_1.errorResponse)('Trip already exists', null);
        }
        const userInfo = await this.userRepository.findOne({
            where: {
                id: user.userId,
            },
        });
        if (!userInfo?.homeLatitude ||
            !userInfo?.homeLongitude ||
            !userInfo?.homeAddress) {
            return (0, http_response_1.errorResponse)('请先在用户设置中设置家的位置', null);
        }
        const data = this.tripRepository.create({
            ...createTripDto,
            userId: Number(user.userId),
        });
        const trip = await this.tripRepository.save(data);
        return (0, http_response_1.successResponse)(trip);
    }
    async findAll(paginationQuery) {
        const [result, total] = await this.tripRepository.findAndCount({
            skip: (paginationQuery.page - 1) * paginationQuery.pageSize,
            take: paginationQuery.pageSize,
            order: {
                createdAt: 'DESC',
            },
            relations: {
                dayPlans: true,
            },
        });
        const paginationResponse = new pagination_1.PaginationResponse(result, total, paginationQuery.page, paginationQuery.pageSize);
        return (0, http_response_1.successResponse)(paginationResponse);
    }
    async findOne(id) {
        const result = await this.tripRepository.findOne({
            where: {
                id,
            },
            relations: {
                dayPlans: {
                    dayPlanItems: true,
                },
            },
        });
        if (!result) {
            return (0, http_response_1.errorResponse)('Trip not found', null);
        }
        result.dayPlans.forEach((dayPlan) => {
            dayPlan.dayPlanItems.sort((a, b) => a.startTime.localeCompare(b.startTime));
        });
        return (0, http_response_1.successResponse)(result);
    }
    async update(id, updateTripDto) {
        const exist = await this.tripRepository.findOne({
            where: {
                id,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Trip not found', null);
        }
        const result = await this.tripRepository.update(id, updateTripDto);
        return (0, http_response_1.successResponse)(result);
    }
    async remove(id) {
        const exist = await this.tripRepository.findOne({
            where: {
                id,
            },
        });
        if (!exist) {
            return (0, http_response_1.errorResponse)('Trip not found', null);
        }
        const result = await this.tripRepository.delete(id);
        return (0, http_response_1.successResponse)(result);
    }
};
exports.TripService = TripService;
exports.TripService = TripService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(trip_entity_1.Trip)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], TripService);
//# sourceMappingURL=trip.service.js.map