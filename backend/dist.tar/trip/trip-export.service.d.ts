import { Repository } from 'typeorm';
import { Trip } from './entities/trip.entity';
export declare class TripExportService {
    private readonly tripRepository;
    private readonly logger;
    constructor(tripRepository: Repository<Trip>);
    getTripWithDetails(id: number): Promise<Trip>;
    private generateTripHTML;
    private generateDayPlansHTML;
    private getItemTypeLabel;
    private getDefaultTemplate;
    private getBrowserExecutablePath;
    exportToPDF(tripId: number): Promise<Buffer>;
    exportToImage(tripId: number): Promise<Buffer>;
}
