"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const auth_module_1 = require("./auth/auth.module");
const auth_guard_1 = require("./auth/auth.guard");
const core_1 = require("@nestjs/core");
const http_response_interceptor_1 = require("./http-response/http-response.interceptor");
const http_exception_filter_1 = require("./http-response/http-exception.filter");
const trip_module_1 = require("./trip/trip.module");
const user_module_1 = require("./user/user.module");
const common_2 = require("@nestjs/common");
const day_plan_module_1 = require("./day-plan/day-plan.module");
const typeorm_1 = require("@nestjs/typeorm");
const day_plan_item_entity_1 = require("./day-plan-item/entities/day-plan-item.entity");
const day_plan_entity_1 = require("./day-plan/entities/day-plan.entity");
const trip_entity_1 = require("./trip/entities/trip.entity");
const user_entity_1 = require("./user/entities/user.entity");
const day_plan_item_module_1 = require("./day-plan-item/day-plan-item.module");
const file_system_module_1 = require("./file-system/file-system.module");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
console.log(process.env.DATABASE_URL);
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forRootAsync({
                useFactory: () => {
                    const baseConfig = {
                        type: 'mysql',
                        entities: [user_entity_1.User, trip_entity_1.Trip, day_plan_entity_1.DayPlan, day_plan_item_entity_1.DayPlanItem],
                        synchronize: false,
                        logging: false,
                        autoLoadEntities: true,
                    };
                    if (process.env.DATABASE_URL) {
                        return {
                            ...baseConfig,
                            url: process.env.DATABASE_URL,
                        };
                    }
                    else {
                        throw new Error('DATABASE_URL is not set');
                    }
                },
            }),
            auth_module_1.AuthModule,
            trip_module_1.TripModule,
            user_module_1.UserModule,
            day_plan_module_1.DayPlanModule,
            day_plan_item_module_1.DayPlanItemModule,
            file_system_module_1.FileSystemModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [
            app_service_1.AppService,
            {
                provide: core_1.APP_GUARD,
                useClass: auth_guard_1.AuthGuard,
            },
            {
                provide: core_1.APP_INTERCEPTOR,
                useClass: http_response_interceptor_1.HttpResponseInterceptor,
            },
            {
                provide: core_1.APP_FILTER,
                useClass: http_exception_filter_1.HttpExceptionFilter,
            },
            {
                provide: core_1.APP_PIPE,
                useValue: new common_2.ValidationPipe({
                    transform: true,
                    whitelist: true,
                    transformOptions: {
                        enableImplicitConversion: true,
                    },
                }),
            },
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map