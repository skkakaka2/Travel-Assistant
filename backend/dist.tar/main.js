"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const platform_fastify_1 = require("@nestjs/platform-fastify");
const multipart_1 = __importDefault(require("@fastify/multipart"));
const static_1 = __importDefault(require("@fastify/static"));
const app_module_1 = require("./app.module");
const typeorm_1 = require("typeorm");
const seed_1 = require("./seeds/seed");
const swagger_1 = require("@nestjs/swagger");
const cookie_1 = __importDefault(require("@fastify/cookie"));
const dotenv_1 = require("dotenv");
const path_1 = require("path");
const fs_1 = require("fs");
require("reflect-metadata");
(0, dotenv_1.config)({ path: (0, path_1.resolve)(process.cwd(), '.env.local') });
(0, dotenv_1.config)({ path: (0, path_1.resolve)(process.cwd(), '.env') });
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule, new platform_fastify_1.FastifyAdapter());
    await app.register(cookie_1.default, {
        secret: process.env.COOKIE_SECRET || 'my-secret-key',
    });
    await app.register(multipart_1.default, {
        limits: {
            fileSize: 1024 * 1024 * 10,
        },
    });
    app.setGlobalPrefix('api');
    const uploadsDir = (0, path_1.join)(process.cwd(), 'uploads');
    if (!(0, fs_1.existsSync)(uploadsDir)) {
        (0, fs_1.mkdirSync)(uploadsDir, { recursive: true });
    }
    await app.register(static_1.default, {
        root: uploadsDir,
        prefix: '/uploads/',
        decorateReply: false,
    });
    await app.enableCors({
        origin: true,
        credentials: true,
    });
    const port = process.env.PORT ?? 3000;
    const config = new swagger_1.DocumentBuilder()
        .setTitle('Travel Assistant API')
        .setDescription('Travel Assistant API Documentation')
        .setVersion('1.0')
        .addServer(`http://localhost:${port}`, 'Local Development')
        .addServer(`http://127.0.0.1:${port}`, 'Local Development (127.0.0.1)')
        .addTag('app')
        .addTag('trip')
        .addCookieAuth('token', {
        type: 'http',
        in: 'Cookie',
    })
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, config);
    swagger_1.SwaggerModule.setup('api', app, document);
    const httpAdapter = app.getHttpAdapter();
    httpAdapter.get('/apijson', (req, res) => {
        httpAdapter.reply(res, document, 200);
    });
    const dataSource = app.get(typeorm_1.DataSource);
    await (0, seed_1.seedAdmin)(dataSource);
    await app.listen(port, '0.0.0.0');
    console.log(`🚀 Application is running on: http://localhost:${port}`);
}
bootstrap();
//# sourceMappingURL=main.js.map