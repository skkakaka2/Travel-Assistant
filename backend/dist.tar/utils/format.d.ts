export declare function formatCurrency(amount: number, currency?: string): string;
export declare function formatDistance(distance: number): string;
export declare function formatDuration(seconds: number): string;
