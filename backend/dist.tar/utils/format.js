"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatCurrency = formatCurrency;
exports.formatDistance = formatDistance;
exports.formatDuration = formatDuration;
function formatCurrency(amount, currency = 'CNY') {
    return new Intl.NumberFormat('zh-CN', {
        style: 'currency',
        currency,
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(amount);
}
function formatDistance(distance) {
    if (!distance || distance < 0)
        return '--';
    if (distance >= 1000) {
        return `${(distance / 1000).toFixed(1)} km`;
    }
    return `${distance} m`;
}
function formatDuration(seconds) {
    if (!seconds || seconds <= 0)
        return '--';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0 && minutes > 0) {
        return `${hours}h ${minutes}m`;
    }
    else if (hours > 0) {
        return `${hours}h`;
    }
    else if (minutes > 0) {
        return `${minutes}m`;
    }
    else {
        return '< 1m';
    }
}
//# sourceMappingURL=format.js.map