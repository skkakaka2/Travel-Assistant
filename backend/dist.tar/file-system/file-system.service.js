"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileSystemService = void 0;
const common_1 = require("@nestjs/common");
const fs_1 = require("fs");
const http_response_1 = require("../http-response/http-response");
const path_1 = __importDefault(require("path"));
const typeorm_1 = require("@nestjs/typeorm");
const day_plan_item_entity_1 = require("../day-plan-item/entities/day-plan-item.entity");
const typeorm_2 = require("typeorm");
const promises_1 = require("stream/promises");
let FileSystemService = class FileSystemService {
    dayPlanItemRepository;
    constructor(dayPlanItemRepository) {
        this.dayPlanItemRepository = dayPlanItemRepository;
    }
    async uploadFile(parts) {
        const fields = {};
        let savedFilePath = null;
        let uniqueName = '';
        for await (const part of parts) {
            if (part.type === 'file') {
                const filename = part.filename;
                const ext = path_1.default.extname(filename).toLowerCase();
                const allowedExts = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
                if (!allowedExts.includes(ext)) {
                    part.file.resume();
                    throw new Error('只能上传图片格式');
                }
                uniqueName = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}${ext}`;
                savedFilePath = path_1.default.join(process.cwd(), 'uploads', uniqueName);
                await (0, promises_1.pipeline)(part.file, (0, fs_1.createWriteStream)(savedFilePath));
            }
            else {
                fields[part.fieldname] = part.value;
            }
        }
        if (!savedFilePath) {
            return (0, http_response_1.errorResponse)('未上传文件', null);
        }
        if (!fields.itemId) {
            return (0, http_response_1.errorResponse)('itemId参数未传', null);
        }
        return await this.relateFileToItem(Number(fields.itemId), uniqueName);
    }
    async relateFileToItem(itemId, filename) {
        const item = await this.dayPlanItemRepository.findOne({
            where: {
                id: itemId,
            },
        });
        if (!item) {
            return (0, http_response_1.errorResponse)('Item not found', null);
        }
        if (!item.imgList) {
            item.imgList = [];
        }
        item.imgList.push(filename);
        const result = await this.dayPlanItemRepository.save(item);
        return (0, http_response_1.successResponse)(result);
    }
    async deleteFileToItem(data) {
        const item = await this.dayPlanItemRepository.findOne({
            where: {
                id: data.itemId,
            },
        });
        if (!item) {
            return (0, http_response_1.errorResponse)('Item not found', null);
        }
        if (!item.imgList) {
            item.imgList = [];
        }
        item.imgList = item.imgList.filter((img) => img !== data.filepath);
        const result = await this.dayPlanItemRepository.save(item);
        return (0, http_response_1.successResponse)(result);
    }
};
exports.FileSystemService = FileSystemService;
exports.FileSystemService = FileSystemService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(day_plan_item_entity_1.DayPlanItem)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], FileSystemService);
//# sourceMappingURL=file-system.service.js.map