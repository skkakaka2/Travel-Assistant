import { Multipart } from '@fastify/multipart';
import { DayPlanItem } from 'src/day-plan-item/entities/day-plan-item.entity';
import { Repository } from 'typeorm';
import { DeleteFileDto } from './dto/create.dto';
export declare class FileSystemService {
    private readonly dayPlanItemRepository;
    constructor(dayPlanItemRepository: Repository<DayPlanItem>);
    uploadFile(parts: AsyncIterableIterator<Multipart>): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<DayPlanItem>>;
    relateFileToItem(itemId: number, filename: string): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<DayPlanItem>>;
    deleteFileToItem(data: DeleteFileDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<DayPlanItem>>;
}
