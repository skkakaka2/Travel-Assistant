"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileSystemController = void 0;
const common_1 = require("@nestjs/common");
const file_system_service_1 = require("./file-system.service");
const swagger_1 = require("@nestjs/swagger");
const create_dto_1 = require("./dto/create.dto");
let FileSystemController = class FileSystemController {
    fileSystemService;
    constructor(fileSystemService) {
        this.fileSystemService = fileSystemService;
    }
    async uploadFile(request) {
        const parts = request.parts();
        return await this.fileSystemService.uploadFile(parts);
    }
    async deleteFile(deleteFileDto) {
        return await this.fileSystemService.deleteFileToItem(deleteFileDto);
    }
};
exports.FileSystemController = FileSystemController;
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Upload file' }),
    (0, swagger_1.ApiBody)({ type: create_dto_1.UploadFileDto }),
    (0, common_1.Post)('upload'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FileSystemController.prototype, "uploadFile", null);
__decorate([
    (0, swagger_1.ApiOperation)({ summary: 'Delete file' }),
    (0, swagger_1.ApiBody)({ type: create_dto_1.DeleteFileDto }),
    (0, common_1.Delete)('delete'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_dto_1.DeleteFileDto]),
    __metadata("design:returntype", Promise)
], FileSystemController.prototype, "deleteFile", null);
exports.FileSystemController = FileSystemController = __decorate([
    (0, common_1.Controller)('upload-file'),
    __metadata("design:paramtypes", [file_system_service_1.FileSystemService])
], FileSystemController);
//# sourceMappingURL=file-system.controller.js.map