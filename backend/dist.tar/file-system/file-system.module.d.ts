export declare class FileSystemModule {
}
