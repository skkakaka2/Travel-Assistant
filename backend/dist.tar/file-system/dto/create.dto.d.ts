import type { Multipart as FastifyMultipart } from '@fastify/multipart';
export declare class UploadFileDto {
    file: FastifyMultipart;
}
export declare class DeleteFileDto {
    itemId: number;
    filepath: string;
}
export declare class GetFileDto {
    path: string;
}
