import { FileSystemService } from './file-system.service';
import { DeleteFileDto } from './dto/create.dto';
import type { FastifyRequest } from 'fastify';
export declare class FileSystemController {
    private readonly fileSystemService;
    constructor(fileSystemService: FileSystemService);
    uploadFile(request: FastifyRequest): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("../day-plan-item/entities/day-plan-item.entity").DayPlanItem>>;
    deleteFile(deleteFileDto: DeleteFileDto): Promise<import("src/http-response/http-response").HttpResponse<null> | import("src/http-response/http-response").HttpResponse<import("../day-plan-item/entities/day-plan-item.entity").DayPlanItem>>;
}
